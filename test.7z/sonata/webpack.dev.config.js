const _ = require('underscore');
const webpack = require('webpack')

module.exports = _(require('./webpack.config'))
.chain()
.clone()
.extend({
    output: {
        path: '/',
        filename: 'bundle.js'
    },
    devtool: 'cheap-module-inline-source-map',
    plugins: [
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: '"development"',
                assayDataApiUrl: '"http://localhost:8070"',
                gridConfigUrl: '"http://localhost:8080"'
            },
        })
    ]
})
.value();
