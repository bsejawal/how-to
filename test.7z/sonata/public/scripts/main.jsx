import es6Promise from 'es6-promise';
import React from 'react';
import ReactDOM from 'react-dom';
import routes from './components/routes';
import { Provider } from 'react-redux'
import store from './redux/store/index'
const {queryProfile, queries, getAuthHeader, enableAuthTokenSupport} = require('@monsantoit/profile-client');
es6Promise.polyfill();

function installNavbar() {
    const navbar = require('@monsantoit/phoenix-navbar').default;
    return navbar.install({
            element: document.querySelector('.nav'),
            suiteId: 'velocity',
            productId: 'lab-testing'
        }, enableAuthTokenSupport()
        .then(() => {
            queryProfile(queries.currentUser())
                .then(rs => {
                        store.dispatch({type:'SET_CURRENT_USER', currentUser: rs.getCurrentUser});
                        ReactDOM.render(
                            <Provider store={store}>{routes}</Provider>,
                            document.querySelector('.contents'));
                    }
                )
        }).catch((e) => {
            console.error(e);
        })
    )
}

const navbarInstall = () => {
    installNavbar();
};

navbarInstall();