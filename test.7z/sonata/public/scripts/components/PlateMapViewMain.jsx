import React from 'react';

import PlateMapViewWF1 from './workflows/wft1/PlateMap/Grid'
import PlateMapViewWF2 from './workflows/wft2/PlateMap/Grid'

import {AjaxLoader} from "./util/Ajaxsetup";
import ProjectConstants from "./util/ProjectConstants"

class AssayDataMain extends React.Component {
    constructor(props){
        super(props);
        document.title = this.props.match.params.requestId+" Score";
        this.state = ({
            projectId: this.props.match.params.requestId,
            workflowType: this.props.match.params.wf,
            plateId: this.props.match.params.plateId
        })
    }

    render(){
        const {workflowType, projectId, plateId} = this.state;
        let returnPage = "";
        switch (workflowType) {
            case ProjectConstants.workflow_types.wft1:
                returnPage = <PlateMapViewWF1 {...this.props} workflowType={workflowType} projectId={projectId} plateId={plateId}/>;
                break;
            case ProjectConstants.workflow_types.wft2:
                returnPage = <PlateMapViewWF2 {...this.props} workflowType={workflowType} projectId={projectId} plateId={plateId}/>;
                break;
            default:
                returnPage = <div> This project is not under any workflow. Please add it to an existing workflow or define new one. </div>
                break;
        }
        return (
            <div>
                <AjaxLoader/>
                {returnPage}
            </div>
        );
    }
}

module.exports = AssayDataMain;