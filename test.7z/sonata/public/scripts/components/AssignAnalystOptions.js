import React from 'react';
const {queryProfile, queries} = require('@monsantoit/profile-client');
import Select from 'react-select'
import {$} from './react-table/common/Ajaxsetup'
import urls from './Urls'
import {toast } from 'react-toastify'
import _ from 'underscore'

import { connect } from 'react-redux'


class AssignAnalystOptions extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            selectedOption: null, options: []
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount(){
        let query = "{\n" +
            "  getGroupById(id: \"ScoringUI\") {\n" +
            "    id, members {\n" +
            "      members {\n" +
            "        id\n" +
            "        preferredName {\n" +
            "          full\n" +
            "        }\n" +
            "      }      \n" +
            "    }\n" +
            "  } \n" +
            "}";

        queryProfile(query)
            .then(rs => {
                let options = [];
                let members = rs.getGroupById.members.members;
                options.push({value: this.props.currentUser.id, label: this.props.currentUser.preferredName.full, className:'assign-analyst-options'});
                for(let member in members){
                    options.push({value: members[member].id, label: members[member].preferredName.full, className:'assign-analyst-options'});
                }
                this.setState({ options: options })
            });
    }

    handleChange(selectedOption){
        this.setState({
            selectedOption: selectedOption
        })
    };

    assignAnalyst(){
        const {selectedOption} = this.state;
        if(selectedOption!=null && selectedOption.value !== 'undefined'){
            let projectIds = [];
            let selectedRows = this.props.selectedRows;
            let warnings = [];
            for(let row in selectedRows){
                let data = selectedRows[row].data;
                projectIds.push(data.projectId);
                if(data.assignedTo){
                    warnings.push({"projectId": data.projectId, "assignedTo":data.assignedTo})
                }
            }
            this.props.dispatch({type:'ASSIGN_ANALYST_WARNING', warnings: warnings});
            let _this = this;
            let _filterOptions = JSON.stringify(this.props.filterOptions)
            if(projectIds.length > 0){
                $.ajax({
                    url: urls.assignAnalystRoute,
                    contentType: 'application/json',
                    type:'POST',
                    data:JSON.stringify({projectIds:projectIds, userId: selectedOption.value , projectFilterOptions: _filterOptions}),
                    cache: true,
                    success: function(data) {
                        this.props.fetchConfig(data.projectVOS);
                        _this.formatWarnings(data);
                    }.bind(this),
                    error: function(xhr, status, err) {
                        toast.error("Error while fetching configuration from api !! Msg = "+err+". Check server logs. ")
                    }.bind(this)
                });
            }
        }
    }

    formatWarnings(data){
        let previousAssignedObj = data.previousProjectAssignedToMapping;
        if(_.isEmpty(previousAssignedObj)) return;
        let formattedWarnings = "";
        Object.keys(previousAssignedObj).forEach(function(key){
            formattedWarnings += "Warning! Project "+key+" was previously assigned to "+previousAssignedObj[key]+" \n"
        });
        toast.warn(formattedWarnings, { position: toast.POSITION.TOP_CENTER, className: "assignAnalystWarning", autoClose: 600000, })
    }

    render() {
        const {selectedOption, options} = this.state;
        return (
            <div className="styled-select">
                <button className="button" id="assign-analyst-button" onClick={this.assignAnalyst.bind(this)}> Assign </button>
                <Select
                    // value={selectedOption}
                    onChange={this.handleChange.bind(this)}
                    options={options}
                    className=""
                    placeholder="Choose Analyst..."
                />

            </div>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        dispatch: dispatch
    }
};

export default connect(mapDispatchToProps)(AssignAnalystOptions)