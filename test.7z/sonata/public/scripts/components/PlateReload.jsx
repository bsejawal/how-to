import React from 'react';
import Modal from "react-responsive-modal"
import {loadImage} from '../resources/ImageLoader';
import {$} from "./util/Ajaxsetup";
import urls from "./Urls";
import {toast} from "react-toastify";

class PlateReload extends React.Component{
    constructor(props) {
        super(props);
        // reload, loading, loaded
        this.state = ({
            reloadStatus: false,
            reloadText: "reload"
        });
        this.reloadStatus = {
            "reload": "reload",
            "loading": "loading",
            "loaded" : "loaded"
        }
    }

    setLoaded(){
        this.setState({
            reloadText: this.reloadStatus.loaded,
            reloadStatus: false
        })
    }

    handleLoadClick(event){
        this.setState({
            reloadText: this.reloadStatus.loading,
            reloadStatus: true
        }, () => {
            // ajax call
            $.ajax({
                url: urls.reloadRoute,
                contentType: 'application/json',
                data:JSON.stringify({"requestId": this.props.projectId, "userId":this.props.userId}),
                type:'POST',
                cache: true,
                success: function(data) {
                    if(data["status"] !== "0")
                        toast.error("Error occured while applying filter. Please check server logs!");
                    else{
                        this.setLoaded.bind(this);
                    }
                }.bind(this),
                error: function(xhr, status, err) {

                    toast.error("Error while applying filters !! Msg = "+err+". Check server logs. ")
                }.bind(this)
            });
            setInterval( this.setLoaded.bind(this) , 3000)
        })

    }

    render() {
        const {reloadStatus, reloadText} = this.state;
        let loadingGif = "";
        if(reloadStatus){
            loadingGif = loadImage("reloading.gif", "loading...", {height: "3vh", width: "3vh"});
        }else
            loadingGif = loadImage("reload.png", "load", {height: "3vh", width: "3vh"});
        let loadingSpan = (
                <a onClick={this.handleLoadClick.bind(this)} href={"javascript:void(0)"}> {loadingGif} </a>
        )
        console.log("value =="+ this.props)
        return (
            <div>
                {loadingSpan}
            </div>
        );
    }

}

module.exports = PlateReload;


// class Notes extends React.Component {
//     constructor(props){
//         super(props);
//         this.state = ({
//             noteModal: false,
//             note:""
//         })
//     }