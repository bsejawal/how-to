import React from 'react'
import {$} from "./react-table/table/body/Page";
import urls from "./Urls";
import {toast} from "react-toastify";

class SubmitRedo extends React.Component{
    constructor(props){
        super(props);
        this.state = ({
            redoObj: {}
        })
    }

    submitRedo(){
        $.ajax({
            url: urls.submitRedoRoute,
            contentType: 'application/json',
            data:JSON.stringify({projectId: this.props.projectId, userId: this.props.currentUser.id}),
            type:'POST',
            cache: true,
            success: function(data) {
                let status = data["status"];
                let errorMsg = data["errorMsg"];
                if(status === 0){
                    window.location.reload(true);
                }else
                    toast.error(errorMsg);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error submitting for Redo. Please check server logs..");
            }.bind(this)
        });
    }

    render(){
        return(
            <div>
                <h4 className={"center-contents-div"}>Submit Plates marked as redo for project {this.props.projectId} ?</h4>
                <span className={"center-contents-div"}><button className="button" onClick={this.submitRedo.bind(this)}> Submit </button></span>
            </div>
        )
    }

}

module.exports = SubmitRedo;