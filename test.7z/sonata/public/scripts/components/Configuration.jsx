import React from 'react';
import Select from 'react-select'
import _ from 'underscore'
import {$, AjaxLoader, DataGrid} from "./react-table/table/body/Page";
import urls from "./Urls";
import {toast, ToastContainer} from "react-toastify";
import 'react-toastify/dist/ReactToastify.css'
import connect from "react-redux/es/connect/connect";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import DateUtil from './util/DateUtil'
import {Tab, TabList, TabPanel, Tabs} from 'react-tabs';
import ProjectConstants from './util/ProjectConstants'
import MarkerPlateConfig from './config/MarkerPlatesConfig'
import Modal from "react-awesome-modal";


class Configuration extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            appCode: ProjectConstants["app-codes"].SONATA, renderConfigs: false, configsSelected: {}, dropdownsOptions:{}, appConfigs: {},
            selectedMarkerPlates:[], markerPlateGridConfig: MarkerPlateConfig, markerPlateGridData: [], openDeleteMarkerPlates: false,
            projectId: ""
        });
        this.fetchConfigs = this.fetchConfigs.bind(this);
    }

    componentDidMount(){
        this.fetchConfigDropdowns();
    }

    getDropdownOptions(dropdownOptions){
        let options = [];
        dropdownOptions.forEach((opt) => {
            options.push({value:opt.code, label:opt.description});
        });
        return options;
    }

    handleChange(type, selectedOption){
        const {configsSelected} = this.state;
        let selectedConfig = _.extend({},configsSelected);
        selectedConfig[type] = selectedOption;
        this.setState({
            configsSelected: selectedConfig
        })
    }

    fetchConfigDropdowns(){
        $.ajax({
            url: urls.getDropdownsConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({ appCode: this.state.appCode, type: "CONFIG" }),
            type:'POST',
            cache: true,
            success: function(data) {
                if( data.responseHolders.length>0) {
                    let _this = this;
                    this.setState({
                        dropdownsOptions: data.categorizedResponseHolders,
                        renderConfigs: true
                    }, () => {
                        _this.fetchConfigs();
                    })
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration.");
            }.bind(this)
        });
    }

    fetchConfigs(){
        $.ajax({
            url: urls.getAppConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({ userId:this.props.currentUser.id, appCode: this.state.appCode, level: "project" }),
            type:'POST',
            cache: true,
            success: function(data) {
                console.log(data);
                let _configsSelected = (data.metaData!==null && typeof data.metaData !== "undefined" )? JSON.parse(data.metaData) : {}
                console.log(_configsSelected)
                this.setState({
                    appConfigs: _configsSelected,
                    configsSelected: _configsSelected
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration.");
            }.bind(this)
        });
    }

    saveConfig(){
        const { appCode, configsSelected } = this.state;
        let _configsSelected = JSON.stringify(configsSelected);
        $.ajax({
            url: urls.saveAppConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({ appCode: appCode, userId:this.props.currentUser.id, metaData: _configsSelected , level: "project"  }),
            type:'POST',
            cache: true,
            success: function(response) {
                if(response.status === "0") {
                    toast.success("Config saved successfully.");
                }else{
                    toast.error("Error while saving configuration. Check server logs!")
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration.");
            }.bind(this)
        });
    }

    resetConfig(){
        $.ajax({
            url: urls.resetAppConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({ userId:this.props.currentUser.id, appCode: this.state.appCode, level: "project"  }),
            type:'POST',
            cache: true,
            success: function(response) {
                if(response.status === "0") {
                    toast.success("Config reset successfully.");
                    window.location.reload(true);
                }else{
                    toast.error("Error while resetting configuration. Check server logs!")
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration.");
            }.bind(this)
        });
    }

    onRowClick(event, data, rowId) {
        this.setState({
            selectedMarkerPlates: data
        })
    }

    fetchMarkerPlateGridData(){
        $.ajax({
            url: urls.assayDataRoute+"?projectId="+this.state.projectId.toUpperCase(),
            contentType: 'application/json',
            type:'GET',
            cache: true,
            success: function(data) {
                console.log(data);
                if(typeof data.markerPlateVOList !== "undefined" && data.markerPlateVOList !== null && data.markerPlateVOList.length > 0) {
                    this.setState({
                        markerPlateGridData: data.markerPlateVOList
                    })
                }else{
                    toast.warn("No marker plates found for this project.");
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching plate data.");
            }.bind(this)
        });
    }

    handleProjectIdChange(event){
        this.setState({
            projectId: event.target.value
        });
    }

    deleteSelectedMarkerPlate(){
        const {selectedMarkerPlates, projectId} = this.state;
        if(selectedMarkerPlates.length === 0){
            toast.info("No plates selected. Please select plate(s) and try again.");
            return;
        }
        let _selectedData = [];
        for(var plate in selectedMarkerPlates){
            let _data = selectedMarkerPlates[plate].data;
            _selectedData.push({"plateMarkerId": _data.plateMarkerId, "pId": _data.pId})
        }
        let _this = this;
        $.ajax({
            url: urls.deleteMarkerPlatesRoute,
            contentType: 'application/json',
            data:JSON.stringify({ userId: this.props.currentUser.id, projectId: projectId, selectedMarkerPlates: _selectedData }),
            type:'POST',
            cache: true,
            success: function(response) {
                if(response.status === "0") {
                    toast.success("Marker plates deleted successfully. Page will reload... ", {
                        onClose: (() => { window.location.reload(true) } ),
                        autoClose: 2000
                    });
                }else{
                    toast.error("Error while deleting marker plates. Check server logs!")
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration.");
            }.bind(this)
        });
    }

    closeModal(type){
        this.setState({ [type]: false });
    };

    openModal(type){
        this.setState({ [type]: true });
    };

    render(){
        const {renderConfigs, configsSelected, dropdownsOptions, appConfigs, appCode, markerPlateGridConfig, markerPlateGridData, openDeleteMarkerPlates} = this.state;
        let preferencesTab = ( renderConfigs && <div className={"container"}>
                <h3>Configurations:</h3>
                <div className={"row"}>
                    <div className={"col-6"}>
                        Lab:
                    </div>
                    <div className={"col-6"}>
                        <Select
                            value={configsSelected.labs}
                            onChange={this.handleChange.bind(this, "labs")}
                            options={this.getDropdownOptions(dropdownsOptions.labs)}
                            className=""
                            placeholder="Choose Lab..."
                            isMulti={"true"}
                        />
                    </div>
                </div>
                <div className={"row"}>
                    <div className={"col-6"}>
                        Project Type:
                    </div>
                    <div className={"col-6"}>
                        <Select
                            value={configsSelected.project_types}
                            onChange={this.handleChange.bind(this, "project_types")}
                            options={this.getDropdownOptions(dropdownsOptions.project_types)}
                            className=""
                            placeholder="Choose Project Type..."
                            isMulti={"true"}
                        />
                    </div>
                </div>
                <div className={"row"}>
                    <div className={"col-6"}>
                        Project Year:
                    </div>
                    <div className={"col-6"}>
                        <Select
                            value={configsSelected.project_years}
                            onChange={this.handleChange.bind(this, "project_years")}
                            options={this.getDropdownOptions(dropdownsOptions.project_years)}
                            className=""
                            placeholder="Choose Project Year..."
                            isMulti={"true"}
                        />
                    </div>
                </div>
                <div className={"row"}>
                    <div className={"col-6"}>
                        Crop:
                    </div>
                    <div className={"col-6"}>
                        <Select
                            value={configsSelected.crop}
                            onChange={this.handleChange.bind(this, "crops")}
                            options={this.getDropdownOptions(dropdownsOptions.crop)}
                            className=""
                            placeholder="Choose Crop..."
                            isMulti={"true"}
                        />
                    </div>
                </div>
                <div className={"row"}>
                    <div className={"col-6"}>
                        Due Date Range:
                    </div>
                    <div className={"col-6"}>
                        From :
                        <DatePicker
                            selected={DateUtil.stringToDate(configsSelected.duedate_start)}
                            onChange={this.handleChange.bind(this, "duedate_start")}
                            dateFormat={"yyyy-MM-dd"}
                        />
                        To :
                        <DatePicker
                            selected={DateUtil.stringToDate(configsSelected.duedate_end)}
                            onChange={this.handleChange.bind(this, "duedate_end")}
                            dateFormat={"yyyy-MM-dd"}
                        />
                    </div>
                </div>
                <div className={"row"}>
                    <div className={"col"}>
                        <button onClick={this.saveConfig.bind(this)}
                                style={{float: "right", margin: "5% 0 0 0"}} type={"button"}
                                className={"btn btn-primary btn-raised btn-xs"}>Save
                        </button>
                        <button onClick={this.resetConfig.bind(this)}
                                style={{float: "right", margin: "5% 0 0 0"}} type={"button"}
                                className={"btn btn-primary btn-raised btn-xs"}>Reset
                        </button>
                    </div>
                </div>
            </div>);

        let markerPlateGrid = (
            <DataGrid
                appCode={appCode}
                fixedHeight={50}
                resultsPerPage={500}
                showAllData={false}
                onRowClick={this.onRowClick.bind(this)}
                showCheckBox={true}
                showCheckAllCheckbox={false}
                config={markerPlateGridConfig}
                //colorConfig={colorConfig}
                // customCellFormatters={customCellFormatters}
                data={markerPlateGridData}
                heading={"Marker Plates"}
                settingOptions={false}
                filterOptions={false}
                indexColumn={""}
            />
        );


        return(
            <div>
                <ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>
                <AjaxLoader/>
                <Tabs forceRenderTabPanel>
                    <TabList>
                        <Tab>Preferences</Tab>
                        <Tab>Delete Plates</Tab>
                        <Tab>Reload Plates</Tab>
                    </TabList>
                    <TabPanel>
                        {preferencesTab}
                    </TabPanel>
                    <TabPanel>
                        <div className={"container-fluid"}>
                            <div className={"row"}>
                                <Modal visible={openDeleteMarkerPlates}  height="200" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openDeleteMarkerPlates')}>
                                    <div>
                                        <h4 className={"center-contents-div"} style={{color: "red"}}>
                                            Warning !! Once you delete, you have to re-import to get them in. <br/>
                                            Are you sure to delete?
                                        </h4>
                                        <span className={"center-contents-div"}>
                                            <button className="button" onClick={this.deleteSelectedMarkerPlate.bind(this)}>
                                                Yes Delete
                                            </button>
                                        </span>
                                    </div>
                                </Modal>
                                <div style={{margin:"0 0 2vh 0"}} className={"col-3"}>
                                    Project Id: <input type={"text"} onChange={this.handleProjectIdChange.bind(this)}/> &nbsp;
                                    <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.fetchMarkerPlateGridData.bind(this)}> Load </button>
                                </div>
                                <div className={"col-6"}>
                                    {markerPlateGrid}
                                </div>
                                <div className={"col-3"}>
                                    <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.openModal.bind(this,'openDeleteMarkerPlates')}>Delete</button>
                                </div>
                            </div>
                        </div>
                    </TabPanel>
                    <TabPanel>
                        <div className={"container-fluid"}>
                            <div className={"row"}>

                            </div>
                        </div>
                    </TabPanel>
                </Tabs>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        currentUser: state.currentUser
    };
}

export default connect(mapStateToProps)(Configuration);