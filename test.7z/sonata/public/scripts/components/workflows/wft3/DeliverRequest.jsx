import React from 'react'
import {$} from "../../react-table/table/body/Page";
import {toast} from "react-toastify";
import urls from "../../Urls"

class DeliverRequest extends React.Component{
    constructor(props){
        super(props);
        this.requestBody = this.requestBody.bind(this);
    }

    requestBody(){
        return {
            "projectId":this.props.projectId,"currentUser":this.props.currentUser.id
        }
    }

    submitUploadRequest(){
        $.ajax({
            url: urls.deliverRequestRoute,
            contentType: 'application/json',
            data:JSON.stringify(this.requestBody()),
            type:'POST',
            cache: true,
            success: function(data) {
                console.log(data);
                let status = data["status"];
                if(status === 0)
                    toast.error("Error while creating zip file. Please check server logs..");
                else if(status === 1)
                    toast.error("Zip file created successfully but there is an error updating status in atlas. Please check server logs..");
                else if(status === 2)
                    window.location.reload(true);
                else
                    toast.error("Error occured. Please check server logs.")
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error uploading to rubicon. Please check server logs.." +err);
            }.bind(this)
        });
    }

    render(){
        return(
            <div >
                <h4 className={"center-contents-div"}>Upload Project {this.props.projectId} to Rubicon ?</h4>
                <span className={"center-contents-div"}><button className="button" onClick={this.submitUploadRequest.bind(this)}> Submit </button></span>
            </div>
        )
    }
}

module.exports = DeliverRequest;