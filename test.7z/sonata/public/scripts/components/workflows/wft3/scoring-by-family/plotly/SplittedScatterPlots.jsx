import React from 'react'

import ProjectConstants from "../../../../util/ProjectConstants";
import PlotsLayouts from "./layouts";
import _ from 'underscore'
import {toast} from "react-toastify";
import plotlyIcons from "./Plotly-icons";
import Plotly from "../../../../../../../node_modules/react-plotly.js/react-plotly";
import Modal from "react-awesome-modal";
import PlotExport from "./PlotExport";

const urls = require('../../../../Urls');
const trace_types = ProjectConstants.trace_types;
const Layouts = PlotsLayouts.layouts;

class SplittedScatterPlots extends React.Component {
    constructor(props){
        super(props);
        let commonModeBarButtonsToAdd = {
            exportedSelected: {
                name: 'exportSelected',
                title: 'Export Selected',
                _this: this,
                icon: plotlyIcons.download,
                click: this.exportToExcel
            }
        };
        Layouts.splittedScatterPlot.config.modeBarButtonsToAdd.push(commonModeBarButtonsToAdd.exportedSelected);
        this.state = ({
            plotsDiv: {},
            openDownload: false,
            openAssignCall:false,
            selectedData: [],
            vicScatterPlotSelectedPoints : [],
            famScatterPlotSelectedPoints : [],
            hemiScatterPlotSelectedPoints : [],
            failScatterPlotSelectedPoints : [],
            tandemScatterPlotSelectedPoints : [],
            multicopyScatterPlotSelectedPoints : [],
            splittedScatterPlotLayouts: Layouts.splittedScatterPlot
        });
        this.onPointsSelection = this.onPointsSelection.bind(this);
        this.onPointsDeselection = this.onPointsDeselection.bind(this);
        this.exportToExcel = this.exportToExcel.bind(this);
        this.attachKeyDownEventForShortCutKeys = this.attachKeyDownEventForShortCutKeys.bind(this);
        this.prepareText = this.prepareText.bind(this);
        this.resetScatterPlotSelectedPoints = this.resetScatterPlotSelectedPoints.bind(this);
    }

    componentDidMount(){
        this.attachKeyDownEventForShortCutKeys();
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    exportToExcel() {
        if(this._this.state.selectedData.length > 0){
            this._this.openModal('openDownload');
        }else{
            toast.error("No Data Selected");
        }

    };

    attachKeyDownEventForShortCutKeys(){
        let _this = this;
        let plotsDiv = document.getElementById("splitted-plot-row-by-family");
        plotsDiv.addEventListener('keydown', function(event){
            if(event.keyCode === 65){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.hom_fam, _this.state.selectedData);
            }else if(event.keyCode === 83){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.hemi, _this.state.selectedData);
            }else if(event.keyCode === 68){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.hom_vic, _this.state.selectedData);
            }else if(event.keyCode === 32){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.fail, _this.state.selectedData);
            }else if(event.keyCode === 84){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.tandem, _this.state.selectedData);
            }else if(event.keyCode === 77){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.multicopy, _this.state.selectedData);
            }
            event.stopPropagation();
        });
        this.setState({
            plotsDiv: plotsDiv
        })
    }

    resetScatterPlotSelectedPoints(){
        // Layouts.splittedScatterPlot.data[0].selectedpoints = null;
        // Layouts.splittedScatterPlot.data[1].selectedpoints = null;
        // Layouts.splittedScatterPlot.data[2].selectedpoints = null;
        // Layouts.splittedScatterPlot.data[3].selectedpoints = null;
    }

    onPointsSelection(event) {
        this.state.plotsDiv.focus();
        let _selectedData = [];
        let vicScatterSelectedPoints = [];
        let famScatterSelectedPoints = [];
        let hemiScatterSelectedPoints = [];
        let failScatterSelectedPoints = [];
        let tandemScatterSelectedPoints = [];
        let multicopyScatterSelectedPoints = [];
        if(event && event.points){
            event.points.forEach(function(point){
                _selectedData.push(point.data.METADATA[point.pointIndex]);
                if(point.data.name === trace_types.hom_fam)
                    famScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.hom_vic)
                    vicScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.hemi)
                    hemiScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.fail)
                    failScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.tandem)
                    tandemScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.multicopy)
                    multicopyScatterSelectedPoints.push(point.pointIndex);
            });
        }
        this.setState({
            selectedData: _selectedData,
            vicScatterPlotSelectedPoints: vicScatterSelectedPoints,
            famScatterPlotSelectedPoints: famScatterSelectedPoints,
            hemiScatterPlotSelectedPoints: hemiScatterSelectedPoints,
            failScatterPlotSelectedPoints: failScatterSelectedPoints,
            tandemScatterPlotSelectedPoints: tandemScatterSelectedPoints,
            multicopyScatterPlotSelectedPoints: multicopyScatterSelectedPoints
        }, () => {
            if(event && event.lassoPoints) {
                this.openModal('openAssignCall');
            }
        })
    }

    onPointsDeselection(){
        this.setState({
            selectedData: [],
            vicScatterPlotSelectedPoints: [],
            famScatterPlotSelectedPoints: [],
            hemiScatterPlotSelectedPoints: [],
            failScatterPlotSelectedPoints: [],
            tandemScatterPlotSelectedPoints: [],
            multicopyScatterPlotSelectedPoints: []
        })
    }

    prepareText(wellInfo){
        let info = "Well: "+wellInfo.wellName+"</br>";
        info += "Name: "+wellInfo.sampleName+"</br>";
        info += "Type: "+wellInfo.sampleClass+"</br>";
        info += "ROX: "+wellInfo.roxIntensity+"</br>";
        info += "VIC: "+wellInfo.vicIntensity+"</br>";
        info += "FAM: "+wellInfo.famIntensity+"</br>";
        info += "Call: "+wellInfo.predictedCall+"</br>";
        info += "Probability: "+wellInfo.maxProbability;
        return info;
    }

    getScatterPlot(scatterPlotDataByPlate){
        const {splittedScatterPlotLayouts} = this.state;
        let columns = [];
        for(let plate in scatterPlotDataByPlate){
            let plateData = scatterPlotDataByPlate[plate];
            let plotData = this.initializeDataPoints(splittedScatterPlotLayouts.data, plateData);
            columns.push(
                <div key={plate} className={"col-6"} style={{width: "50%", height:"25%"}}>
                    <h4>{plate}</h4>
                    {this.getScatterPlotByPlate(Object.assign([],plotData), plate, plateData, splittedScatterPlotLayouts)}
                </div>
            )
        }
        return(
            <div key={""} id={"splitted-plot-row-by-family"} tabIndex={0} className={"row outline0"}>{columns}</div>
        )
    }

    initializeDataPoints(scatterPlotData, scatterPlotDataPerPlate){
        _.extend(scatterPlotDataPerPlate.hom_fam, scatterPlotData[0] );
        _.extend(scatterPlotDataPerPlate.hom_vic, scatterPlotData[1] );
        _.extend(scatterPlotDataPerPlate.hemi, scatterPlotData[2] );
        _.extend(scatterPlotDataPerPlate.fail, scatterPlotData[3] );
        _.extend(scatterPlotDataPerPlate.standardControl, scatterPlotData[4] );
        _.extend(scatterPlotDataPerPlate.tandem, scatterPlotData[5] );
        _.extend(scatterPlotDataPerPlate.multicopy, scatterPlotData[6] );
        return [scatterPlotDataPerPlate.hom_fam, scatterPlotDataPerPlate.hom_vic, scatterPlotDataPerPlate.hemi, scatterPlotDataPerPlate.fail, scatterPlotDataPerPlate.standardControl,
            scatterPlotDataPerPlate.tandem, scatterPlotDataPerPlate.multicopy]
    }

    updatePredictedCall(predictedCallType, selectedData){
        let _this = this;
        _this.closeModal("openAssignCall");
        this.props.updatePredictedCall(predictedCallType, selectedData, function(){
            _this.resetScatterPlotSelectedPoints();
            _this.onPointsDeselection();
        }());
    }

    copyObj(src) {
        return JSON.parse(JSON.stringify(src));
    }

    getScatterPlotByPlate(scatterPlotData, divId, plateData, splittedScatterPlotLayouts){
        let _layout = this.copyObj(splittedScatterPlotLayouts.layout);
        let _x = plateData.range_x_upper - plateData.range_x_lower;
        let _y = plateData.range_y_upper - plateData.range_y_lower;
        _layout.xaxis.range = [plateData.range_x_lower-(_x*0.06), plateData.range_x_upper+(_x*0.06)];
        _layout.yaxis.range = [plateData.range_y_lower-(_y*0.06), plateData.range_y_upper+(_y*0.06)];
        return (
            <Plotly
                divId={divId}
                data={scatterPlotData}
                layout={_layout}
                frames={splittedScatterPlotLayouts.frames}
                config={splittedScatterPlotLayouts.config}
                useResizeHandler={true}
                style={{height:'100%', width:'100%'}}
                onSelected={(selectedPoints) => {
                    this.onPointsSelection(selectedPoints)
                }}
                onDeselect={() => {
                    this.onPointsDeselection();
                }}
            />
        )
    }

    render(){
        const { openDownload, openAssignCall, selectedData } = this.state;
        let scatterPlots = this.getScatterPlot(this.props.scatterPlotDataByPlates);
        let assignAnalyst;
        assignAnalyst = (
            <div>
                <h3>Assign Call</h3>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.hom_fam, selectedData)} value={trace_types.hom_fam}/> YY HOM FAM (A)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.hemi, selectedData)} value={trace_types.hemi}/> XY HEMI (S)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.hom_vic, selectedData)} value={trace_types.hom_vic}/> XX HOM VIC (D)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.fail, selectedData)} value={trace_types.fail}/> FAIL (SPACE)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.tandem, selectedData)} value={trace_types.tandem}/> TANDEM (T)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.multicopy, selectedData)} value={trace_types.multicopy}/> MULTICOPY (M)<br/>
            </div>
        );
        return(
            <div id="splitted-plots">
                <div>
                    <Modal visible={openAssignCall} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openAssignCall')}>
                        <div className="center-contents-div">
                            {assignAnalyst}
                        </div>
                    </Modal>
                    <Modal visible={openDownload} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openDownload')}>
                        <div className="center-contents-div">
                            <PlotExport excelData={selectedData}/>
                        </div>
                    </Modal>
                </div>
                <div>
                    <div className={""} style={{height:"90vh", overflowY:"scroll"}}>
                        {scatterPlots}
                    </div>
                </div>
            </div>
        )
    }

}

module.exports = SplittedScatterPlots