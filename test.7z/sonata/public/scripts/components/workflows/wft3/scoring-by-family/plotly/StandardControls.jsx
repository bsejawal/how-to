import React from 'react';
import HtmlParser from 'react-html-parser'

class StandardControls extends React.Component {
    constructor(props){
        super(props)
        this.state = ({

        })
    }

    buildStandardControlsTable(){
        let table =
            "<table id='standard-controls-table'>"+
            "<thead><tr>"+
            "<th>Type</th>"+
            "<th>Well</th>"+
            "<th>Sample</th>"+
            "<th>FP Call</th>"+
            "<th>Plate Call</th>"+
            "</tr></thead>" +
            "<tbody>";
        return table;
    }

    render(){

        return(
            <div className="standard-controls-div" style={{overflowX: "scroll"}}>
                <h4>Standard Controls</h4>
                {HtmlParser(this.buildStandardControlsTable())}
            </div>
        )
    }
}

module.exports = StandardControls