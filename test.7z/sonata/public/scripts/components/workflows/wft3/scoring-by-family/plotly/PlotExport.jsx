import React from 'react'

import ReactExport from "react-data-export";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

class Excel extends React.Component {
    constructor(props){
        super(props);
        this.state = ({

        })
    }

    render(){
        return (
            <div>
                <ExcelFile filename={"WellData"} element={<a href="javascript:void(0)" >Download Data</a>}>
                    <ExcelSheet data={this.props.excelData} name={"Well Information"}>
                        <ExcelColumn label="Well Name" value="wellName"/>
                        <ExcelColumn label="Sample ID" value="sampleId"/>
                        <ExcelColumn label="Rox Intensity" value="roxIntensity"/>
                        <ExcelColumn label="Fam Intensity" value="famIntensity"/>
                        <ExcelColumn label="Vic Intensity" value="vicIntensity"/>
                        <ExcelColumn label="Predicted Call" value="predictedCall"/>
                        <ExcelColumn label="Call Probability" value="maxCallProbability"/>
                        <ExcelColumn label="Ratio" value="ratio"/>
                        <ExcelColumn label="Hemi Probability" value="hemiProbability"/>
                        <ExcelColumn label="Homo Probability" value="homoProbability"/>
                        <ExcelColumn label="Neg Probability" value="negProbability"/>
                        <ExcelColumn label="Plate__Marker Id" value="plateMarkerId"/>
                        <ExcelColumn label="Marker" value="markerName"/>
                    </ExcelSheet>
                </ExcelFile>
            </div>
        )
    }
}

export default Excel;