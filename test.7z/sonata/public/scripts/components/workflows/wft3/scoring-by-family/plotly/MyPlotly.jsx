import React from 'react'
import Plotly from '../../../../../../../node_modules/react-plotly.js/react-plotly'

class MyPlotly extends React.Component{
    constructor(props){
        super(props);
        this.state = ({
            refresh: false
        })
    }

    componentDidMount(){
        this.setState({
            refresh: true
        })
    }

    render(){
        return(
            <Plotly
                data={this.props.data}
                layout={this.props.layout}
                frames={this.props.frames}
                config={this.props.config}
                useResizeHandler={true}
                style={{height:'100%', width:'100%'}}
                onSelected={(selectedPoints) => {
                    this.props.onPointsSelection(selectedPoints)
                }}
                onDeselect={() => {
                    this.props.onPointsDeselection();
                }}
            />)

    }
}

module.exports = MyPlotly;