import React from 'react';

import Table from "./Table"
import {$} from "../../../util/Ajaxsetup";
import urls from "../../../Urls";
import {toast} from "react-toastify";
import HtmlParser from "react-html-parser";
import AppUtil from "../../../util/AppUtil"

const cellInfoTblMapping = {
    "projectId":"Request ID",
    "wellName":"Well Name",
    "markerName": "Assay",
    "sampleId": "Sample Id",
    "roxIntensity": "Rox Intensity",
    "famIntensity": "Fam Intensity",
    "vicIntensity": "Vic Intensity"
};

class Grid extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            plateMapData: [],
            workflowType: props.workflowType, plateId: props.plateId, projectId: props.projectId,
            quad1Checkbox: true, quad2Checkbox: true, quad3Checkbox: true, quad4Checkbox: true, renderGrid: false, selectedCellValue: {},
            quadWellMapping: {}
        });
        this.getGridData = this.getGridData.bind(this);
    }

    componentDidMount(){
        this.getGridData();
    }

    getGridData(){
        const {plateId, projectId, workflowType} = this.state;
        $.ajax({
            url: urls.samplesForPlateRoute,
            contentType: 'application/json',
            data:JSON.stringify({projectId: projectId, plateId: plateId, workflowType: workflowType}),
            type:'POST',
            cache: true,
            success: function(data) {
                this.setState({
                    plateMapData: data.gMapList,
                    quadWellMapping: data.quadWellMapping,
                    renderGrid: true
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching samples. Please Check server logs !")
            }.bind(this)
        });
    }

    handleQuadChange(event){
        this.setState({
            ["quad"+event.target.value+"Checkbox"]: event.target.checked
        });
    }

    getQuadCheckboxes(){
        return (
            <div style={{border: "1px solid #e1e1e1", float: "right", padding:"1vh 1vh 1vh 1vh"}} >
                <label style={{margin: '0 1vh 0 0'}}>1 <input type={"checkbox"} defaultChecked={true} name={"quad1"} value={"1"} onChange={this.handleQuadChange.bind(this)}/></label>
                <label style={{margin: '0 0 0 1vh'}}><input type={"checkbox"} defaultChecked={true} name={"quad2"} value={"2"} onChange={this.handleQuadChange.bind(this)}/> 2</label>
                <br/>
                <label style={{margin: '1vh 1vh 0 0'}}>3 <input type={"checkbox"} defaultChecked={true} name={"quad3"} value={"3"} onChange={this.handleQuadChange.bind(this)}/></label>
                <label style={{margin: '1vh 0 0 1vh'}}><input type={"checkbox"} defaultChecked={true} name={"quad4"} value={"4"} onChange={this.handleQuadChange.bind(this)}/> 4</label>
            </div>
        );
    }

    getSelectedCellInfo(){
        const {selectedCellValue} = this.state;
        let table = "<div id='selected-sample-info' style='height: 35vh' class='container-fluid'>";
        let keys = Object.keys(selectedCellValue);
        for(let key in keys){
            let property = cellInfoTblMapping[keys[key]];
            if(typeof property !== 'undefined'){
                table += "<div class='row'>";
                table += "<div class='col-6 request-details-tbl-col'>"+ property+"</div>";
                table += "<div class='col-6 request-details-tbl-col'>"+selectedCellValue[keys[key]]+"</div>";
                table += "</div>";
            }
        }
        table += "</div>";
        return table;
    }

    buildRequestDetailsTable(){
        let table = "<div id='request-details-tbl' style='height: 35vh' class='container-fluid'>";
        let requestDetails = this.state.requestDetails;
        let keys = Object.keys(requestDetails);
        for(let key in keys){
            let property = cellInfoTblMapping[keys[key]];
            if(typeof property !== 'undefined'){
                table += "<div class='row'>";
                table += "<div class='col-6 '>"+ property+"</div>";
                table += "<div class='col-6 '>"+requestDetails[keys[key]]+"</div>";
                table += "</div>";
            }
        }
        table += "</div>";
        return table;
    }

    onCellClick(cellObj){
        this.setState({
            selectedCellValue: cellObj
        })
    }

    filterByQuad(){
        const {quad1Checkbox, quad2Checkbox, quad3Checkbox, quad4Checkbox, plateMapData, quadWellMapping} = this.state;
        let filteredPlateMapData = [];
        let quadList = [1,2,3,4];
        plateMapData.forEach((row) => {
            let validRowList = {};
            for(var q in quadList){
                if(eval("quad"+quadList[q]+"Checkbox")){
                    let quadWells = eval("quadWellMapping["+quadList[q]+"]");
                    for(var w in quadWells){
                        let d = row[quadWells[w]];
                        if(!AppUtil.checkUndefined(d) && !AppUtil.checkEmpty(d)) {
                            validRowList[quadWells[w]] = d;
                        }
                    }
                }
            }
            filteredPlateMapData.push(validRowList)
        });
        return filteredPlateMapData
    }

    getGrid(){
        let filteredPlateMapData = this.filterByQuad();
        return(
            <div>
                <Table x={24} y={16} cellWidth={"4%"} cellHeight={"2.5vh"} data={filteredPlateMapData} onCellClick={this.onCellClick.bind(this)}/>
            </div>
        )
    }

    render(){
        const { renderGrid, selectedCellValue} = this.state;
        let quadCheckboxes = this.getQuadCheckboxes();
        let selectedCellInfo = this.getSelectedCellInfo();
        let samplesGrid = renderGrid && this.getGrid();
        return (
            <div style={{borderBottom: "1px solid black" , margin: "1vh"}}>
                <div className={"container-fluid"}>
                    <div className={"row"}>
                        <div style={{width: '15%', borderRight: "1px solid #e1e1e1"}}>
                            <div className={"row"}>
                                <div className={"col"}>Select Quadrant(s) to view (384-well plate){quadCheckboxes}</div>
                            </div>
                            <div className={"row"}>
                                <div className={"col"}>
                                    <h6>Well Info ({this.props.plateId})</h6>
                                    <div >
                                        {HtmlParser(selectedCellInfo)}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style={{width: '85%', borderRight: "1px solid #e1e1e1"}}>
                            <div className={"container-fluid"}>
                                <div style={{overflowX: "scroll" , height: "50%"}}>
                                    {samplesGrid}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = Grid;