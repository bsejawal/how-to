import React from 'react';

import Layouts from '../scoring-by-plate/plotly/layouts'
import AppUtil from '../../../util/AppUtil'

const alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

class Cell extends React.Component {
    constructor(props) {
        super(props);
        this.prevent = false;
        this.cellValueObject = props.valueObj;
    }

    getCellValue ({ x, y, css }, valueObj){
        let cellValue = valueObj.call || '';
        // row 0
        if (y === 0) {
            cellValue = x;
        }
        // column 0
        else if (x === 0) {
            cellValue = alpha[this.props.y-1];
        }
        else if(x!==0 && y!==0) {
            if(!AppUtil.isNullAndUndefinedAndEmpty(css.backgroundColor)){
                css.color = 'white';
            }
            if(!AppUtil.isNullOrUndefinedOrEmpty(valueObj.control)){
                cellValue = valueObj.control;
            }
            css.backgroundColor = Layouts.colorConfigs[cellValue]
        }
        return cellValue;
    }

    calculateCss (){
        let css = {
            width: this.props.width,
            padding: '0.5vh 0 0 0',
            margin: '0',
            height: this.props.height,
            boxSizing: 'border-box',
            position: 'relative',
            display: 'inline-block',
            color: 'black',
            textAlign: 'left',
            verticalAlign: 'top',
            fontSize: 'x-small',
            lineHeight: '15px',
            overflow: 'hidden',
            wordWrap: 'break-word',
            fontFamily: 'Calibri, Segoe UI, Thonburi, Arial, Verdana, sans-serif',
        };

        if(this.props.x !== 0 && this.props.y !== 0 && this.props.selected){
            css.border = '2px dotted';
        }else {
            css.border = '1px solid #cacaca';
        }

        if (this.props.x === 0 || this.props.y === 0) {
            css.textAlign = 'center';
            css.backgroundColor = '#f0f0f5';
            css.fontWeight = 'bold';
            css.fontSize = 'medium';
        }
        return css;
    }

    render() {
        const {x,y,onClick, valueObj} = this.props;
        let css = this.calculateCss();
        let display = this.getCellValue({x: x, y: y, css: css}, valueObj);
        return (
            <div style={css} role="presentation" onClick={onClick.bind(this)}>
                {display}
            </div>
        )
    }
}

class Row extends React.Component{
    constructor(props) {
        super(props);
    }

    createCell(){
        const {y,rowData,onCellClick, selectedCell} = this.props;
        let cells = [];
        for (let x = 0; x < this.props.x + 1; x++) {
            let selected = false;
            let thisCellKey = `${x}-${y}`;
            if(selectedCell.key === thisCellKey)
                selected = true;
            let valueObj = rowData[alpha[y-1]+x.toLocaleString('en-US', {minimumIntegerDigits: 2, useGrouping:false})] || {};
            cells.push(
                <Cell
                    selected={selected}
                    key={thisCellKey}
                    y={y}
                    x={x}
                    valueObj={valueObj}
                    onClick={onCellClick.bind(this, valueObj,x,y)}
                    height={this.props.cellHeight}
                    width={this.props.cellWidth}
                />
            )
        }
        return cells;
    }

    render(){
        let cells = this.createCell();
        return (
            <div >
                {cells}
            </div>
        )
    }
}

class Table extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {},
        };
        this.selectedCell = {};
    }

    onCellClick(valueObj,x,y){
        this.selectedCell = {x: x, y: y, key: `${x}-${y}`};
        this.props.onCellClick(valueObj);
    }

    render() {
        const rows = [];
        let x = this.props.x;
        for (let y = 0; y < this.props.y + 1; y++) {
            rows.push(
                <Row
                    key={y}
                    x={x}
                    y={y}
                    rowData={this.props.data[y-1] || {}}
                    onCellClick={this.onCellClick.bind(this)}
                    selectedCell={this.selectedCell}
                    cellHeight={this.props.cellHeight}
                    cellWidth={this.props.cellWidth}
                />
            )
        }
        return (
            <div >
                {rows}
            </div>
        )
    }
}


module.exports = Table;