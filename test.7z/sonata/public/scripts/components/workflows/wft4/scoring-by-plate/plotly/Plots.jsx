import React from 'react';
import Plotly from '../../../../../../../node_modules/react-plotly.js/react-plotly'
import plotlyIcons from './Plotly-icons'
import PlotExport from './PlotExport'
import Modal from 'react-awesome-modal';
import $ from 'jquery'
import PlotsLayouts from './layouts'
import {toast} from 'react-toastify'
import ProjectConstants from '../../../../util/ProjectConstants'
import SplittedScatterPlot from './SplittedScatterPlots'
import SelectedDataConfig from '../../../../config/workflows/wft1/SelectedDataConfig';
import {DataGrid} from "../../../../react-table/table/body/Page";
import PlateMapView from "../../PlateMap/GridWrapper";

const _ = require('underscore');

const urls = require('../../../../Urls');
const trace_types = ProjectConstants.trace_types;
const Layouts = PlotsLayouts.layouts;

class App extends React.Component {
    constructor(props) {
        super(props);
        let commonModeBarButtonsToAdd = {
            exportedSelected: {
                name: 'exportSelected',
                title: 'Export Selected',
                _this: this,
                icon: plotlyIcons.download,
                click: this.exportToExcel
            }
        };
        let scatterPlotModeBarButtonsToAdd = {
            maximize: {
                name: 'maximizeScatterPlot',
                title: 'Maximize Plot',
                _this: this,
                icon: plotlyIcons.expand,
                click: this.openModal.bind(this, 'maximizeScatterPlot')
            },
            splitScatterPlot: {
                name: 'splitScatterPlot',
                title: 'Split Plot',
                _this: this,
                icon: plotlyIcons.autoscale,
                click: this.openModal.bind(this, 'splitScatterPlot')
            },
            toggleHoverInfo: {
                name: 'toggleHoverInfo',
                title: 'Toggle HoverInfo',
                _this: this,
                icon: plotlyIcons.toggleHoverInfo,
                click: this.toggleHoverInfo.bind(this, 'showScatterPlotHoverInfo')
            },
            getPlateMapView: {
                name: 'plateMapView',
                title: 'Plate Map View',
                _this: this,
                icon: plotlyIcons.movie,
                click: this.openModal.bind(this, 'showPlateMapView')
            }
        };
        let sCurvePlotModeBarButtonsToAdd = {
            maximize: {
                name: 'maximizeSCurve',
                title: 'Maximize Plot',
                _this: this,
                icon: plotlyIcons.expand,
                click: this.openModal.bind(this, 'maximizeSCurvePlot')
            },
            toggleHoverInfo: {
                name: 'toggleHoverInfo',
                title: 'Toggle HoverInfo',
                _this: this,
                icon: plotlyIcons.toggleHoverInfo,
                click: this.toggleHoverInfo.bind(this, 'showScurveHoverInfo')
            }
        };
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(commonModeBarButtonsToAdd.exportedSelected);
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(scatterPlotModeBarButtonsToAdd.splitScatterPlot);
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(scatterPlotModeBarButtonsToAdd.toggleHoverInfo);
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(scatterPlotModeBarButtonsToAdd.getPlateMapView);
        Layouts.sCurve.config.modeBarButtonsToAdd.push(commonModeBarButtonsToAdd.exportedSelected);
        Layouts.sCurve.config.modeBarButtonsToAdd.push(sCurvePlotModeBarButtonsToAdd.toggleHoverInfo);
        this.state = ({
            plotsDiv: {},
            openDownload: false,
            openAssignCall:false,
            maximizeScatterPlot:false,
            splitScatterPlot: false,
            maximizeSCurvePlot:false,
            selectedData: [],
            sCurveData: [],
            vicScatterPlotSelectedPoints : [],
            famScatterPlotSelectedPoints : [],
            hemiScatterPlotSelectedPoints : [],
            failScatterPlotSelectedPoints : [],
            negScatterPlotSelectedPoints : [],
            posScatterPlotSelectedPoints : [],
            tandemScatterPlotSelectedPoints : [],
            multicopyScatterPlotSelectedPoints : [],
            modeBarButtonsToAdd: {commonModeBarButtonsToAdd: commonModeBarButtonsToAdd, scatterPlotModeBarButtonsToAdd: scatterPlotModeBarButtonsToAdd,
                sCurvePlotModeBarButtonsToAdd: sCurvePlotModeBarButtonsToAdd},
            scatterPlotLayouts: Layouts.scatterPlot,
            scurveLayouts: Layouts.sCurve,
            splittedScatterPlotLayouts: Layouts.splittedScatterPlot,
            appCode: ProjectConstants["app-codes"].SELECTED_DATA_BY_PLATE_WFT1,
            showScatterPlotHoverInfo: true,
            showScurveHoverInfo: true,
            showPlateMapView: false
        });
        this.onPointsSelection = this.onPointsSelection.bind(this);
        this.onPointsDeselection = this.onPointsDeselection.bind(this);
        this.exportToExcel = this.exportToExcel.bind(this);
        this.attachKeyDownEventToDomForShortCutKeys = this.attachKeyDownEventToDomForShortCutKeys.bind(this);
        this.updatePredictedCall = this.updatePredictedCall.bind(this);
        this.prepareText = this.prepareText.bind(this);
        this.resetScatterPlotSelectedPoints = this.resetScatterPlotSelectedPoints.bind(this);
        toast.configure({
            pauseOnFocusLoss: false
        });
    }

    componentDidMount(){
        this.attachKeyDownEventToDomForShortCutKeys();
    }

    openPlateMapView(){
        let selectedRows = this.props.selectedRows;
        for(var key in selectedRows){
            let row = selectedRows[key];
            window.open('/smad-web/plate-map-view/'+this.props.projectId+'/'+row.data.plateId+'/'+this.props.workflowType, '_blank');
        }
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    exportToExcel() {
        if(this._this.state.selectedData.length > 0){
            this._this.openModal('openDownload');
        }else{
            toast.error("No Data Selected");
        }

    };

    toggleHoverInfo(type){
        let currentHoverInfoState = this.state[type];
        this.setState({ [type]: !currentHoverInfoState })
    }

    attachKeyDownEventToDomForShortCutKeys(){
        let _this = this;
        let plotsDiv = document.getElementById("plots-by-plate");
        plotsDiv.addEventListener('keydown', function(event){
            if(event.keyCode === 65){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.hom_fam, _this.state.selectedData);
            }else if(event.keyCode === 83){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.hemi, _this.state.selectedData);
            }else if(event.keyCode === 68){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.hom_vic, _this.state.selectedData);
            }else if(event.keyCode === 32){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.fail, _this.state.selectedData);
            }else if(event.keyCode === 84){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.tandem, _this.state.selectedData);
            }else if(event.keyCode === 77){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.multicopy, _this.state.selectedData);
            }
        });
        this.setState({
            plotsDiv: plotsDiv
        })
    }

    updatePredictedCall(predictedCallType, selectedData){
        this.closeModal("openAssignCall");
        let _this = this;
        $.ajax({
            url: urls.updatePredictedCallRoute,
            contentType: 'application/json',
            data: JSON.stringify({userId: this.props.currentUser.id, selectedData: selectedData, predictedCallType: predictedCallType, projectId: this.props.projectId }),
            type:"POST",
            cache: true,
            success: function(data) {
                this.props.reloadData(data, function(){
                    _this.resetScatterPlotSelectedPoints(function(){
                        _this.onPointsDeselection();
                    }());
                }());
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured. Cause :: "+err);
            }.bind(this)
        })
    }

    resetScatterPlotSelectedPoints(){
        const {scatterPlotLayouts} = this.state;
        scatterPlotLayouts.data[0].selectedpoints = null;
        scatterPlotLayouts.data[1].selectedpoints = null;
        scatterPlotLayouts.data[2].selectedpoints = null;
        scatterPlotLayouts.data[3].selectedpoints = null;
        scatterPlotLayouts.data[5].selectedpoints = null;
        scatterPlotLayouts.data[6].selectedpoints = null;
    }

    resetScurvePlotSelectedPoints(){
        const {scurveLayouts} = this.state;
        scurveLayouts.data[0].selectedpoints = null;
        scurveLayouts.data[1].selectedpoints = null;
        scurveLayouts.data[2].selectedpoints = null;
        scurveLayouts.data[3].selectedpoints = null;
        scurveLayouts.data[5].selectedpoints = null;
        scurveLayouts.data[6].selectedpoints = null;
    }

    onPointsSelection(event) {
        this.state.plotsDiv.focus();
        let _selectedData = [];
        let vicScatterSelectedPoints = [];
        let famScatterSelectedPoints = [];
        let hemiScatterSelectedPoints = [];
        let failScatterSelectedPoints = [];
        let tandemScatterSelectedPoints = [];
        let multicopyScatterSelectedPoints = [];
        if(event && event.points){
            event.points.forEach(function(point){
                _selectedData.push(point.data.METADATA[point.pointIndex]);
                if(point.data.name === trace_types.hom_fam)
                    famScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.hom_vic)
                    vicScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.hemi)
                    hemiScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.fail)
                    failScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.tandem)
                    tandemScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.multicopy)
                    multicopyScatterSelectedPoints.push(point.pointIndex);
            });
        }

        this.setState({
            selectedData: _selectedData,
            vicScatterPlotSelectedPoints: vicScatterSelectedPoints,
            famScatterPlotSelectedPoints: famScatterSelectedPoints,
            hemiScatterPlotSelectedPoints: hemiScatterSelectedPoints,
            failScatterPlotSelectedPoints: failScatterSelectedPoints,
            tandemScatterPlotSelectedPoints: tandemScatterSelectedPoints,
            multicopyScatterPlotSelectedPoints: multicopyScatterSelectedPoints
        }, () => {
            if(event && event.lassoPoints)
                this.openModal('openAssignCall');
        })
    }

    onPointsDeselection(){
        this.setState({
            selectedData: [],
            vicScatterPlotSelectedPoints: [],
            famScatterPlotSelectedPoints: [],
            hemiScatterPlotSelectedPoints: [],
            failScatterPlotSelectedPoints: [],
            tandemScatterPlotSelectedPoints: [],
            multicopyScatterPlotSelectedPoints: []
        })
    }

    prepareText(wellInfo){
        let info = "Well: "+wellInfo.wellName+"</br>";
        info += "Name: "+wellInfo.sampleName+"</br>";
        info += "Type: "+wellInfo.sampleClass+"</br>";
        info += "ROX: "+wellInfo.roxIntensity+"</br>";
        info += "VIC: "+wellInfo.vicIntensity+"</br>";
        info += "FAM: "+wellInfo.famIntensity+"</br>";
        info += "Call: "+wellInfo.predictedCall+"</br>";
        info += "Probability: "+wellInfo.maxProbability;
        return info;
    }

    initializePoints(scatterPlotData, sCurveData, showScatterPlotHoverInfo, showScurveHoverInfo){
        this.initializeDataPoints(scatterPlotData, sCurveData);
        this.toggleScatterPlotHoverInfo(showScatterPlotHoverInfo, scatterPlotData);
        this.toggleScurveHoverInfo(showScurveHoverInfo, sCurveData)
    }

    initializeDataPoints(scatterPlotData, sCurveData){
        const { famScatterPlotSelectedPoints, vicScatterPlotSelectedPoints, hemiScatterPlotSelectedPoints, failScatterPlotSelectedPoints, scurveLayouts,
            tandemScatterPlotSelectedPoints, multicopyScatterPlotSelectedPoints} = this.state;
        _.extend(scatterPlotData[0], this.props.scatterPlotGraphData.hom_fam);
        _.extend(scatterPlotData[0].marker.opacity, this.props.scatterPlotGraphData.hom_fam.opacity);
        _.extend(scatterPlotData[1], this.props.scatterPlotGraphData.hom_vic);
        _.extend(scatterPlotData[1].marker.opacity, this.props.scatterPlotGraphData.hom_vic.opacity);
        _.extend(scatterPlotData[2], this.props.scatterPlotGraphData.hemi);
        _.extend(scatterPlotData[2].marker.opacity, this.props.scatterPlotGraphData.hemi.opacity);
        _.extend(scatterPlotData[3], this.props.scatterPlotGraphData.fail);
        _.extend(scatterPlotData[3].marker.opacity, this.props.scatterPlotGraphData.fail.opacity);
        _.extend(scatterPlotData[5], this.props.scatterPlotGraphData.tandem);
        _.extend(scatterPlotData[5].marker.opacity, this.props.scatterPlotGraphData.tandem.opacity);
        _.extend(scatterPlotData[6], this.props.scatterPlotGraphData.multicopy);
        _.extend(scatterPlotData[6].marker.opacity, this.props.scatterPlotGraphData.multicopy.opacity);
        _.extend(scatterPlotData[4], this.props.scatterPlotGraphData.standardControl);

        /* this is for auto selection of points in s-curve whenever data is selecetd in scatter plot */
        scurveLayouts.data[0].selectedpoints = famScatterPlotSelectedPoints.length > 0 ? famScatterPlotSelectedPoints : ((vicScatterPlotSelectedPoints.length > 0 || hemiScatterPlotSelectedPoints.length > 0 || failScatterPlotSelectedPoints.length) > 0 || tandemScatterPlotSelectedPoints.length > 0 || multicopyScatterPlotSelectedPoints.length > 0 ? [] : null);
        scurveLayouts.data[1].selectedpoints = vicScatterPlotSelectedPoints.length > 0 ? vicScatterPlotSelectedPoints : ((famScatterPlotSelectedPoints.length > 0 || hemiScatterPlotSelectedPoints.length > 0 || failScatterPlotSelectedPoints.length) > 0 || tandemScatterPlotSelectedPoints.length > 0 || multicopyScatterPlotSelectedPoints.length > 0 ? [] : null);
        scurveLayouts.data[2].selectedpoints = hemiScatterPlotSelectedPoints.length > 0 ? hemiScatterPlotSelectedPoints : ((vicScatterPlotSelectedPoints.length > 0 || famScatterPlotSelectedPoints.length > 0 || failScatterPlotSelectedPoints.length) > 0 || tandemScatterPlotSelectedPoints.length > 0 || multicopyScatterPlotSelectedPoints.length > 0 ? [] : null);
        scurveLayouts.data[3].selectedpoints = failScatterPlotSelectedPoints.length > 0 ? failScatterPlotSelectedPoints : ((vicScatterPlotSelectedPoints.length > 0 || hemiScatterPlotSelectedPoints.length > 0 || famScatterPlotSelectedPoints.length) > 0 || tandemScatterPlotSelectedPoints.length > 0 || multicopyScatterPlotSelectedPoints.length > 0 ? [] : null);
        scurveLayouts.data[5].selectedpoints = tandemScatterPlotSelectedPoints.length > 0 ? tandemScatterPlotSelectedPoints : ((vicScatterPlotSelectedPoints.length > 0 || hemiScatterPlotSelectedPoints.length > 0 || famScatterPlotSelectedPoints.length) > 0 || failScatterPlotSelectedPoints.length > 0 || multicopyScatterPlotSelectedPoints.length > 0 ? [] : null);
        scurveLayouts.data[6].selectedpoints = multicopyScatterPlotSelectedPoints.length > 0 ? multicopyScatterPlotSelectedPoints : ((vicScatterPlotSelectedPoints.length > 0 || hemiScatterPlotSelectedPoints.length > 0 || famScatterPlotSelectedPoints.length) > 0 || failScatterPlotSelectedPoints.length > 0 || tandemScatterPlotSelectedPoints.length > 0 ? [] : null);

        _.extend(sCurveData[0], this.props.sCurveGraphData.hom_fam);
        _.extend(sCurveData[0].marker.opacity, this.props.sCurveGraphData.hom_fam.opacity);
        _.extend(sCurveData[1], this.props.sCurveGraphData.hom_vic);
        _.extend(sCurveData[1].marker.opacity, this.props.sCurveGraphData.hom_vic.opacity);
        _.extend(sCurveData[2], this.props.sCurveGraphData.hemi);
        _.extend(sCurveData[2].marker.opacity, this.props.sCurveGraphData.hemi.opacity);
        _.extend(sCurveData[3], this.props.sCurveGraphData.fail);
        _.extend(sCurveData[3].marker.opacity, this.props.sCurveGraphData.fail.opacity);
        _.extend(sCurveData[5], this.props.sCurveGraphData.tandem);
        _.extend(sCurveData[5].marker.opacity, this.props.sCurveGraphData.tandem.opacity);
        _.extend(sCurveData[6], this.props.sCurveGraphData.multicopy);
        _.extend(sCurveData[6].marker.opacity, this.props.sCurveGraphData.multicopy.opacity);
        _.extend(sCurveData[4], this.props.sCurveGraphData.standardControl);
    }

    toggleScatterPlotHoverInfo(showHoverInfo, scatterPlotGraphData){
        let hoverInfo = "text";
        if(!showHoverInfo) hoverInfo = "none";
        let numberOfCalls = 6;
        for(var i = 0; i < numberOfCalls; i++){
            scatterPlotGraphData[i].hoverinfo = hoverInfo;
        }
    }

    toggleScurveHoverInfo(showHoverInfo, sCurveGraphData){
        let hoverInfo = "text";
        if(!showHoverInfo) hoverInfo = "none";
        let numberOfCalls = 6;
        for(var i = 0; i < numberOfCalls; i++){
            sCurveGraphData[i].hoverinfo = hoverInfo;
        }
    }

    customizeScatterPlotForMaximizing(){
        const {maximizeScatterPlot, modeBarButtonsToAdd, scatterPlotLayouts } = this.state;
        let name = modeBarButtonsToAdd.scatterPlotModeBarButtonsToAdd.maximize.name;
        if(maximizeScatterPlot){
            this.removeFromObjArray(scatterPlotLayouts.config.modeBarButtonsToAdd,"name",name);
        }else{
            if (scatterPlotLayouts.config.modeBarButtonsToAdd.findIndex(o => o.name === name) < 1){
                scatterPlotLayouts.config.modeBarButtonsToAdd.push(modeBarButtonsToAdd.scatterPlotModeBarButtonsToAdd.maximize);
            }
        }
    }

    customizeSCurvePlotForMaximizing(){
        const {maximizeSCurvePlot, modeBarButtonsToAdd, scurveLayouts } = this.state;
        let name = modeBarButtonsToAdd.sCurvePlotModeBarButtonsToAdd.maximize.name;
        if(maximizeSCurvePlot){
            this.removeFromArray(scurveLayouts.config.modeBarButtonsToAdd,name);
        }else{
            if (scurveLayouts.config.modeBarButtonsToAdd.findIndex(o => o.name === name) < 1){
                scurveLayouts.config.modeBarButtonsToAdd.push(modeBarButtonsToAdd.sCurvePlotModeBarButtonsToAdd.maximize);
            }
        }
    }

    removeFromObjArray(arr, prop, value){
        let index = arr.findIndex(obj => obj[prop] === value);
        if(index > 0){
            arr.splice(index, 1);
        }
    }

    removeFromArray(arr, value){
        let index = arr.findIndex(i => arr[i] === value);
        if(index > 0){
            arr.splice(index, 1);
        }
    }

    prepareInfoFromSelectedDataWhenAssignCall(appCode, selectedData){
        let data = selectedData.map(function(obj){
            return {wellName: obj.wellName, sampleId: obj.sampleId, predictedCall: obj.predictedCall}
        });
        return (
            <DataGrid
                gridId={"selectedDataByPlate"}
                appCode={appCode}
                fixedHeight={30}
                resultsPerPage={500}
                showAllData={true}
                showAllTools={false}
                masterSearch={false}
                // onRowClick={this.onRowClick}
                showCheckBox={true}
                showCheckAllCheckbox={false}
                config={SelectedDataConfig}
                //colorConfig={colorConfig}
                // customCellFormatters={customCellFormatters}
                data={data}
                // heading={"Score Marker Assay Data"}
                // refreshData={this.fetchData}
                settingOptions={false}
                filterOptions={false}
                indexColumn={""}
            />
        );

    }

    render() {
        const { openDownload, openAssignCall, selectedData, maximizeScatterPlot, maximizeSCurvePlot, splitScatterPlot, scurveLayouts,
            scatterPlotLayouts, appCode, showScatterPlotHoverInfo, showScurveHoverInfo, showPlateMapView } = this.state;
        const {scatterPlotGraphData, currentUser, reloadData, scatterPlotDataByPlate, projectType, labCode} = this.props;
        let scatterPlotData = Object.assign([], scatterPlotLayouts.data);
        let sCurveData = Object.assign([], scurveLayouts.data);
        let layout = Object.assign({},scatterPlotLayouts.layout);
        layout.xaxis.title = "Vic ("+ scatterPlotGraphData["vic_allele"] +")";
        layout.yaxis.title = "Fam ("+ scatterPlotGraphData["fam_allele"] +")";
        this.initializePoints(scatterPlotData, sCurveData, showScatterPlotHoverInfo, showScurveHoverInfo);
        this.customizeScatterPlotForMaximizing();
        this.customizeSCurvePlotForMaximizing();
        let selectedRows = this.props.selectedRows;
        let plateIds = [];
        for(var key in selectedRows){
            plateIds.push(selectedRows[key].data.plateId);
        }
        let scatterPlot = (
            <Plotly
                divId={"mainScatterPlotByPlate"}
                data={scatterPlotData}
                layout={layout}
                frames={scatterPlotLayouts.frames}
                config={scatterPlotLayouts.config}
                useResizeHandler={true}
                style={{height:'100%', width:'100%'}}
                onSelected={(selectedPoints) => {
                    this.onPointsSelection(selectedPoints)
                }}
                onDeselect={() => {
                    this.onPointsDeselection();
                }}
            />
        );
        let scurve = (
            <Plotly
                divId={"mainSCurveByPlate"}
                data={sCurveData}
                layout={scurveLayouts.layout}
                frames={scurveLayouts.frames}
                config={scurveLayouts.config}
                useResizeHandler={true}
                style={{height:'100%', width:'100%'}}
                onSelected={(selectedPoints) => {
                    this.onPointsSelection(selectedPoints)
                }}
                onDeselect={() => {
                    this.onPointsDeselection();
                }}
            />
        );

        let assignCall;
        assignCall = (
            <div className={"container-fluid"}>
                <div className={"row"}>
                    <div className={"col-4"}>
                        <div style={{margin: "15% 0 0 20%"}}>
                            <h3>Assign Call</h3>
                            <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.hom_fam, selectedData)} value={trace_types.hom_fam}/> YY HOM FAM (A)<br/>
                            <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.hemi, selectedData)} value={trace_types.hemi}/> XY HEMI (S)<br/>
                            <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.hom_vic, selectedData)} value={trace_types.hom_vic}/> XX HOM VIC (D)<br/>
                            <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.fail, selectedData)} value={trace_types.fail}/> FAIL (SPACE)<br/>
                            <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.tandem, selectedData)} value={trace_types.tandem}/> TANDEM (T)<br/>
                            <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.multicopy, selectedData)} value={trace_types.multicopy}/> MULTICOPY (M)<br/>
                        </div>
                    </div>
                    <div className={"col-8"}>
                        {this.prepareInfoFromSelectedDataWhenAssignCall(appCode, selectedData)}
                    </div>
                </div>
            </div>
        );
        return (
            <div id="plot-row-by-plate" className={"outline0"}>
                {/* all modals */}
                <div>
                    <Modal visible={splitScatterPlot} width="1400" height="900" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'splitScatterPlot')}>
                        <SplittedScatterPlot currentUser={currentUser} splitScatterPlot={splitScatterPlot} reloadData={reloadData}
                                             scatterPlotDataByPlates={scatterPlotDataByPlate} projectId={this.props.projectId} workflowType={this.props.workflowType}
                                             updatePredictedCall={this.updatePredictedCall} projectType={projectType} labCode={labCode}
                        />
                    </Modal>
                    <Modal visible={maximizeScatterPlot} width="1400" height="900" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'maximizeScatterPlot')}>
                        {scatterPlot}
                    </Modal>
                    <Modal visible={maximizeSCurvePlot} width="1400" height="900" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'maximizeSCurvePlot')}>
                        {scurve}
                    </Modal>
                    <Modal visible={openAssignCall} width="800" height="400" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openAssignCall')}>
                        <div className="center-contents-div">
                            {assignCall}
                        </div>
                    </Modal>
                    <Modal visible={openDownload} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openDownload')}>
                        <div className="center-contents-div">
                            <PlotExport excelData={selectedData}/>
                        </div>
                    </Modal>
                    {showPlateMapView &&
                    <Modal visible={showPlateMapView} width="1500" height="900" effect="fadeInUp"
                           onClickAway={this.closeModal.bind(this, 'showPlateMapView')}>
                        <PlateMapView projectId={this.props.projectId} plateIds={plateIds}
                                      workflowType={this.props.workflowType}/>
                    </Modal>
                    }
                </div>
                <div>
                    <div style={{height:'42vh', width:'55vh'}}>
                        {scatterPlot}
                    </div>
                    <div style={{height:'42vh', width:'55vh'}}>
                        {scurve}
                    </div>
                </div>
            </div>
        );
    }
}

module.exports = App;