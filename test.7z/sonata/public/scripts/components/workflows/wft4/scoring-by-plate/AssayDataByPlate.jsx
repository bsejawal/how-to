import React from 'react';
import {$, DataGrid} from '../../../react-table/table/body/Page.js';
import Plots from './plotly/Plots'
import {connect} from 'react-redux'
import _ from 'underscore'
import Modal from 'react-awesome-modal';
import {toast, ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import SubmitRedo from '../../../SubmitRedo'
import DeliverRequest from '../DeliverRequest'
import Select from 'react-select'
// import RequestDetails from "../plotly/RequestDetails";
// import EventSource from 'eventsource'
import ProjectConstants from '../../../util/ProjectConstants'
import {colorConfigs} from './plotly/layouts'
import orderby from 'lodash.orderby';

import urls from '../../../Urls';
import Notes from "../../../Notes";

const Config = require ('../../../config/workflows/wft4/AssayDataByPlateConfig');

const trace_types = ProjectConstants.trace_types;
// const STRD_CTRL_FONT_COLOR = {"S1":"#9467bd","S2":"#FF5733","S3":"FF5233","S4":"","S5":"","S6":"","Z":"","E":""};


class AssayDataByPlate extends React.Component {
    constructor(props) {
        super(props);
        this.fetchData = this.fetchData.bind(this);
        this.fetchConfig = this.fetchConfig.bind(this);
        this.onRowClick = this.onRowClick.bind(this);
        this.getNormalizedIntensities = this.getNormalizedIntensities.bind(this);
        this.setWellData = this.setWellData.bind(this);
        this.reloadData = this.reloadData.bind(this);
        this.submitRedo = this.submitRedo.bind(this);
        this.deliverRequest = this.deliverRequest.bind(this);
        this.state = { projectId: this.props.match.params.requestId, projectType:"", labCode: "", workflowType: this.props.match.params.wf,
            data: [], requestDetails: {}, notificationMessage: "",
            scatterPlotData: {hom_fam:{}, hom_vic:{}, hemi: {}, fail:{}, pos: {}, neg: {}, tandem: {}, multicopy: {}, vic_allele: "", fam_allele : ""},
            sCurvePlotData: {hom_fam:{}, hom_vic:{}, hemi: {}, fail:{}, pos: {}, neg: {}, tandem: {}, multicopy: {}},
            wellsData: {},
            gridConfig : [], renderGrid: false, selectedRows: {}, appCode:ProjectConstants["app-codes"].ASSAY_DATA_BY_PLATE_WFT4,
            openSubmitRedoModal: false,openDeliverRequestModal: false, statusInfo_redo: [], statusInfo_okay: [], statusInfo_drop: [],
            statusInfo_selectedDefault:{},statusInfo_selected:{}, totalPlates:0, statusCounts:{}, currentUser: {}, statusOptions: [],
            statusObjs: {}, scatterPlotDataByPlate: {}, recentSelectedStatus: {}
        };
        this.modifiedNotes = {};
    }

    componentDidMount() {
        this.startListeningToNewArrivals();
        $.ajax({
            url: urls.getStatusListRoute,
            contentType: 'application/json',
            data:JSON.stringify({"applicationCode": "assay-data", "dropdownCode": "status", "projectId": this.state.projectId}),
            type:'POST',
            cache: true,
            success: function(data) {
                let statusObject = this.prepareStatus(data);
                this.setState({
                    statusOptions: statusObject.statusOptions,
                    statusObjs: statusObject.statusObjs
                }, () => this.fetchData() )
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching data from api !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    reloadPage(){
        window.location.reload(true);
    }

    createNewArrivalsNotificationDiv(){
        return (
            <div>New plates arrived for this Project. Would you like to reload page? <button className={"button"} onClick={this.reloadPage}>Reload</button></div>
        )
    }

    startListeningToNewArrivals(){
        // let _this = this;
        // var eventSource = new EventSource(urls.listenerUrl);
        // eventSource.addEventListener(this.state.projectId, function(e) {
        //     toast.success(({ closeToast }) => _this.createNewArrivalsNotificationDiv());
        // });
    }

    onRowClick(event, data, rowId){
        let normalizedFAMIntensity_HOM_VIC = [];
        let normalizedFAMIntensity_HOM_FAM = [];
        let normalizedFAMIntensity_HEMI = [];
        let normalizedFAMIntensity_FAIL = [];
        let normalizedFAMIntensity_TANDEM = [];
        let normalizedFAMIntensity_MULTICOPY = [];

        let normalizedVICIntensity_HOM_VIC = [];
        let normalizedVICIntensity_HOM_FAM = [];
        let normalizedVICIntensity_HEMI = [];
        let normalizedVICIntensity_FAIL = [];
        let normalizedVICIntensity_TANDEM = [];
        let normalizedVICIntensity_MULTICOPY = [];

        let standardControlFAM = [];
        let standardControlVIC = [];
        let standardControlVicByFam = [];

        let normalized_HOM_VIC_metadata = [];
        let normalized_HOM_FAM_metadata = [];
        let normalized_HEMI_metadata = [];
        let normalized_FAIL_metadata = [];
        let normalized_TANDEM_metadata = [];
        let normalized_MULTICOPY_metadata = [];
        let standardControl_metadata = [];

        let standardControl_text = [];
        let standardControl_text_fontColor = [];

        let hom_fam_hoverText = [];
        let hom_vic_hoverText = [];
        let hemi_hoverText = [];
        let fail_hoverText = [];
        let tandem_hoverText = [];
        let multicopy_hoverText = [];
        let standardControl_hoverText = [];

        // for s-curve
        let normalizedVicByFamIntensity_HOM_VIC = [];
        let normalizedVicByFamIntensity_HOM_FAM = [];
        let normalizedVicByFamIntensity_HEMI = [];
        let normalizedVicByFamIntensity_FAIL = [];
        let normalizedVicByFamIntensity_TANDEM = [];
        let normalizedVicByFamIntensity_MULTICOPY = [];

        let HOM_VIC_Range = [];
        let HOM_FAM_Range = [];
        let HEMI_RANGE = [];
        let FAIL_RANGE = [];
        let TANDEM_RANGE = [];
        let MULTICOPY_RANGE = [];
        let standardControlRange = [];

        let opacity_HOM_FAM = [];
        let opacity_HOM_VIC = [];
        let opacity_HEMI = [];
        let opacity_FAIL = [];
        let opacity_TANDEM = [];
        let opacity_MULTICOPY = [];

        let rows = data;

        let scatterPlotDataByPlate = {};
        let fam_allele = [];
        let vic_allele = [];
        let id = 1;
        for(let row in rows){
            let _data = rows[row]["data"];
            let _temp = this.getNormalizedIntensities(this.state.wellsData[row], row, _data["markerName"], id);
            typeof _data["famAllele"] === "undefined" || _data["famAllele"] === null ? _data["famAllele"] = "" : _data["famAllele"];
            typeof _data["vicAllele"] === "undefined" || _data["vicAllele"] === null ? _data["vicAllele"] = "" : _data["vicAllele"];
            fam_allele.push(_data["famAllele"]);
            vic_allele.push(_data["vicAllele"]);
            normalizedFAMIntensity_HOM_FAM.push(..._temp.fam_hom_fam);
            normalizedFAMIntensity_HOM_VIC.push(..._temp.fam_hom_vic);
            normalizedFAMIntensity_HEMI.push(..._temp.fam_hemi);
            normalizedFAMIntensity_FAIL.push(..._temp.fam_fail);
            normalizedFAMIntensity_TANDEM.push(..._temp.fam_tandem);
            normalizedFAMIntensity_MULTICOPY.push(..._temp.fam_multicopy);

            normalizedVICIntensity_HOM_FAM.push(..._temp.vic_hom_fam);
            normalizedVICIntensity_HOM_VIC.push(..._temp.vic_hom_vic);
            normalizedVICIntensity_HEMI.push(..._temp.vic_hemi);
            normalizedVICIntensity_FAIL.push(..._temp.vic_fail);
            normalizedVICIntensity_TANDEM.push(..._temp.vic_tandem);
            normalizedVICIntensity_MULTICOPY.push(..._temp.vic_multicopy);

            standardControlVIC.push(..._temp.standardControl_vic);
            standardControlFAM.push(..._temp.standardControl_fam);

            standardControlVicByFam.push(..._temp.standardControlVicByFam);

            normalizedVicByFamIntensity_HOM_FAM.push(..._temp.vicByFam_hom_fam);
            normalizedVicByFamIntensity_HOM_VIC.push(..._temp.vicByFam_hom_vic);
            normalizedVicByFamIntensity_HEMI.push(..._temp.vicByFam_hemi);
            normalizedVicByFamIntensity_FAIL.push(..._temp.vicByFam_fail);
            normalizedVicByFamIntensity_TANDEM.push(..._temp.vicByFam_tandem);
            normalizedVicByFamIntensity_MULTICOPY.push(..._temp.vicByFam_multicopy);

            HOM_VIC_Range.push(..._temp.hom_vic_range);
            HOM_FAM_Range.push(..._temp.hom_fam_range);
            HEMI_RANGE.push(..._temp.hemi_range);
            FAIL_RANGE.push(..._temp.fail_range);
            TANDEM_RANGE.push(..._temp.tandem_range);
            MULTICOPY_RANGE.push(..._temp.multicopy_range);
            standardControlRange.push(..._temp.standardControlRange);

            normalized_HOM_FAM_metadata.push(..._temp.hom_fam_metadata);
            normalized_HOM_VIC_metadata.push(..._temp.hom_vic_metadata);
            normalized_HEMI_metadata.push(..._temp.hemi_metadata);
            normalized_FAIL_metadata.push(..._temp.fail_metadata);
            normalized_TANDEM_metadata.push(..._temp.tandem_metadata);
            normalized_MULTICOPY_metadata.push(..._temp.multicopy_metadata);
            standardControl_metadata.push(..._temp.standardControl_metadata);

            standardControl_text.push(..._temp.standardControl_text);
            standardControl_text_fontColor.push(..._temp.standardControl_text_fontColor);

            hom_fam_hoverText.push(..._temp.hom_fam_hoverText);
            hom_vic_hoverText.push(..._temp.hom_vic_hoverText);
            hemi_hoverText.push(..._temp.hemi_hoverText);
            fail_hoverText.push(..._temp.fail_hoverText);
            tandem_hoverText.push(..._temp.tandem_hoverText);
            multicopy_hoverText.push(..._temp.multicopy_hoverText);
            standardControl_hoverText.push(..._temp.standardControl_hoverText);

            opacity_HOM_VIC.push(..._temp.opacity_hom_vic);
            opacity_HOM_FAM.push(..._temp.opacity_hom_fam);
            opacity_HEMI.push(..._temp.opacity_hemi);
            opacity_FAIL.push(..._temp.opacity_fail);
            opacity_TANDEM.push(..._temp.opacity_tandem);
            opacity_MULTICOPY.push(..._temp.opacity_multicopy);

            scatterPlotDataByPlate[row] = {
                hom_fam: {marker: {opacity: _temp.opacity_hom_fam}, x: _temp.vic_hom_fam, y: _temp.fam_hom_fam, METADATA: _temp.hom_fam_metadata, hovertext: _temp.hom_fam_hoverText, opacity: _temp.opacity_hom_fam},
                hom_vic: {marker: {opacity: _temp.opacity_hom_vic}, x: _temp.vic_hom_vic, y: _temp.fam_hom_vic, METADATA: _temp.hom_vic_metadata, hovertext: _temp.hom_vic_hoverText, opacity: _temp.opacity_hom_vic},
                hemi: {marker: {opacity: _temp.opacity_hemi}, x: _temp.vic_hemi, y: _temp.fam_hemi, METADATA: _temp.hemi_metadata, hovertext: _temp.hemi_hoverText, opacity: _temp.opacity_hemi},
                fail: {marker: {opacity: _temp.opacity_fail}, x: _temp.vic_fail, y: _temp.fam_fail, METADATA: _temp.fail_metadata, hovertext: _temp.fail_hoverText, opacity: _temp.opacity_fail},
                tandem: {marker: {opacity: _temp.opacity_tandem}, x: _temp.vic_tandem, y: _temp.fam_tandem, METADATA: _temp.tandem_metadata, hovertext: _temp.tandem_hoverText, opacity: _temp.opacity_tandem},
                multicopy: {marker: {opacity: _temp.opacity_multicopy}, x: _temp.vic_multicopy, y: _temp.fam_multicopy, METADATA: _temp.multicopy_metadata, hovertext: _temp.multicopy_hoverText, opacity: _temp.opacity_multicopy},
                standardControl: {x: _temp.standardControl_vic, y: _temp.standardControl_fam, METADATA: _temp.standardControl_metadata, hovertext: _temp.standardControl_hoverText, text: _temp.standardControl_text,
                    textfont: { size: 17, color: _temp.standardControl_text_fontColor }
                },
                range_x_lower: _temp.vic_lower_range, range_x_upper: _temp.vic_upper_range, range_y_lower: _temp.fam_lower_range, range_y_upper: _temp.fam_upper_range,
                ids: _temp.ids,
                fam_allele: _data["famAllele"], vic_allele: _data["vicAllele"]
            }
            id=+_temp.ids[_temp.ids.length-1]+1;
        }

        this.setState({
            scatterPlotData: {
                hom_fam: {x: normalizedVICIntensity_HOM_FAM, y: normalizedFAMIntensity_HOM_FAM, METADATA: normalized_HOM_FAM_metadata, hovertext: hom_fam_hoverText, opacity: opacity_HOM_FAM},
                hom_vic: {x: normalizedVICIntensity_HOM_VIC, y: normalizedFAMIntensity_HOM_VIC, METADATA: normalized_HOM_VIC_metadata, hovertext: hom_vic_hoverText, opacity: opacity_HOM_VIC},
                hemi: {x: normalizedVICIntensity_HEMI, y: normalizedFAMIntensity_HEMI, METADATA: normalized_HEMI_metadata, hovertext: hemi_hoverText, opacity: opacity_HEMI},
                fail: {x: normalizedVICIntensity_FAIL, y: normalizedFAMIntensity_FAIL, METADATA: normalized_FAIL_metadata, hovertext: fail_hoverText, opacity: opacity_FAIL},
                tandem: {x: normalizedVICIntensity_TANDEM, y: normalizedFAMIntensity_TANDEM, METADATA: normalized_TANDEM_metadata, hovertext: tandem_hoverText, opacity: opacity_TANDEM},
                multicopy: {x: normalizedVICIntensity_MULTICOPY, y: normalizedFAMIntensity_MULTICOPY, METADATA: normalized_MULTICOPY_metadata, hovertext: multicopy_hoverText, opacity: opacity_MULTICOPY},
                standardControl: {x: standardControlVIC, y: standardControlFAM, METADATA: standardControl_metadata, hovertext: standardControl_hoverText, text: standardControl_text,
                    textfont: { size: 17, color: standardControl_text_fontColor }
                },
                fam_allele: fam_allele.join(","), vic_allele: vic_allele.join(",")
            },
            sCurvePlotData: {
                hom_fam: {x: HOM_FAM_Range, y: normalizedVicByFamIntensity_HOM_FAM, METADATA: normalized_HOM_FAM_metadata, hovertext: hom_fam_hoverText, opacity: opacity_HOM_FAM },
                hom_vic: {x: HOM_VIC_Range, y: normalizedVicByFamIntensity_HOM_VIC, METADATA: normalized_HOM_VIC_metadata, hovertext: hom_vic_hoverText, opacity: opacity_HOM_VIC },
                hemi: { x: HEMI_RANGE, y: normalizedVicByFamIntensity_HEMI,  METADATA: normalized_HEMI_metadata, hovertext: hemi_hoverText, opacity: opacity_HEMI },
                fail: { x: FAIL_RANGE, y: normalizedVicByFamIntensity_FAIL, METADATA: normalized_FAIL_metadata, hovertext: fail_hoverText, opacity: opacity_FAIL },
                tandem: { x: TANDEM_RANGE, y: normalizedVicByFamIntensity_TANDEM, METADATA: normalized_TANDEM_metadata, hovertext: tandem_hoverText, opacity: opacity_TANDEM },
                multicopy: { x: MULTICOPY_RANGE, y: normalizedVicByFamIntensity_MULTICOPY, METADATA: normalized_MULTICOPY_metadata, hovertext: multicopy_hoverText, opacity: opacity_MULTICOPY },
                standardControl: {x: standardControlRange, y: standardControlVicByFam, METADATA: standardControl_metadata, hovertext: standardControl_hoverText, text: standardControl_text,
                    textfont: { size: 17, color: standardControl_text_fontColor }
                }
            }
            , selectedRows: data, scatterPlotDataByPlate: scatterPlotDataByPlate
        }, ()=>{
            if(!_.isEmpty(this.state.recentSelectedStatus) && (event.upArrowPressed || event.downArrowPressed)){
                if(this.state.statusInfo_selected.hasOwnProperty(rowId)){
                    if(this.state.statusInfo_selected[rowId] === null || typeof this.state.statusInfo_selected[rowId] === "undefined") {
                        this.handleStatusDropDownChange(rowId, this.state.recentSelectedStatus)
                    }
                }else if(this.state.statusInfo_selectedDefault[rowId] === null || typeof this.state.statusInfo_selectedDefault[rowId] === "undefined"){
                    this.handleStatusDropDownChange(rowId, this.state.recentSelectedStatus);
                }

            }
        });
    }

    getNormalizedIntensities(wells, plateMarkerId, markerName, id){
        // for scatter plot
        let normalizedFAMIntensity_HOM_VIC = [];
        let normalizedFAMIntensity_HOM_FAM = [];
        let normalizedFAMIntensity_HEMI = [];
        let normalizedFAMIntensity_FAIL = [];
        let normalizedFAMIntensity_TANDEM = [];
        let normalizedFAMIntensity_MULTICOPY = [];

        let normalizedVICIntensity_HOM_VIC = [];
        let normalizedVICIntensity_HOM_FAM = [];
        let normalizedVICIntensity_HEMI = [];
        let normalizedVICIntensity_FAIL = [];
        let normalizedVICIntensity_TANDEM = [];
        let normalizedVICIntensity_MULTICOPY = [];

        let standardControlFAM = [];
        let standardControlVIC = [];
        let standardControlVicByFam = [];
        let standardControlRange = [];

        let normalized_HOM_VIC_metadata = [];
        let normalized_HOM_FAM_metadata = [];
        let normalized_HEMI_metadata = [];
        let normalized_FAIL_metadata = [];
        let normalized_TANDEM_metadata = [];
        let normalized_MULTICOPY_metadata = [];
        let standardControl_metadata = [];

        let hom_fam_hoverText = [];
        let hom_vic_hoverText = [];
        let fail_hoverText = [];
        let hemi_hoverText = [];
        let tandem_hoverText = [];
        let multicopy_hoverText = [];
        let standardControl_hoverText = [];

        let standardControl_text = [];
        let standardControl_text_fontColor = [];

        // for s-curve
        let normalizedVicByFamIntensity_HOM_VIC = [];
        let normalizedVicByFamIntensity_HOM_FAM = [];
        let normalizedVicByFamIntensity_HEMI = [];
        let normalizedVicByFamIntensity_FAIL = [];
        let normalizedVicByFamIntensity_TANDEM = [];
        let normalizedVicByFamIntensity_MULTICOPY = [];

        let HOM_VIC_Range = [];
        let HOM_FAM_Range = [];
        let HEMI_RANGE = [];
        let FAIL_RANGE = [];
        let TANDEM_RANGE = [];
        let MULTICOPY_RANGE = [];

        let opacity_HOM_FAM = [];
        let opacity_HOM_VIC = [];
        let opacity_HEMI = [];
        let opacity_FAIL = [];
        let opacity_TANDEM = [];
        let opacity_MULTICOPY = [];

        wells = orderby(wells,['ratio'],['asc']);
        let fam_lower_range = 20, fam_upper_range = -20, vic_lower_range = 20, vic_upper_range = -20;
        let ids = [];
        for(let well in wells){
            ids.push(""+ id++);
            var _tempWell = wells[well];
            _tempWell["plateMarkerId"] = plateMarkerId;
            _tempWell["markerName"] = markerName;
            let vicByFam = _tempWell["ratio"];
            _tempWell["sampleRankings"] = vicByFam;
            let famByRox = _tempWell.famIntensity / _tempWell.roxIntensity;
            let vicByRox = _tempWell.vicIntensity / _tempWell.roxIntensity;

            if(famByRox < fam_lower_range)
                fam_lower_range = famByRox;
            if(famByRox > fam_upper_range)
                fam_upper_range = famByRox;
            if(vicByRox < vic_lower_range)
                vic_lower_range = vicByRox;
            if(vicByRox > vic_upper_range)
                vic_upper_range = vicByRox;

            if( _.isUndefined(_tempWell.standardControl) ||
                _.isNull(_tempWell.standardControl) ||
                _tempWell.standardControl === ""
              ){
                // hom vic
                if(_tempWell.predictedCall.toLowerCase() === trace_types.hom_vic.toLowerCase()){
                    normalizedFAMIntensity_HOM_VIC.push(famByRox);
                    normalizedVICIntensity_HOM_VIC.push(vicByRox);
                    normalized_HOM_VIC_metadata.push(_tempWell);
                    hom_vic_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_HOM_VIC.push(vicByFam);
                    HOM_VIC_Range.push(well);

                    opacity_HOM_VIC.push(_tempWell.maxCallProbability);
                }
                // hom fam
                else if(_tempWell.predictedCall.toLowerCase() === trace_types.hom_fam.toLowerCase()) {
                    normalizedFAMIntensity_HOM_FAM.push(famByRox);
                    normalizedVICIntensity_HOM_FAM.push(vicByRox);
                    normalized_HOM_FAM_metadata.push(_tempWell);
                    hom_fam_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_HOM_FAM.push(vicByFam);
                    HOM_FAM_Range.push(well);

                    opacity_HOM_FAM.push(_tempWell.maxCallProbability);
                }
                // hemi
                else if(_tempWell.predictedCall.toLowerCase() === trace_types.hemi.toLowerCase()) {
                    normalizedFAMIntensity_HEMI.push(famByRox);
                    normalizedVICIntensity_HEMI.push(vicByRox);
                    normalized_HEMI_metadata.push(_tempWell);
                    hemi_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_HEMI.push(vicByFam);
                    HEMI_RANGE.push(well);

                    opacity_HEMI.push(_tempWell.maxCallProbability);
                }
                // fail
                else if(_tempWell.predictedCall.toLowerCase() === trace_types.fail.toLowerCase()){
                    normalizedFAMIntensity_FAIL.push(famByRox);
                    normalizedVICIntensity_FAIL.push(vicByRox);
                    normalized_FAIL_metadata.push(_tempWell);
                    fail_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_FAIL.push(vicByFam);
                    FAIL_RANGE.push(well);

                    opacity_FAIL.push(_tempWell.maxCallProbability);
                    // pos
                }
                // tandem
                else if(_tempWell.predictedCall.toLowerCase() === trace_types.tandem.toLowerCase()){
                    normalizedFAMIntensity_TANDEM.push(famByRox);
                    normalizedVICIntensity_TANDEM.push(vicByRox);
                    normalized_TANDEM_metadata.push(_tempWell);
                    tandem_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_TANDEM.push(vicByFam);
                    TANDEM_RANGE.push(well);

                    opacity_TANDEM.push(_tempWell.maxCallProbability);
                    // pos
                }
                // multicopy
                else if(_tempWell.predictedCall.toLowerCase() === trace_types.multicopy.toLowerCase()){
                    normalizedFAMIntensity_MULTICOPY.push(famByRox);
                    normalizedVICIntensity_MULTICOPY.push(vicByRox);
                    normalized_MULTICOPY_metadata.push(_tempWell);
                    multicopy_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_MULTICOPY.push(vicByFam);
                    MULTICOPY_RANGE.push(well);

                    opacity_MULTICOPY.push(_tempWell.maxCallProbability);
                }
            } else{
                standardControlFAM.push(famByRox);
                standardControlVIC.push(vicByRox);
                standardControl_metadata.push(_tempWell);
                standardControl_hoverText.push(this.prepareText(_tempWell));

                standardControlVicByFam.push(vicByFam);
                standardControlRange.push(well);

                standardControl_text.push(_tempWell.standardControl);
                standardControl_text_fontColor.push(colorConfigs[_tempWell.predictedCall]);
            }
        }
        return {
            "fam_hom_vic": normalizedFAMIntensity_HOM_VIC, "fam_hom_fam": normalizedFAMIntensity_HOM_FAM, "fam_hemi": normalizedFAMIntensity_HEMI, "fam_fail": normalizedFAMIntensity_FAIL,
            "fam_tandem": normalizedFAMIntensity_TANDEM, "fam_multicopy": normalizedFAMIntensity_MULTICOPY,
            "vic_hom_vic": normalizedVICIntensity_HOM_VIC, "vic_hom_fam": normalizedVICIntensity_HOM_FAM, "vic_hemi": normalizedVICIntensity_HEMI, "vic_fail": normalizedVICIntensity_FAIL,
            "vic_tandem": normalizedVICIntensity_TANDEM,"vic_multicopy": normalizedVICIntensity_MULTICOPY,
            "hom_vic_metadata": normalized_HOM_VIC_metadata, "hom_fam_metadata": normalized_HOM_FAM_metadata, "hemi_metadata": normalized_HEMI_metadata, "fail_metadata": normalized_FAIL_metadata,
            "tandem_metadata": normalized_TANDEM_metadata, "multicopy_metadata": normalized_MULTICOPY_metadata,
            "hom_fam_hoverText":hom_fam_hoverText, "hom_vic_hoverText":hom_vic_hoverText, "fail_hoverText":fail_hoverText, "hemi_hoverText": hemi_hoverText,
            "tandem_hoverText": tandem_hoverText,"multicopy_hoverText": multicopy_hoverText,

            "vicByFam_hom_vic": normalizedVicByFamIntensity_HOM_VIC, "vicByFam_hom_fam": normalizedVicByFamIntensity_HOM_FAM, "vicByFam_hemi": normalizedVicByFamIntensity_HEMI,
            "vicByFam_fail": normalizedVicByFamIntensity_FAIL,
            "vicByFam_tandem": normalizedVicByFamIntensity_TANDEM,"vicByFam_multicopy": normalizedVicByFamIntensity_MULTICOPY,
            "hom_vic_range":HOM_VIC_Range, "hom_fam_range":HOM_FAM_Range, "hemi_range": HEMI_RANGE, "fail_range":FAIL_RANGE,
            "tandem_range": TANDEM_RANGE,"multicopy_range": MULTICOPY_RANGE,

            "standardControl_fam": standardControlFAM, "standardControl_vic": standardControlVIC, "standardControlVicByFam": standardControlVicByFam, "standardControlRange": standardControlRange,
            "standardControl_metadata": standardControl_metadata, "standardControl_text_fontColor": standardControl_text_fontColor,
            "standardControl_hoverText": standardControl_hoverText, "standardControl_text": standardControl_text,

            "opacity_hom_vic": opacity_HOM_VIC, "opacity_hom_fam": opacity_HOM_FAM, "opacity_hemi": opacity_HEMI, "opacity_fail": opacity_FAIL,
            "opacity_tandem": opacity_TANDEM, "opacity_multicopy": opacity_MULTICOPY,

            "fam_lower_range": fam_lower_range, "fam_upper_range": fam_upper_range,
            "vic_lower_range": vic_lower_range, "vic_upper_range": vic_upper_range,

            "ids": ids
        }
    }

    prepareText(wellInfo){
        let info = "Well: "+wellInfo.wellName+"<br>";
        info += "Ratio: "+wellInfo.ratio+"<br>";
        info += "ROX: "+wellInfo.roxIntensity+"<br>";
        info += "VIC: "+wellInfo.vicIntensity+"<br>";
        info += "FAM: "+wellInfo.famIntensity+"<br>";
        info += "Call: "+wellInfo.predictedCall+"<br>";
        info += "Probability: "+wellInfo.maxCallProbability+"<br>";
        info += "SampleId: "+wellInfo.sampleId;
        return info;
    }

    prepareStatus(statusArr){
        let statusOptions = [];
        let statusObjs = {};
        let description = "", code = "";
        for(let obj in statusArr){
            description = statusArr[obj]["description"];
            code = statusArr[obj]["code"];
            statusOptions.push({label: description, value: code});
            statusObjs[code] = description
        }
        return {statusOptions, statusObjs};
    }

    reloadData(data){
        this.setState({
            data: data,
            wellsData: this.setWellData(data).wellData
        },() =>{ this.onRowClick({}, this.state.selectedRows) })
    }

    fetchData(){
        let requestId = this.state.projectId;
        $.ajax({
            url: urls.assayDataRoute+(requestId?"?projectId="+requestId:""),
            contentType: 'application/json',
            data:{},
            type:'GET',
            cache: true,
            success: function(data) {
                this.fetchConfig(data);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching data from api !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        })
    }

    fetchConfig(gridData){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, appCode: this.state.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                let _wellData = this.setWellData(gridData.markerPlateVOList);
                if(!(data.length > 0)) data = Config;
                this.setState({data:gridData.markerPlateVOList, totalPlates: gridData.markerPlateVOList.length, renderGrid:true,
                    projectType: gridData.project.projectType, labCode: gridData.project.labCode,
                    gridConfig: data, wellsData: _wellData.wellData, statusCounts: gridData.statusCount, currentUser: this.props.currentUser}, () => {
                    // this.onRowClick(null, this.state.selectedRows)
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    setWellData(data){
        let wellData = {};
        for( let row in data){
            var _thisData = data[row];
            wellData[_thisData.plateMarkerId] = _thisData.wells;
            _thisData.wells = []
        }
        return {"wellData": wellData};
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    submitRedo(){
        this.setState({
            openSubmitRedoModal: true
        })
    }

    deliverRequest(){
        this.setState({
            openDeliverRequestModal: true
        })
    }

    saveStatus(rowId, selectedOption){
        $.ajax({
            url: urls.savePlateStatusRoute,
            contentType: 'application/json',
            data:JSON.stringify({plateMarkerId: rowId, status: selectedOption.value, projectId: this.state.projectId, userId: this.props.currentUser.id}),
            type:'POST',
            cache: true,
            success: function(data) {
                let statusInfo_selected = this.state.statusInfo_selected;
                statusInfo_selected[rowId] = selectedOption.label;
                this.setState({
                    statusCounts:data,
                    statusInfo_selected: statusInfo_selected,
                    recentSelectedStatus: selectedOption.label !== null? selectedOption : this.state.recentSelectedStatus
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    handleStatusDropDownChange(rowId, selectedOption){
        if(_.isEmpty(selectedOption)){ selectedOption.value = ""; selectedOption.label = null }
        // const {statusInfo_selected} = this.state;
        // statusInfo_selected[rowId] = selectedOption.label;
        this.saveStatus(rowId, selectedOption);
    }

    removeFromObjArray(arr, prop, value){
        let index = this.findIndexFromArray(arr, prop, value);
        if(index > -1){
            arr.splice(index, 1);
        }
    }

    findIndexFromArray(arr, prop, value){
        return arr.findIndex(obj => obj[prop] === value);
    }

    statusDropDown(props, state, columnMeta, index, rowId, defaultValue){
        this.state.statusInfo_selectedDefault[rowId] = this.state.statusObjs[defaultValue];
        let options = this.state.statusOptions;
        return (
            <Select
                value={{label: (!_.isUndefined(this.state.statusInfo_selected[rowId]))?this.state.statusInfo_selected[rowId]:this.state.statusInfo_selectedDefault[rowId],  value: defaultValue}}
                onChange={this.handleStatusDropDownChange.bind(this, rowId)}
                options={options}
                className="status-drop-down"
                classNamePrefix="status-drop-down"
                placeholder="choose status..."
                id={rowId}
            />
        );
    }

    handleNoteChange(rowId, event){
        this.modifiedNotes[rowId] = event.target.value;
    }

    saveNote(rowId){
        $.ajax({
            url: urls.saveNotesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, noteType: "plate", parentId: rowId, note: this.modifiedNotes[rowId]}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] === "0"){
                    toast.success("Note saved successfully.");
                }
                else {
                    toast.error("Error while saving note! Please check server logs.")
                }
                this.fetchData();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving note !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    deleteNote(rowId){
        $.ajax({
            url: urls.deleteNotesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, noteType: "plate", parentId: rowId}),
            type:'POST',
            cache: true,
            success: async function(data) {
                toast.success("Note deleted successfully.");
                this.fetchData();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving note !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    note(props, state, columnMeta, index, rowId, defaultValue){
        return (
            <Notes
                defaultValue={defaultValue}
                onNoteChange={this.handleNoteChange.bind(this, rowId)}
                onSaveClick={this.saveNote.bind(this, rowId)}
                onDeleteClick={this.deleteNote.bind(this, rowId)}
            />
        );
    }

    render() {
        const {data,requestDetails, notificationMessage, scatterPlotData, scatterPlotDataByPlate, sCurvePlotData, wellsData, maxCallProbability, statusCounts, workflowType,
            gridConfig , renderGrid, selectedRows, appCode, openSubmitRedoModal,openDeliverRequestModal, statusInfo_redo, totalPlates, currentUser, projectId, labCode, projectType} = this.state;
        let customCellFormatters = {
            "statusDropDown" : this.statusDropDown.bind(this),
            "note": this.note.bind(this)
        };
        let submitButtonClassName = 'button';
        let submitButtonDisabled = '';
        let deliverRequestButtonClassName = 'button';
        let deliverRequestButtonDisabled = '';
        if(!(statusCounts.redocount>0 && (statusCounts.redocount + statusCounts.dropcount + statusCounts.okcount) === totalPlates)){
            submitButtonClassName = 'disabled-button';
            submitButtonDisabled = 'disabled';
        }
        if((statusCounts.redocount + statusCounts.dropcount + statusCounts.okcount) !== totalPlates){
            deliverRequestButtonClassName = 'disabled-button';
            deliverRequestButtonDisabled = 'disabled';
        }
        return (
            <div>
                <ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>
                <Modal visible={openSubmitRedoModal}  width="400" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openSubmitRedoModal')}>
                    <SubmitRedo projectId={projectId} currentUser={currentUser}/>
                </Modal>
                <Modal visible={openDeliverRequestModal}  width="400" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openDeliverRequestModal')}>
                    <DeliverRequest projectId={projectId} currentUser={currentUser}/>
                </Modal>
                <div id="assay-data-plots-holder-by-plate" className={"container-fluid"}>
                    {renderGrid &&
                    <div className={"row"}>
                        <div id="assay-data-by-plate" tabIndex="1" style={{width: '65%'}} className={"outline0"}>
                            <div style={{float: "right"}}>
                                <button id="submit-redo" onClick={this.submitRedo} disabled={submitButtonDisabled}
                                        className={submitButtonClassName}>Submit Redo
                                </button>
                                <button id="deliver-request" onClick={this.deliverRequest}
                                        disabled={deliverRequestButtonDisabled}
                                        className={deliverRequestButtonClassName}>Deliver Request
                                </button>
                            </div>
                            <DataGrid
                                gridId={"assayDataByPlate"}
                                appCode={appCode}
                                fixedHeight={60}
                                resultsPerPage={500}
                                showAllData={false}
                                onRowClick={this.onRowClick}
                                showCheckBox={true}
                                showCheckAllCheckbox={false}
                                config={gridConfig}
                                //colorConfig={colorConfig}
                                customCellFormatters={customCellFormatters}
                                data={data}
                                heading={"Score Marker Assay Data"}
                                refreshData={this.fetchData}
                                settingOptions={true}
                                filterOptions={false}
                                indexColumn={"plateMarkerId"}
                            />

                        </div>
                        <div id="plots-by-plate" tabIndex="2" style={{width: '35%'}} className={"outline0"}>
                            <div>
                                <Plots projectId={projectId} traceTypes={trace_types}
                                       scatterPlotGraphData={scatterPlotData}
                                       scatterPlotDataByPlate={scatterPlotDataByPlate}
                                       sCurveGraphData={sCurvePlotData}
                                       reloadData={this.reloadData}
                                       selectedRows={selectedRows}
                                       currentUser={currentUser}
                                       labCode={labCode}
                                       projectType={projectType}
                                       workflowType={workflowType}
                                />
                            </div>
                        </div>
                    </div>
                    }
                </div>
            </div>
        );
    }
}

AssayDataByPlate.defaultProps = {
    gridConfig:[]
};

function mapStateToProps(state) {
    return {
        currentUser: state.currentUser
    };
}



export default connect(mapStateToProps)(AssayDataByPlate);