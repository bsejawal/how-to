import React from 'react';
import AssayDataByPlate from './scoring-by-plate/AssayDataByPlate'
import AssayDataByFamily from './scoring-by-family/AssayDataByFamily'

import {Tab, TabList, TabPanel, Tabs} from 'react-tabs';
import RequestDetails from "./scoring-by-plate/plotly/RequestDetails";

class AssayDataTabs extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            renderGrid: false, projectId: this.props.projectId
        })
    }

    componentDidMount(){
        this.setState({
            renderGrid: true
        })
    }

    render(){
        const {renderGrid, projectId} = this.state;
        return (
            <div >
                <div className={"container-fluid"}>
                    <div className={"row"}>
                        <div id={"assay-data-grid-plots-div"} style={{width:"85%"}}>
                            {renderGrid &&
                            <Tabs forceRenderTabPanel={true}>
                                <TabList>
                                    <Tab>ByPlate</Tab>
                                    <Tab>ByFamily</Tab>
                                </TabList>
                                <TabPanel>
                                    <AssayDataByPlate {...this.props}/>
                                </TabPanel>
                                <TabPanel>
                                    <AssayDataByFamily {...this.props}/>
                                </TabPanel>
                            </Tabs>
                            }
                        </div>
                        <div id="request-details-div" style={{width: '15%'}}>
                            <div >
                                <RequestDetails projectId={projectId}/>
                            </div>
                            {/*<StandardControls/>*/}
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}

module.exports = AssayDataTabs