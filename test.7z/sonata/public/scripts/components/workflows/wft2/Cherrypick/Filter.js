import React from 'react';
import Select from 'react-select';
import {$} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";

class FilterMain extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            samplesConfig: props.samplesConfig,
            selectedTissueBoxes: null, selectedAssays:null, selectedPedigrees:null, projectId: ""
        });
        this.createFilterOptions = this.createFilterOptions.bind(this);
    }

    handleTissueBoxFilterChange(objs){
        let selected = [];
        for(let obj in objs){
            selected.push(objs[obj].value)
        }
        this.setState({
            selectedTissueBoxes: selected.length > 0 ? selected : null
        })
    }

    handleAssayFilterChange(objs){
        let selected = [];
        for(let obj in objs){
            selected.push(objs[obj].value)
        }
        this.setState({
            selectedAssays: selected.length > 0 ? selected : null
        })
    }

    handlePedigreeFilterChange(objs){
        let selected = [];
        for(let obj in objs){
            selected.push(objs[obj].value)
        }
        this.setState({
            selectedPedigrees: selected.length > 0 ? selected : null
        })
    }

    handleLimsIdInputChange(event){
        this.setState({
            projectId: event.target.value
        });
    }

    createFilterOptions(options){
        let filterOptions = [];
        for(let o in options) {
            let option = options[o];
            filterOptions.push({key:option, value: option, label: option})
        }
        return filterOptions;
    }

    render(){
        const { selectedTissueBoxes, selectedAssays, selectedPedigrees, projectId } = this.state;
        let tissueBoxFilterOptions = this.createFilterOptions(this.props.tissueBoxFilterOptions);
        let pedigreeFilterOptiosn = this.createFilterOptions(this.props.pedigreeFilterOptions);
        let assayFilterOptions = this.createFilterOptions(this.props.assayFilterOptions);
        let filterRequestData = {samplesDataRequestVO: {projectIds: projectId, selectedTissueBoxes: selectedTissueBoxes,selectedAssays: selectedAssays,selectedPedigrees: selectedPedigrees}};
        return (
            <div className="samples-info-filter-wrapper">
                <h4>Filters</h4>
                <div style={{margin:"0 0 2vh 0"}}>
                    Lims Id: <input type={"text"} onChange={this.handleLimsIdInputChange.bind(this)}/> &nbsp;
                    <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.props.fetchData.bind(this, projectId)}> Load </button>
                </div>
                <div style={{height:"50vh", width:"33vh", overflowY:"scroll"}}>
                    <div style={{margin:"0 0 1vh 0"}}>
                        Tissue Box:
                        <Select
                            // value={selectedOption}
                            style={{width: '2px'}}
                            isMulti={"true"}
                            onChange={this.handleTissueBoxFilterChange.bind(this)}
                            options={tissueBoxFilterOptions}
                            className="filter-fields-dropdown"
                            classNamePrefix="filter-fields-dropdown"
                            placeholder="Choose Field..."
                            closeMenuOnSelect={false}
                        />
                    </div>
                    <div style={{margin:"0 0 1vh 0"}}>
                        Assay:
                        <Select
                            // value={selectedOption}
                            style={{width: '2px'}}
                            isMulti={"true"}
                            onChange={this.handleAssayFilterChange.bind(this)}
                            options={assayFilterOptions}
                            className="filter-fields-dropdown"
                            classNamePrefix="filter-fields-dropdown"
                            placeholder="Choose Field..."
                            closeMenuOnSelect={false}
                        />
                    </div>
                    <div style={{margin:"0 0 1vh 0"}}>
                        Pedigree:
                        <Select
                            // value={selectedOption}
                            style={{width: '2px'}}
                            isMulti={"true"}
                            onChange={this.handlePedigreeFilterChange.bind(this)}
                            options={pedigreeFilterOptiosn}
                            className="filter-fields-dropdown"
                            classNamePrefix="filter-fields-dropdown"
                            placeholder="Choose Field..."
                            closeMenuOnSelect={false}
                        />
                    </div>
                </div>
                <div style={{margin:"1vh 0 0 0"}}>
                    <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} style={{float:'right'}}
                            onClick={this.props.fetchSamples.bind(this, filterRequestData)}>
                        Apply Filters
                    </button>
                </div>
            </div>
        )
    }
}

module.exports = FilterMain;