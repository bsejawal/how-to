import React from 'react';
import {toast} from "react-toastify";
import Modal from "react-awesome-modal";
import ResponsiveModal from 'react-responsive-modal';
import SamplesExport from './SamplesExport'
import Select from 'react-select';
import CustomerReport from '../CustomerReport/CustomerReport'
import CloseButton from '../../../util/CloseButton'

class OtherOptions extends React.Component{
    constructor(props){
        super(props);
        this.state = ({
          cherryPick: false, sendEmail: false, downloadData: false, redoRound: null, redoReason: null
        })
    }

    cherryPickSamples(selectedRows){
        if(typeof selectedRows === "undefined" || selectedRows === null || selectedRows.length === 0){
            toast.error("No samples selected.")
        }else{
            this.setState({
                cherryPick: true
            })
        }
    }

    sendEmail(selectedRows){
        this.setState({
            sendEmail: true
        })
    }

    downloadData(selectedRows){
        if(typeof selectedRows === "undefined" || selectedRows === null || selectedRows.length === 0){
            toast.error("No samples selected.")
        }else{
            this.setState({
                downloadData: true
            })
        }
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    onRedoroundChange(selectedOption){
        this.setState({
            redoRound: selectedOption.value
        })
    }

    onRedoReasonChange(selectedOption){
        this.setState({
            redoReason: selectedOption.value
        })
    }

    getClassName(fieldToCheck){
        return (fieldToCheck === null || typeof fieldToCheck === "undefined" || fieldToCheck==="" ? "text-danger" : "");
    }

    getRedoRoundOptions(){
        let options = [{value:1, label:1},{value:2, label:2},{value:3, label:3},{value:4, label:4},{value:5, label:5}];
        return (
            <Select
                required
                onChange={this.onRedoroundChange.bind(this)}
                options={options}
                className="samples-redo-drop-down"
                classNamePrefix="samples-redo-drop-down"
                placeholder={<span className={this.getClassName(this.state.redoRound)}>Choose redo round...</span>}
            />
        )
    }

    getRedoReasonOptions(){
        let options = [ {value:"R04", label:"% missing - failed/uncallable(Reassay)"},
                        {value:"R05", label:"%missing- automation issue(Re-extract)"},
                        {value:"R06", label:"Unexpected calls-QC shiny app(Reassay)"}
                        ];
        return (
            <Select
                onChange={this.onRedoReasonChange.bind(this)}
                options={options}
                className="samples-redo-drop-down"
                classNamePrefix="samples-redo-drop-down"
                placeholder={<span className={this.getClassName(this.state.redoReason)}>Choose redo reason...</span>}
            />
        )
    }

    submitForCherryPick(){
        if(this.state.redoRound===null || this.state.redoRound==="" || typeof this.state.redoRound === "undefined"
            || this.state.redoReason===null || this.state.redoReason==="" || typeof this.state.redoReason === "undefined"){
            toast.error("Please select round and reason for redo.")
        }else {
            this.props.sendDataForCherryPick(this.state.redoReason, this.state.redoRound)
        }
    }

    render(){
        const {cherryPick, sendEmail, downloadData, redoReason, redoRound} = this.state;
        return (
            <div>
                <Modal visible={cherryPick} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'cherryPick')}>
                    <CloseButton onClick={this.closeModal.bind(this,'cherryPick')}/>
                    <div className={"center-contents-div"}>
                        <div className={"container-fluid"}>
                            <div className={"row center-contents-div"}>
                                Cherry Pick
                            </div>
                            <div className={"row"}>
                                <div className={"col"}>
                                    Number of Reps:
                                    {this.getRedoRoundOptions()}
                                </div>
                            </div>
                            <div className={"row"}>
                                <div className={"col"}>
                                    Redo Reason:
                                    {this.getRedoReasonOptions()}
                                </div>
                            </div>
                            <button type={"button"} onClick={this.submitForCherryPick.bind(this)} className={"btn btn-primary btn-raised btn-xs"}
                                    style={{float:'right', margin:'1vh 0 0 0'}}>Submit</button>
                        </div>
                    </div>
                </Modal>
                <Modal visible={downloadData} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'downloadData')}>
                    <CloseButton onClick={this.closeModal.bind(this,'downloadData')}/>
                    <SamplesExport excelData={this.props.selectedRows} downloadData={downloadData}/>
                </Modal>
                <div className={"container-fluid"}>
                    <div className={"row"}>
                        <div className={""} style={{margin: "0 1vh 0 3vh"}}>
                            <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.cherryPickSamples.bind(this,this.props.selectedRows)}>CherryPick</button>
                        </div>
                        <div className={""} style={{margin: "0 1vh 0 0"}}>
                            <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.downloadData.bind(this,this.props.selectedRows)}>Download</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = OtherOptions;