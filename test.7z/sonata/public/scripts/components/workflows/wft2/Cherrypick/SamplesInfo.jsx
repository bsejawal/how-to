import React from 'react'
import {$, DataGrid} from "../../../react-table/table/body/Page";
import Filter from './Filter'
// import OtherOptions from './OtherOptions'
import Select from 'react-select';
import urls from "../../../Urls";
import {toast, ToastContainer} from "react-toastify";
import connect from "react-redux/es/connect/connect";
import Modal from "react-awesome-modal";
import CloseButton from "../../../util/CloseButton";
// import SamplesExport from "./SamplesExport";
import ProjectConstants from '../../../util/ProjectConstants'

import ReactExport from "react-data-export";
import {AjaxLoader} from '../../../util/Ajaxsetup'

const Config = require ('../../../config/workflows/wft2/CherrypickConfig.json');

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

let _global_selectedRows = {};

class SamplesExport extends React.PureComponent {
    constructor(props){
        super(props);
        document.title = "Cherrypick";
        this.state = ({

        })
    }

    getSelectedDataAsArray(){
        let selectedData = [];
        if(this.props.downloadData){
            let excelData = this.props.excelData;
            for(let data in excelData){
                selectedData.push(excelData[data]["data"])
            }
        }
        return selectedData;
    }

    render(){
        let selectedData = this.getSelectedDataAsArray();
        return (
            <div>
                <ExcelFile filename={"Samples"} element={<a href="javascript:void(0)" >Download Data</a>}>
                    <ExcelSheet data={selectedData} name={"Samples Information"}>
                        <ExcelColumn label="Request" value="request"/>
                        <ExcelColumn label="Protocol" value="protocol"/>
                        <ExcelColumn label="Tissue Box" value="tissueBox"/>
                        <ExcelColumn label="Tissue Well" value="tissueWell"/>
                        <ExcelColumn label="Quality" value="quality"/>
                        <ExcelColumn label="Pedigree" value="pedigree"/>
                        <ExcelColumn label="Sample Name" value="sampleName"/>
                        <ExcelColumn label="Assay Type" value="assayType"/>
                        <ExcelColumn label="Event Type" value="eventType"/>
                        <ExcelColumn label="Assay Substance" value="assaySubstance"/>
                        <ExcelColumn label="Assay Technology" value="assayTechnology"/>
                        <ExcelColumn label="Last Call" value="lastCall"/>
                        <ExcelColumn label="All Calls" value="allCalls"/>
                    </ExcelSheet>
                </ExcelFile>
            </div>
        )
    }
}

class OtherOptions extends React.PureComponent{
    constructor(props){
        super(props);
        this.state = ({
            cherryPick: false, sendEmail: false, downloadData: false, redoRound: null, redoReason: null
        })
    }

    cherryPickSamples(selectedRows){
        if(typeof selectedRows === "undefined" || selectedRows === null || selectedRows.length === 0){
            toast.error("No samples selected.")
        }else{
            this.setState({
                cherryPick: true
            })
        }
    }

    downloadData(selectedRows){
        if(typeof selectedRows === "undefined" || selectedRows === null || selectedRows.length === 0){
            toast.error("No samples selected.")
        }else{
            this.setState({
                downloadData: true
            })
        }
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    onRedoroundChange(selectedOption){
        this.setState({
            redoRound: selectedOption.value
        })
    }

    onRedoReasonChange(selectedOption){
        this.setState({
            redoReason: selectedOption.value
        })
    }

    getClassName(fieldToCheck){
        return (fieldToCheck === null || typeof fieldToCheck === "undefined" || fieldToCheck==="" ? "text-danger" : "");
    }

    getRedoRoundOptions(){
        let options = [{value:1, label:1},{value:2, label:2},{value:3, label:3},{value:4, label:4},{value:5, label:5}];
        return (
            <Select
                required
                onChange={this.onRedoroundChange.bind(this)}
                options={options}
                className="samples-redo-drop-down"
                classNamePrefix="samples-redo-drop-down"
                placeholder={<span className={this.getClassName(this.state.redoRound)}>Choose redo round...</span>}
            />
        )
    }

    getRedoReasonOptions(){
        let options = [ {value:"R04", label:"% missing - failed/uncallable(Reassay)"},
            {value:"R05", label:"%missing- automation issue(Re-extract)"},
            {value:"R06", label:"Unexpected calls-QC shiny app(Reassay)"}
        ];
        return (
            <Select
                onChange={this.onRedoReasonChange.bind(this)}
                options={options}
                className="samples-redo-drop-down"
                classNamePrefix="samples-redo-drop-down"
                placeholder={<span className={this.getClassName(this.state.redoReason)}>Choose redo reason...</span>}
            />
        )
    }

    submitForCherryPick(){
        if(this.state.redoRound===null || this.state.redoRound==="" || typeof this.state.redoRound === "undefined"
            || this.state.redoReason===null || this.state.redoReason==="" || typeof this.state.redoReason === "undefined"){
            toast.error("Please select round and reason for redo.")
        }else {
            this.props.sendDataForCherryPick(this.state.redoReason, this.state.redoRound)
        }
    }

    render(){
        const {cherryPick, sendEmail, downloadData, redoReason, redoRound} = this.state;
        return (
            <div>
                <Modal visible={cherryPick} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'cherryPick')}>
                    <CloseButton onClick={this.closeModal.bind(this,'cherryPick')}/>
                    <div className={"center-contents-div"}>
                        <div className={"container-fluid"}>
                            <div className={"row center-contents-div"}>
                                Cherry Pick
                            </div>
                            <div className={"row"}>
                                <div className={"col"}>
                                    Number of Reps:
                                    {this.getRedoRoundOptions()}
                                </div>
                            </div>
                            <div className={"row"}>
                                <div className={"col"}>
                                    Redo Reason:
                                    {this.getRedoReasonOptions()}
                                </div>
                            </div>
                            <button type={"button"} onClick={this.submitForCherryPick.bind(this)} className={"btn btn-primary btn-raised btn-xs"}
                                    style={{float:'right', margin:'1vh 0 0 0'}}>Submit</button>
                        </div>
                    </div>
                </Modal>
                <Modal visible={downloadData} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'downloadData')}>
                    <CloseButton onClick={this.closeModal.bind(this,'downloadData')}/>
                    <SamplesExport excelData={_global_selectedRows} downloadData={downloadData}/>
                </Modal>
                <div className={"container-fluid"}>
                    <div className={"row"}>
                        <div className={""} style={{margin: "0 1vh 0 3vh"}}>
                            <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.cherryPickSamples.bind(this,_global_selectedRows)}>CherryPick</button>
                        </div>
                        <div className={""} style={{margin: "0 1vh 0 0"}}>
                            <button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.downloadData.bind(this,_global_selectedRows)}>Download</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

class SamplesInfo extends React.PureComponent{
    constructor(props){
        super(props);
        this.state = {
            appCode:ProjectConstants["app-codes"].CHERRYPICK_WFT2, gridConfig:[], gridData:[], renderGrid: false, tissueBoxFilterOptions: [], pedigreeFilterOptions: [], assayFilterOptions: [], selectedProjectId: "",
            selectedRows: [], filterOptions: {}
        };
        this.onRowClick = this.onRowClick.bind(this);
        this.fetchData = this.fetchData.bind(this);
        this.fetchFilterOptions = this.fetchFilterOptions.bind(this);
        this.fetchSamples = this.fetchSamples.bind(this);
    }

    componentDidMount(){
        this.fetchConfig();
    }

    fetchConfig(){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, appCode: this.state.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(!(data.length > 0)) data = Config;
                this.setState({
                    gridConfig: data,
                    renderGrid: true,
                    data: []
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    fetchData(projectIds){
        if(projectIds != null && typeof projectIds !== "undefined" && projectIds!=="") {
            const {selectedProjectId} = this.state;
            const sameProjectIds = selectedProjectId.toLowerCase().trim() === projectIds.toLowerCase().trim();//selectedProjectId.toLowerCase().trim().split(",").every(projectId => projectIds.toLowerCase().split(",").includes(projectId));
            if (!sameProjectIds) {
                this.fetchFilterOptions(projectIds);
            } else{
                this.fetchSamples( {samplesDataRequestVO: {projectIds: projectIds, selectedTissueBoxes: null, selectedAssays:null,selectedPedigrees:null}} );
            }
        }else{
            toast.error("No lims id(s) provided.")
        }
    }

    fetchFilterOptions(projectIds){
        $.ajax({
            url: urls.getSampleInfoFiltersRoute,
            contentType: 'application/json',
            data:JSON.stringify({projectIds: projectIds}),
            type:'POST',
            cache: true,
            success: function(filterOptions) {
                let _filterOptions = {samplesDataRequestVO: {projectIds: projectIds, selectedTissueBoxes: null, selectedAssays:null,selectedPedigrees:null} };
                $.ajax({
                    url: urls.getSampleDataRoute,
                    contentType: 'application/json',
                    data:JSON.stringify(_filterOptions),
                    type:'POST',
                    cache: true,
                    success: function(data) {
                        this.setState({
                            gridData: data["samples"],
                            tissueBoxFilterOptions: filterOptions["tissueBoxOptions"],
                            pedigreeFilterOptions: filterOptions["pedigreeOptions"],
                            assayFilterOptions: filterOptions["assayOptions"],
                            selectedProjectId: projectIds,
                            filterOptions: _filterOptions
                        },function(){
                            if(data["hasPlatesWithEmptyStatus"]===true)
                                toast.warn("All plates are not assigned status.")
                        })
                    }.bind(this),
                    error: function(xhr, status, err) {
                        toast.error("Error occured while fetching filter options")
                    }.bind(this)
                });
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured while fetching filter options")
            }.bind(this)
        })
    }

    fetchSamples(filterOptions){
        $.ajax({
            url: urls.getSampleDataRoute,
            contentType: 'application/json',
            data:JSON.stringify(filterOptions),
            type:'POST',
            cache: true,
            success: function(data) {
                this.setState({
                    gridData: data["samples"],
                    filterOptions: filterOptions
                },function(){
                    if(data["hasPlatesWithEmptyStatus"]===true)
                        toast.warn("All plates are not assigned status.")
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured while fetching filter options")
            }.bind(this)
        })
    }

    sendDataForCherryPick(redoReason, redoRound, event){
        let unwrap = ({sampleId, well, plateBarCode, assay, projectId}) => ({sampleId, well, plateBarCode, assay, projectId});
        let cherryPickDatas = [];
        _global_selectedRows.map((row, index) =>{
            let _row = unwrap(row.data);
            _row.redoReason = redoReason;
            _row.redoNumber = Number(redoRound);
            cherryPickDatas.push(_row);
        });
        let _this = this;
        $.ajax({
            url: urls.cherrypickSamplesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.id, samples: cherryPickDatas}),
            type:'POST',
            cache: true,
            success: function(data) {
                if (data["status"] === 0) {
                    toast.success("Successfully sent samples for cherry pick.");
                    _this.fetchSamples(this.state.filterOptions);
                }else{
                    toast.error("Server error. Please check server logs.")
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error in request for cherry pick. Please check server logs.");
            }.bind(this)
        });
    }

    onRowClick(event, data) {
        _global_selectedRows = data;
    }

    render(){
        const {appCode, renderGrid, gridData, tissueBoxFilterOptions, pedigreeFilterOptions, assayFilterOptions, gridConfig, selectedRows} = this.state;
        return(
            <div>
                <ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>
                <AjaxLoader/>
                <div id={"Samples-Info"} className={"container-fluid"}>
                    <div className={"row"}>
                        <div className={"col-2"} id={"samples-info-filter-options"}>
                            <Filter tissueBoxFilterOptions={tissueBoxFilterOptions} pedigreeFilterOptions={pedigreeFilterOptions} assayFilterOptions={assayFilterOptions}
                                    samplesConfig={Config} fetchData={this.fetchData} fetchSamples={this.fetchSamples}/>
                        </div>
                        <div className={"col-10"} id={"samples-info-tbl"}>
                            <OtherOptions gridData={gridData} selectedRows={selectedRows} sendDataForCherryPick={this.sendDataForCherryPick.bind(this)}/>
                            {renderGrid &&
                            <DataGrid
                                appCode={appCode}
                                fixedHeight={60}
                                resultsPerPage={500}
                                showAllData={true}
                                onRowClick={this.onRowClick}
                                showCheckBox={true}
                                showCheckAllCheckbox={false}
                                config={gridConfig}
                                //colorConfig={colorConfig}
                                // customCellFormatters={customCellFormatters}
                                data={gridData}
                                heading={"Samples Info"}
                                refreshData={this.fetchData}
                                refreshOptions={false}
                                settingOptions={true}
                                filterOptions={false}
                            />

                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        currentUser: state.currentUser
    };
}

export default connect(mapStateToProps)(SamplesInfo);