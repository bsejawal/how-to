import React from 'react'

import ReactExport from "react-data-export";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

class SamplesExport extends React.Component {
    constructor(props){
        super(props);
        this.state = ({

        })
    }

    getSelectedDataAsArray(){
        let selectedData = [];
        if(this.props.downloadData){
            let excelData = this.props.excelData;
            for(let data in excelData){
                selectedData.push(excelData[data]["data"])
            }
        }
        return selectedData;
    }

    render(){
        let selectedData = this.getSelectedDataAsArray();
        return (
            <div>
                <ExcelFile filename={"Samples"} element={<a href="javascript:void(0)" >Download Data</a>}>
                    <ExcelSheet data={selectedData} name={"Samples Information"}>
                        <ExcelColumn label="Request" value="request"/>
                        <ExcelColumn label="Protocol" value="protocol"/>
                        <ExcelColumn label="Tissue Box" value="tissueBox"/>
                        <ExcelColumn label="Tissue Well" value="tissueWell"/>
                        <ExcelColumn label="Quality" value="quality"/>
                        <ExcelColumn label="Pedigree" value="pedigree"/>
                        <ExcelColumn label="Sample Name" value="sampleName"/>
                        <ExcelColumn label="Assay Type" value="assayType"/>
                        <ExcelColumn label="Event Type" value="eventType"/>
                        <ExcelColumn label="Assay Substance" value="assaySubstance"/>
                        <ExcelColumn label="Assay Technology" value="assayTechnology"/>
                        <ExcelColumn label="Last Call" value="lastCall"/>
                        <ExcelColumn label="All Calls" value="allCalls"/>
                    </ExcelSheet>
                </ExcelFile>
            </div>
        )
    }
}

export default SamplesExport;