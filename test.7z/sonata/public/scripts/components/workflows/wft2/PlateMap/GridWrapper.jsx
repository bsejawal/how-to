import React from 'react';
import PlateMapView from "./Grid";

class GridWrapper extends React.Component {
    constructor(props) {
        super(props);
    }

    generateGrids(){
        let grids = [];
        let plateIds = this.props.plateIds;
        for(var i in plateIds){
            grids.push(<PlateMapView projectId={this.props.projectId} plateId={plateIds[i]} workflowType={this.props.workflowType}/>);
        }
        return grids;
    }

    render(){
        let grids = this.generateGrids();
        return (
            <div style={{height:"90vh", overflowY:"scroll", padding:'2vh'}}>
                {grids}
            </div>
        )
    }

}

module.exports = GridWrapper;