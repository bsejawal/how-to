import React from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import SummaryDetails from './CustomerReportSummaryDetails';
import SummaryAggregate from './CustomerReportSummaryAggregate';

class CustomerReportResult extends React.Component {
    constructor(props){
        super(props);
        this.state = ({

        })
    }

    render(){
        return(
            <div style={{margin:"0 0 0 2vh"}}>
                <Tabs forceRenderTabPanel={true}>
                    <TabList>
                        <Tab>Aggregate</Tab>
                        <Tab>Details</Tab>
                    </TabList>
                    <TabPanel>
                        <SummaryAggregate {...this.props}/>
                    </TabPanel>
                    <TabPanel>
                        <SummaryDetails {...this.props}/>
                    </TabPanel>
                </Tabs>

            </div>
        )
    }
}

module.exports = CustomerReportResult;