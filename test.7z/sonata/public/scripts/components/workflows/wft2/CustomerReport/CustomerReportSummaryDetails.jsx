import React from 'react';
import Configs from "../../../config/GridConfig";
import {$, DataGrid} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";
import {toast} from "react-toastify";
import ProjectConstants from "../../../util/ProjectConstants"

class CustomerReportSummaryDetails extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            appCode: ProjectConstants["app-codes"].CUSTOMER_REPORT_SUMMARY_DETAILS_WFT2, selectedRows: [], gridConfig:[], gridData:[], renderGrid: false
        })
    }

    componentDidMount(){
        this.fetchConfig();
    }

    onRowClick(event, data) {
        this.props.onRowClick(event, data);
    }

    fetchConfig(){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId: this.props.currentUser.email, appCode: this.state.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(!(data.length > 0)) data = Configs[this.state.appCode];
                this.setState({
                    gridConfig: data,
                    renderGrid: true,
                    data: []
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    render(){
        const {appCode, gridConfig, renderGrid} = this.state;
        return(
            <div style={{margin:"0 0 0 2vh"}}>
                { renderGrid &&
                <DataGrid
                    gridId={"customerReportSummaryDetailsGrid"}
                    appCode={appCode}
                    fixedHeight={55}
                    resultsPerPage={100}
                    showAllData={true}
                    onRowClick={this.onRowClick.bind(this)}
                    showCheckBox={true}
                    showCheckAllCheckbox={false}
                    config={gridConfig}
                    //colorConfig={colorConfig}
                    // customCellFormatters={customCellFormatters}
                    data={this.props.data["details"]}
                    heading={""}
                    // refreshData={this.fetchData}
                    refreshOptions={false}
                    settingOptions={true}
                    filterOptions={false}
                    enableColumnResizer={false}
                />
                }
            </div>
        )
    }
}

module.exports = CustomerReportSummaryDetails;