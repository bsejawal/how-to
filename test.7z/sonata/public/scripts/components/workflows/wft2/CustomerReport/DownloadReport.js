import React from 'react';
import ReactExport from "react-data-export";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

class DownloadReport extends React.Component {
    constructor(props){
        super(props);
        this.state = ({

        })
    }

    getSelectedDataAsArray(){
        return {"resultData": this.props.resultData};
    }

    render(){
        let selectedData = this.getSelectedDataAsArray();
        let returnDiv = (
            <div>
                No Data Found !
            </div>
        );
        if (selectedData.resultData !== undefined && selectedData.resultData.length > 0) {
            returnDiv = (
                <div>
                    <a href={"javascript:void(0)"} onClick={this.props.sendRequestForDownload} >Download</a>
                </div>
            )
        }
        return (
            returnDiv
        )
    }
}

module.exports = DownloadReport;