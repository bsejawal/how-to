import React from 'react';
import {$} from "../../../../react-table/table/body/Page";
import urls from "../../../../Urls";
import {toast} from "react-toastify";
const {queryProfile, queries} = require('@monsantoit/profile-client');
import ProjectConstants from '../../../../util/ProjectConstants'

class EmailTemplate extends React.Component {
    constructor(props) {
        super(props);
        this.state = ({
            recipientEmailAddresses: ""
        });
        // this.getAllReceipientUsers = this.getAllReceipientUsers.bind(this);
    }

    sendEmail(emailBody, emailSubject){
        $.ajax({
            url: urls.customerReportEmailRoute,
            contentType: 'application/json',
            data:JSON.stringify({projectIds:this.props.selectedProjectId, emailBody: emailBody, emailSubject: emailSubject, senderEmailAddress: this.props.currentUser.email}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] === "0"){
                    toast.success("Sent email successfully.");
                    window.location.reload(true);
                }else if(data["status"] === "1"){
                    toast.error("Something went wrong while sending email. Please check server logs.")
                }else{
                    toast.error("Error occured. Please check server logs.")
                }

            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured. Please check server logs.")
            }.bind(this)
        });
    }

    render(){
        let emailBody =
            "Hi, " +
            "</br>Please find assay results in the following link(s) - "+window.location.href+
            "</br>Request(s): "+this.props.selectedProjectId+
            "</br>General comments:" +
            "</br>________________________________________" +
            "</br>Please let me know if there are any questions, concerns, or a need for follow-up testing." +
            "</br>Thank you and have a nice day!"+
            "</br></br>"+ this.props.currentUser.preferredName.full+
            "</br>"+ this.props.currentUser.email;

        let emailSubject = "MQC Assay Results for Request "+this.props.selectedProjectId;
        return(
            <div>
                <span className={"center-contents-div"}>
                    <button className="button" onClick={this.sendEmail.bind(this, emailBody, emailSubject)}> Send Email </button>
                </span>
            </div>
        )
    }



}

module.exports = EmailTemplate;