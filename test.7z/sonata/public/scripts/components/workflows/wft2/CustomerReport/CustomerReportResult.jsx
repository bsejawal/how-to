import React from 'react';
import Configs from "../../../config/GridConfig";
import {$, DataGrid} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";
import {toast} from "react-toastify";
import _ from 'underscore'
import ProjectConstants from "../../../util/ProjectConstants"

class CustomerReportResult extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            appCode: ProjectConstants["app-codes"].CUSTOMER_REPORT_RESULT_WFT2, selectedRows: [], gridConfig:[], gridData:[], renderGrid: false
        })
    }

    componentDidMount(){
        this.fetchConfig();
    }

    onRowClick(event, data) {
        this.props.onRowClick(event, data);
    }

    fetchConfig(){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId: this.props.currentUser.email, appCode: this.state.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(!(data.length > 0)) data = Configs[this.state.appCode];
                this.setState({
                    gridConfig: data,
                    renderGrid: true,
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    getAdditionalFields(additionalFields){
        let fieldObjects = [];
        let fieldObject = {
            "search": "true",
            "sort": "true",
            "classNames": "clickable",
            "hidden": "false",
            "type": "string",
            "indexCol": "false",
            "status":"false"
        };
        for(let [i, field] of additionalFields.entries()){
            let obj = _.extend({},fieldObject);
            obj["columnName"] = field;
            obj["displayName"] = "Qualitative call for "+field;
            obj["order"] = i + 14;
            fieldObjects.push(obj);

            if(this.props.showAllCalls) {
                let objAllCalls = _.extend({}, fieldObject);
                objAllCalls["columnName"] = field + " : ALL_CALLS";
                objAllCalls["displayName"] = "All calls for " + field;
                objAllCalls["order"] = obj["order"] + 1;
                fieldObjects.push(objAllCalls);
            }
        }
        return fieldObjects;
    }

    render(){
        let {appCode, gridConfig, renderGrid, downloadData, selectedRows} = this.state;
        let newConfig = [...gridConfig];
        if(this.props.data.length > 0){
            newConfig.push(...this.getAdditionalFields(this.props.additionalFields));
        }
        return(
            <div>
                { renderGrid &&
                <DataGrid
                    gridId={"customerReportResultGrid"}
                    appCode={appCode}
                    fixedHeight={60}
                    resultsPerPage={100}
                    showAllData={true}
                    onRowClick={this.onRowClick.bind(this)}
                    showCheckBox={true}
                    showCheckAllCheckbox={false}
                    config={newConfig}
                    //colorConfig={colorConfig}
                    // customCellFormatters={customCellFormatters}
                    data={this.props.data}
                    heading={""}
                    // refreshData={this.fetchData}
                    refreshOptions={false}
                    settingOptions={true}
                    filterOptions={false}
                    enableColumnResizer={false}
                />
                }
            </div>
        )
    }
}

module.exports = CustomerReportResult;