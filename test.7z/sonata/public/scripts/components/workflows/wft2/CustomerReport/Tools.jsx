import React from 'react';
import {toast} from "react-toastify";
import CloseButton from "../../../util/CloseButton";
import SamplesExport from "../Cherrypick/SamplesExport";
import Modal from "react-awesome-modal";

class Tools extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            downloadData: false
        })
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    downloadData(selectedRows){
        if(typeof selectedRows === "undefined" || selectedRows === null || selectedRows.length === 0){
            toast.error("No samples selected.")
        }else{
            this.setState({
                downloadData: true
            })
        }
    }

    render(){
        const {downloadData} = this.state;
        return(
            <div>
                <Modal visible={downloadData} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'downloadData')}>
                    <CloseButton onClick={this.closeModal.bind(this,'downloadData')}/>
                    <SamplesExport excelData={this.props.selectedRows} downloadData={downloadData}/>
                </Modal>
                <div className={"container-fluid"}>
                    <div className={"row"}>
                        <div className={""} style={{margin: "0 1vh 0 0"}}>
                            {/*<button type={"button"} className={"btn btn-primary btn-raised btn-xs"} onClick={this.downloadData.bind(this,this.props.selectedRows)}>Download</button>*/}
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = Tools