import React from 'react';
import {$} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";
import {toast} from "react-toastify";

class DeliverRequest extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            sendEmail: true
        }
    }
    sendDeliverRequest(projectIds){
        if(projectIds===null || typeof projectIds === "undefined" || projectIds === ""){
            toast.error("No lims id provided.")
        }else {
            $.ajax({
                url: urls.deliverRequestRoute,
                contentType: 'application/json',
                data: JSON.stringify({projectId:projectIds.split(",")[0], projectIds: projectIds, "currentUser":this.props.currentUser.id}),
                type: 'POST',
                cache: true,
                success: function (data) {
                    if (data["status"] === "0") {
                        if(this.state.sendEmail) {
                            toast.success("Successfully delivered!! Sending Email...");
                            this.sendEmail(projectIds);
                        }else{
                            toast.success("Successfully delivered!! Please wait, page will reload ! ", { onClose: ()=> window.location.reload(true) });
                        }
                    } else if (data["status"] === "2") {
                        toast.info("There is no samples to deliver as no marker plates found with status OK.")
                    }
                    else {
                        toast.error("Exception Occured. Please check server logs!")
                    }
                }.bind(this),
                error: function (xhr, status, err) {
                    toast.error("Error occured while fetching report data")
                }.bind(this)
            });
        }
    }

    sendEmail(projectIds){
        $.ajax({
            url: urls.customerReportEmailRoute,
            contentType: 'application/json',
            data:JSON.stringify({
                projectIds: projectIds,
                emailBody: this.getEmailBody(window.location.href, projectIds, this.props.currentUser),
                emailSubject: this.getEmailSubject(projectIds),
                senderEmailAddress: this.props.currentUser.email}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] === "0"){
                    toast.success("Sent email successfully. Please wait, page will reload !",{ onClose: ()=> window.location.reload(true) });
                }else if(data["status"] === "1"){
                    toast.error("Something went wrong while sending email. Please check server logs.")
                }else{
                    toast.error("Error occured. Please check server logs.")
                }

            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured. Please check server logs.")
            }.bind(this)
        });
    }

    getEmailBody(linkUrl, projectIds, currentUser){
        return "Hi, " +
            "</br>Please find assay results in the following link(s) - "+linkUrl+
            "</br>Request(s): "+projectIds+
            "</br>General comments:" +
            "</br>________________________________________" +
            "</br>Please let me know if there are any questions, concerns, or a need for follow-up testing." +
            "</br>Thank you and have a nice day!"+
            "</br></br>"+ currentUser.preferredName.full+
            "</br>"+ currentUser.email;
    }

    getEmailSubject(projectIds){
        return "MQC Assay Results for Request "+projectIds;
    }

    handleSendEmailChange(event){
        this.setState({
            sendEmail: event.target.checked
        })
    }

    render(){
        return (
            <div>
                <h4 className={"center-contents-div"}>Deliver samples for {this.props.selectedProjectIds} ?</h4>
                <label>Send Email <input type={"checkbox"} defaultChecked={true} name={"checkEmailSend"} onChange={this.handleSendEmailChange.bind(this)}/></label>
                <span className={"center-contents-div"}><button className="button" onClick={this.sendDeliverRequest.bind(this, this.props.selectedProjectIds)}> Submit </button></span>
            </div>
        )
    }
}

module.exports = DeliverRequest;