import React from 'react';
import {Tab, TabList, TabPanel, Tabs} from 'react-tabs';
import "react-tabs/style/react-tabs.css";
import CustomerReportResult from './CustomerReportResult';
import CustomerReportSummary from './CustomerReportSummary';
import CustomerReportPercentMissingByPedigree from './CustomerReportPercentMissingByPedigree'
import {$} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";
import {toast, ToastContainer} from "react-toastify";
import CustomerReportFilter from "./CustomerReportFilter";
import connect from "react-redux/es/connect/connect";
import DownloadReport from "./DownloadReport";
import Modal from "react-awesome-modal";
import DeliverRequest from './DeliverRequest'
import _ from 'underscore'
import ProjectConstants from '../../../util/ProjectConstants'
import {base64StringToBlob} from 'blob-util';
import {AjaxLoader} from '../../../util/Ajaxsetup'

const {queryProfile, queries} = require('@monsantoit/profile-client');

let customerReport = ProjectConstants.customer_report;

class CustomerReport extends React.Component {
    constructor(props){
        super(props);
        document.title ="CustomerReport";
        this.state = {
            renderGrid: false, tissueBoxFilterOptions: [], pedigreeFilterOptions: [], assayFilterOptions: [], selectedProjectId: "", allFilterOptions:{},
            selectedResultRows: [],selectedSummaryRows: [],selectedMissingByPedigreeRows:[], result: [], summary: [], missingByPedigree: [], downloadData:false,
            emailData: false, deliverRequest: false, reportType:"", resultAdditionalFields:{}
        };
        // this.onRowClick = this.onRowClick.bind(this);
        this.fetchData = this.fetchData.bind(this);
        this.fetchFilterOptions = this.fetchFilterOptions.bind(this);
        this.fetchSamples = this.fetchSamples.bind(this);
    }

    componentDidMount(){
        queryProfile('{ isCurrentUserMemberOfGroup(groupId: "'+customerReport.customer.groupId+'") }')
            .then(rs => {
                this.setState({
                    renderGrid: true,
                    reportType: rs.isCurrentUserMemberOfGroup ?  customerReport.customer.type : customerReport.lab_user.type
                })
            });
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    fetchData(projectIds){
        const {reportType} = this.state;
        if(projectIds != null && typeof projectIds !== "undefined" && projectIds!=="") {
            const {selectedProjectId} = this.state;
            const sameProjectIds = selectedProjectId.toLowerCase().trim() === projectIds.toLowerCase().trim();//selectedProjectId.toLowerCase().trim().split(",").every(projectId => projectIds.toLowerCase().split(",").includes(projectId));
            if (!sameProjectIds) {
                this.fetchFilterOptions(projectIds);
            } else{
                this.fetchSamples( {samplesDataRequestVO: {reportType:reportType, projectIds: projectIds, selectedTissueBoxes: null, selectedAssays:null,selectedPedigrees:null}} );
            }
        }else{
            toast.error("No lims id(s) provided.")
        }
    }

    fetchFilterOptions(projectIds){
        const {reportType} = this.state;
        $.ajax({
            url: urls.getSampleInfoFiltersRoute,
            contentType: 'application/json',
            data:JSON.stringify({projectIds: projectIds, reportType: reportType}),
            type:'POST',
            cache: true,
            success: function(filterOptions) {
                $.ajax({
                    url: urls.customerReportRoute,
                    contentType: 'application/json',
                    data:JSON.stringify({samplesDataRequestVO: {reportType: reportType,projectIds: projectIds, selectedTissueBoxes: null, selectedAssays:null,selectedPedigrees:null} } ),
                    type:'POST',
                    cache: true,
                    success: function(data) {
                        this.setState({
                            result: data["result"]["data"], resultAdditionalFields: data["result"]["additionalFields"],
                            summary: {"details": data["summary"], "aggregate":data['summaryAggregate']},
                            missingByPedigree: data["missingByPedigree"],
                            tissueBoxFilterOptions: filterOptions["tissueBoxOptions"],
                            pedigreeFilterOptions: filterOptions["pedigreeOptions"],
                            assayFilterOptions: filterOptions["assayOptions"],
                            selectedProjectId: projectIds,
                            allFilterOptions: {samplesDataRequestVO: {reportType: reportType,projectIds: projectIds, selectedTissueBoxes: null, selectedAssays:null,selectedPedigrees:null} }
                        })
                    }.bind(this),
                    error: function(xhr, status, err) {
                        toast.error("Error occured while fetching report data")
                    }.bind(this)
                });
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured while fetching filter options")
            }.bind(this)
        })
    }

    fetchSamples(filterOptions){
        const {reportType} = this.state;
        _.extend(filterOptions.samplesDataRequestVO, {reportType: reportType});
        $.ajax({
            url: urls.customerReportRoute,
            contentType: 'application/json',
            data:JSON.stringify(filterOptions),
            type:'POST',
            cache: true,
            success: function(data) {
                this.setState({
                    result: data["result"]["data"], resultAdditionalFields: data["result"]["additionalFields"],
                    summary: {"details": data["summary"], "aggregate":data['summaryAggregate'], "summaryByRequest": data["summaryByRequest"], "summaryAggregateByRequest": data["summaryAggregateByRequest"]},
                    missingByPedigree: data["missingByPedigree"],
                    renderGrid: true,
                    allFilterOptions: filterOptions
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured while fetching report data.")
            }.bind(this)
        })
    }

    sendRequestForDownload(){
        const {allFilterOptions} = this.state;
        $.ajax({
            url: urls.customerReportDownloadRoute,
            contentType: 'application/json',
            data:JSON.stringify(allFilterOptions),
            type:'POST',
            cache: true,
            success: function(response) {
                var fileName=response.headers['content-disposition'].split('filename=')[1];
                var blob = base64StringToBlob(response.data, 'application/xlsx');
                const tempLink = document.createElement('a');
                tempLink.style.display = 'none';
                tempLink.href = window.URL.createObjectURL(blob);
                tempLink.setAttribute('download', fileName);
                tempLink.click();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured while fetching report data.")
            }.bind(this)
        })
    }

    onResultRowClick(event, data) {
        // this.setState({
        //     selectedResultRows : data
        // })
    }

    onSummaryRowClick(event, data) {
        // this.setState({
        //     selectedSummaryRows : data
        // })
    }

    onMissingByPedigreeRowClick(event, data) {
        // this.setState({
        //     selectedMissingByPedigreeRows : data
        // })
    }

    downloadData(){
        this.setState({
            downloadData: true
        })
    }

    email(){
        this.setState({
            emailData: true
        })
    }

    deliverRequest(){
        this.setState({
            deliverRequest: true
        })
    }

    getDeliverRequestBtn(reportType){
        let deliverRequestBtn = "";
        if(reportType === ProjectConstants.customer_report.lab_user.type) {
            deliverRequestBtn = (
                <div style={{margin: "0 1vh 0 0"}}>
                    <button className={"btn btn-primary btn-raised btn-xs"}
                            onClick={this.deliverRequest.bind(this)}>Deliver Request
                    </button>
                </div>
            );
        }
        return deliverRequestBtn;
    }

    getEmailBtn(reportType){
        let emailBtn = "";
        if(reportType === ProjectConstants.customer_report.lab_user.type) {
            emailBtn = (
                <div  style={{margin:"0 1vh 0 0"}}>
                    <button className={"btn btn-primary btn-raised btn-xs"} onClick={this.email.bind(this)}>Email</button>
                </div>
            );
        }
        return emailBtn;
    }

    showAllCalls(reportType){
        return reportType === ProjectConstants.customer_report.lab_user.type;
    }

    render(){
        const {renderGrid, result, resultAdditionalFields, summary, missingByPedigree, tissueBoxFilterOptions, pedigreeFilterOptions, assayFilterOptions, reportType, summaryAggregate,
            downloadData, emailData, deliverRequest, selectedProjectId} = this.state;
        let deliverRequestBtn = this.getDeliverRequestBtn(reportType);
        // let emailBtn = this.getEmailBtn(reportType);
        return(
            <div>
                <ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>
                <AjaxLoader/>
                <div id={"Samples-Info"} className={"container-fluid"}>
                    <Modal visible={downloadData} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'downloadData')}>
                        <div className="center-contents-div">
                            <DownloadReport sendRequestForDownload={this.sendRequestForDownload.bind(this)} resultData={result} downloadData={downloadData}/>
                        </div>
                    </Modal>
                    {/*<Modal visible={emailData} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'emailData')}>*/}
                        {/*<div className="center-contents-div">*/}
                            {/*<Email selectedProjectId={selectedProjectId} currentUser={this.props.currentUser}/>*/}
                        {/*</div>*/}
                    {/*</Modal>*/}
                    <Modal visible={deliverRequest} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'deliverRequest')}>
                        <div className="center-contents-div">
                            <DeliverRequest selectedProjectIds={selectedProjectId} currentUser={this.props.currentUser}/>
                        </div>
                    </Modal>
                    <div className={"row"}>
                        <div className={"col-2"} id={"customer-report-filter-options"}>
                            <CustomerReportFilter tissueBoxFilterOptions={tissueBoxFilterOptions} pedigreeFilterOptions={pedigreeFilterOptions} assayFilterOptions={assayFilterOptions}
                                    fetchData={this.fetchData} fetchSamples={this.fetchSamples}/>
                        </div>
                        <div className={"col-10"} id={"customer-report-tbl"}>
                            <div className={"row"}>
                                <div  style={{margin:"0 1vh 0 1vh"}}>
                                    <h4> Customer Report </h4>
                                </div>
                                <div  style={{margin:"0 1vh 0vh 0"}}>
                                    <button className={"btn btn-primary btn-raised btn-xs"} onClick={this.downloadData.bind(this)}>Download</button>
                                </div>
                                {/*{emailBtn}*/}
                                {deliverRequestBtn}
                            </div>
                            <div style={{height:"100%", width:"100%"}}>
                                {renderGrid &&
                                <Tabs forceRenderTabPanel={true}>
                                    <TabList>
                                        <Tab>Result</Tab>
                                        <Tab>Summary</Tab>
                                        <Tab>% Missing by Pedigree</Tab>
                                    </TabList>
                                    <TabPanel>
                                        <CustomerReportResult showAllCalls={this.showAllCalls(reportType)} additionalFields={resultAdditionalFields} data={result} currentUser={this.props.currentUser} onRowClick={this.onResultRowClick.bind(this)}/>
                                    </TabPanel>
                                    <TabPanel>
                                        <CustomerReportSummary data={summary} currentUser={this.props.currentUser} onRowClick={this.onSummaryRowClick.bind(this)}/>
                                    </TabPanel>
                                    <TabPanel>
                                        <CustomerReportPercentMissingByPedigree data={missingByPedigree}
                                                                                currentUser={this.props.currentUser} onRowClick={this.onMissingByPedigreeRowClick.bind(this)}/>
                                    </TabPanel>
                                </Tabs>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        currentUser: state.currentUser
    };
}

export default connect(mapStateToProps)(CustomerReport);

// module.exports = CustomerReport;