import ProjectConstants from '../../../../util/ProjectConstants'

const trace_types = ProjectConstants.trace_types;
const color_configs = {
    [trace_types.hom_fam]:'rgb(0, 159, 134)',
    [trace_types.pos]:'rgb(0, 204, 0)',
    [trace_types.hom_vic]:'rgb(252, 78, 7)',
    [trace_types.neg]:'rgb(51, 51, 204)',
    [trace_types.hemi]:'rgb(231, 184, 0)',
    [trace_types.missing]:'rgb(0, 0, 0)',
    [trace_types.uncallable]:'rgb(204,204,0)',
    [trace_types.fail]:'rgb(255, 0, 0)',
    'S1':'rgb(255,51,255)',
    'S2':'rgb(0,153,76)',
    'S3':'rgb(94,14,148)',
    'S4':'rgb(255,55,255)'
};
let layouts = {
    scatterPlot: {
        revision:"1",
        data: [
            {
                name: trace_types.hom_fam,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hom_fam], size: 5, opacity:[] },
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.hom_vic,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hom_vic], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.hemi,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hemi], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.fail,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.fail], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.standard_controls,
                type: 'scatter', mode: 'markers',
                showlegend: false,
                textfont: {
                    size: 20
                }
            },{
                name: trace_types.pos,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.pos], size: 5, opacity:[] },
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.neg,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.neg], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.uncallable,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.uncallable], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.cherrypicked,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.cherrypicked], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            }
        ],
        layout: {
            hovermode: 'closest',
            autosize: true,
            margin: {
                l: 50,
                r: 35,
                b: 35,
                t: 80
            },
            plot_bgcolor: '#efe6e6',
            showlegend: true,
            title: 'Scatter Plot',
            xaxis: {title: 'Fam Intensity'},
            yaxis: {title: 'Vic Intensity'},
            legend: {
                x: 0,
                y: 1.1,
                orientation: 'h',
                traceorder: 'normal',
                font: {
                    family: 'sans-serif',
                    size: 15,
                    color: '#000'
                },
                bgcolor: 'transparent'
            },
            dragmode: 'lasso'
        },
        frames: [],
        config: {
            editable: false,
            displaylogo: false,
            modeBarButtonsToAdd:[],
            modeBarButtonsToRemove: ['sendDataToCloud', 'hoverCompareCartesian']
        }
    },
    splittedScatterPlot: {
        revision:"2",
        data: [
            {
                name: trace_types.hom_fam,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hom_fam], size: 5, opacity:[] },
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.hom_vic,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hom_vic], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.hemi,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hemi], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.fail,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.fail], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.standard_controls,
                type: 'scatter', mode: 'markers',
                showlegend: false,
                textfont: {
                    size: 20
                }
            },{
                name: trace_types.pos,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.pos], size: 5, opacity:[] },
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.neg,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.neg], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.uncallable,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.uncallable], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            },
            {
                name: trace_types.cherrypicked,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.cherrypicked], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.2
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                    }
                }
            }
        ],
        layout: {
            hovermode: 'closest',
            autosize: true,
            margin: {
                l: 50,
                r: 35,
                b: 35,
                t: 80
            },
            plot_bgcolor: '#efe6e6',
            showlegend: true,
            title: 'Scatter Plot',
            xaxis: {title: 'Fam Intensity', autorange: false},
            yaxis: {title: 'Vic Intensity', autorange: false},
            legend: {
                x: 0,
                y: 1.1,
                orientation: 'h',
                traceorder: 'normal',
                font: {
                    family: 'sans-serif',
                    size: 15,
                    color: '#000'
                },
                bgcolor: 'transparent'
            },
            dragmode: 'lasso'
        },
        frames: [],
        config: {
            editable: false,
            displaylogo: false,
            modeBarButtonsToAdd:[],
            modeBarButtonsToRemove: ['sendDataToCloud', 'hoverCompareCartesian']
        },
        useResizeHandler: true
    },
    sCurve: {
        data: [
            {
                name: trace_types.hom_fam,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hom_fam], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.hom_vic,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hom_vic], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.hemi,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.hemi], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.fail,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.fail], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.standard_controls,
                type: 'scatter', mode: 'markers',
                showlegend: false
            },
            {
                name: trace_types.pos,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.pos], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.neg,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.neg], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.uncallable,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.missing], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            },
            {
                name: trace_types.cherrypicked,
                type: 'scatter', mode: 'markers',
                marker: {color: color_configs[trace_types.cherrypicked], size: 5, opacity:[]},
                unselected:{
                    marker: {
                        opacity: 0.1
                    },
                },
                selected:{
                    marker: {
                        opacity: 1,
                        size: 7
                    }
                }
            }
        ],
        layout: {
            hovermode: 'closest',
            autosize: true,
            margin: {
                l: 50,
                r: 35,
                b: 35,
                t: 80
            },
            plot_bgcolor: '#efe6e6',
            showlegend: true,
            title: 'S-Curve',
            xaxis: {title: 'Rankings'},
            yaxis: {title: 'Fam/Vic'},
            legend: {
                x: 0,
                y: 1.1,
                orientation: 'h',
                traceorder: 'normal',
                font: {
                    family: 'sans-serif',
                    size: 15,
                    color: '#000'
                },
                bgcolor: 'transparent'
            },
            dragmode: 'lasso'
        },
        frames: [],
        config: {
            editable: false,
            displaylogo: false,
            modeBarButtonsToRemove: ['sendDataToCloud', 'hoverCompareCartesian'],
            modeBarButtonsToAdd:[]
        }
    }
};
//https://community.plot.ly/t/unable-to-change-marker-of-selected-points-js/9598
module.exports = {layouts: layouts, colorConfigs: color_configs};