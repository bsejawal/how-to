import React from 'react';
import HtmlParser from 'react-html-parser'
import urls from '../../../../Urls'
import {$} from "../../../../react-table/table/body/Page";
import {toast} from "react-toastify";

const requestDetailsMapping = {
    "projectId":"Request ID",
    "lab":"Lab",
    "crop":"Crop",
    "workflow":"Workflow",
    "dueDate":"Due Date",
    "assignedTo":"Assigned To",
    "outcome":"QC Outcome",
    "totalPlates":"Total Plates",
    "pending":"Pending Plates",
    "okay":"OK Status Count",
    "redo":"REDO Status Count",
    "dropped":"DROP Status Count",
    "priority":"Priority",
    "screeningPurpose":"Screening Purpose",
    "resultRecipients":"Partners Email"
};

class RequestDetails extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            requestDetails: {}
        });
        this.buildRequestDetailsTable = this.buildRequestDetailsTable.bind(this);
        this.fetchRequestDetails = this.fetchRequestDetails.bind(this)
    }

    componentDidMount(){
        this.fetchRequestDetails();
    }

    fetchRequestDetails(){
        $.ajax({
            url: urls.requestDetailsRoute,
            contentType: 'application/json',
            data:JSON.stringify({"projectId":this.props.projectId}),
            type:'POST',
            cache: true,
            success: function(data) {
                this.setState({ requestDetails: data })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching data request details !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    buildRequestDetailsTable(){
        let table = "<div id='request-details-tbl' style='height: 35vh' class='container-fluid'>";
        let requestDetails = this.state.requestDetails;
        let keys = Object.keys(requestDetails);
        for(let key in keys){
            let property = requestDetailsMapping[keys[key]];
            if(typeof property !== 'undefined'){
                table += "<div class='row'>";
                table += "<div class='col-6 request-details-tbl-col'>"+ property+"</div>";
                table += "<div class='col-6 request-details-tbl-col'>"+requestDetails[keys[key]]+"</div>";
                table += "</div>";
            }
        }
        table += "</div>";
        return table;
    }

    render () {
        return (
            <div className="request-details-div">
                <h4>Request Details</h4><button id="refresh" className="button" onClick={this.fetchRequestDetails}>Refresh</button>
                <div style={{height:"20%", overflowY:"scroll"}}>
                {HtmlParser(this.buildRequestDetailsTable())}
                </div>
            </div>
        )
    }
}

module.exports = RequestDetails;