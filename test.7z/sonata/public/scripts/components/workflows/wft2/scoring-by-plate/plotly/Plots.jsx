import React from 'react';
import Plotly from '../../../../../../../node_modules/react-plotly.js/react-plotly'
import plotlyIcons from './Plotly-icons'
import PlotExport from './PlotExport'
import Modal from 'react-awesome-modal';
import $ from 'jquery'
import PlotsLayouts from './layouts'
import {toast} from 'react-toastify'
import ProjectConstants from '../../../../util/ProjectConstants'
import SplittedScatterPlot from './SplittedScatterPlots'
import PlateMapView from "../../PlateMap/GridWrapper"

const _ = require('underscore');

const urls = require('../../../../Urls');
const trace_types = ProjectConstants.trace_types;
const Layouts = PlotsLayouts.layouts;

class App extends React.Component {
    constructor(props) {
        super(props);
        let commonModeBarButtonsToAdd = {
            exportedSelected: {
                name: 'exportSelected',
                title: 'Export Selected',
                _this: this,
                icon: plotlyIcons.download,
                click: this.exportToExcel
            }
        };
        let scatterPlotModeBarButtonsToAdd = {
            maximize: {
                name: 'maximizeScatterPlot',
                title: 'Maximize Plot',
                _this: this,
                icon: plotlyIcons.expand,
                click: this.openModal.bind(this, 'maximizeScatterPlot')
            },
            splitScatterPlot: {
                name: 'splitScatterPlot',
                title: 'Split Plot',
                _this: this,
                icon: plotlyIcons.autoscale,
                click: this.openModal.bind(this, 'splitScatterPlot')
            },
            getPlateMapView: {
                name: 'plateMapView',
                title: 'Plate Map View',
                _this: this,
                icon: plotlyIcons.movie,
                click: this.openModal.bind(this, 'showPlateMapView')
            }
        };
        let sCurvePlotModeBarButtonsToAdd = {
            maximize: {
                name: 'maximizeSCurve',
                title: 'Maximize Plot',
                _this: this,
                icon: plotlyIcons.expand,
                click: this.openModal.bind(this, 'maximizeSCurvePlot')
            }
        };
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(commonModeBarButtonsToAdd.exportedSelected);
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(scatterPlotModeBarButtonsToAdd.splitScatterPlot);
        Layouts.scatterPlot.config.modeBarButtonsToAdd.push(scatterPlotModeBarButtonsToAdd.getPlateMapView);
        Layouts.sCurve.config.modeBarButtonsToAdd.push(commonModeBarButtonsToAdd.exportedSelected);
        this.state = ({
            plotsDiv: {},
            openDownload: false,
            openAssignCall:false,
            maximizeScatterPlot:false,
            splitScatterPlot: false,
            maximizeSCurvePlot:false,
            selectedData: [],
            sCurveData: [],
            vicScatterPlotSelectedPoints : [],
            famScatterPlotSelectedPoints : [],
            hemiScatterPlotSelectedPoints : [],
            failScatterPlotSelectedPoints : [],
            negScatterPlotSelectedPoints : [],
            posScatterPlotSelectedPoints : [],
            uncallableScatterPlotSelectedPoints : [],
            cherrypickedScatterPlotSelectedPoints : [],
            modeBarButtonsToAdd: {commonModeBarButtonsToAdd: commonModeBarButtonsToAdd, scatterPlotModeBarButtonsToAdd: scatterPlotModeBarButtonsToAdd,
                sCurvePlotModeBarButtonsToAdd: sCurvePlotModeBarButtonsToAdd},
            scatterPlotLayouts: Layouts.scatterPlot,
            scurveLayouts: Layouts.sCurve,
            splittedScatterPlotLayouts: Layouts.splittedScatterPlot,
            showPlateMapView: false
        });
        this.onPointsSelection = this.onPointsSelection.bind(this);
        this.onPointsDeselection = this.onPointsDeselection.bind(this);
        this.exportToExcel = this.exportToExcel.bind(this);
        this.attachKeyDownEventToDomForShortCutKeys = this.attachKeyDownEventToDomForShortCutKeys.bind(this);
        this.updatePredictedCall = this.updatePredictedCall.bind(this);
        this.prepareText = this.prepareText.bind(this);
        this.resetScatterPlotSelectedPoints = this.resetScatterPlotSelectedPoints.bind(this);
    }

    componentDidMount(){
        this.attachKeyDownEventToDomForShortCutKeys();
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    exportToExcel() {
        if(this._this.state.selectedData.length > 0){
            this._this.openModal('openDownload');
        }else{
            toast.error("No Data Selected");
        }

    };

    attachKeyDownEventToDomForShortCutKeys(){
        let _this = this;
        let plotsDiv = document.getElementById("plots-by-plate");
        plotsDiv.addEventListener('keydown', function(event){
            if(event.keyCode === 65){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.pos, _this.state.selectedData);
            }else if(event.keyCode === 83){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.neg, _this.state.selectedData);
            }else if(event.keyCode === 68){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.uncallable, _this.state.selectedData);
            }else if(event.keyCode === 32){
                if(_this.state.selectedData.length > 0)
                    _this.updatePredictedCall(trace_types.fail, _this.state.selectedData);
            }
        });
        this.setState({
            plotsDiv: plotsDiv
        })
    }

    updatePredictedCall(predictedCallType, selectedData){
        this.closeModal("openAssignCall");
        let _this = this;
        $.ajax({
            url: urls.updatePredictedCallRoute,
            contentType: 'application/json',
            data: JSON.stringify({userId: this.props.currentUser.id, selectedData: selectedData, predictedCallType: predictedCallType, projectId: this.props.projectId }),
            type:"POST",
            cache: true,
            success: function(data) {
                this.props.reloadData(data, function(){
                    _this.resetScatterPlotSelectedPoints(function(){
                        _this.onPointsDeselection();
                    }());
                }());
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error occured. Cause :: "+err);
            }.bind(this)
        })
    }

    resetScatterPlotSelectedPoints(){
        const {scatterPlotLayouts} = this.state;
        scatterPlotLayouts.data[0].selectedpoints = null;
        scatterPlotLayouts.data[1].selectedpoints = null;
        scatterPlotLayouts.data[2].selectedpoints = null;
        scatterPlotLayouts.data[3].selectedpoints = null;
        scatterPlotLayouts.data[5].selectedpoints = null;
        scatterPlotLayouts.data[6].selectedpoints = null;
        scatterPlotLayouts.data[7].selectedpoints = null;
        scatterPlotLayouts.data[8].selectedpoints = null;
    }

    resetScurvePlotSelectedPoints(){
        const {scurveLayouts} = this.state;
        scurveLayouts.data[0].selectedpoints = null;
        scurveLayouts.data[1].selectedpoints = null;
        scurveLayouts.data[2].selectedpoints = null;
        scurveLayouts.data[3].selectedpoints = null;
        scurveLayouts.data[5].selectedpoints = null;
        scurveLayouts.data[6].selectedpoints = null;
        scurveLayouts.data[7].selectedpoints = null;
        scurveLayouts.data[8].selectedpoints = null;
    }

    onPointsSelection(event) {
        this.state.plotsDiv.focus();
        let _selectedData = [];
        let vicScatterSelectedPoints = [];
        let famScatterSelectedPoints = [];
        let hemiScatterSelectedPoints = [];
        let failScatterSelectedPoints = [];
        let posScatterSelectedPoints = [];
        let negScatterSelectedPoints = [];
        let uncallableScatterSelectedPoints = [];
        let cherrypickedScatterSelectedPoints = [];
        if(event && event.points){
            event.points.forEach(function(point){
                _selectedData.push(point.data.METADATA[point.pointIndex]);
                if(point.data.name === trace_types.fail)
                    failScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.pos)
                    posScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.neg)
                    negScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.uncallable)
                    uncallableScatterSelectedPoints.push(point.pointIndex);
                else if(point.data.name === trace_types.cherrypicked)
                    uncallableScatterSelectedPoints.push(point.pointIndex);
            });
        }

        this.setState({
            selectedData: _selectedData,
            failScatterPlotSelectedPoints: failScatterSelectedPoints,
            posScatterPlotSelectedPoints: posScatterSelectedPoints,
            negScatterPlotSelectedPoints: negScatterSelectedPoints,
            uncallableScatterPlotSelectedPoints: uncallableScatterSelectedPoints,
            cherrypickedScatterPlotSelectedPoints: cherrypickedScatterSelectedPoints,
        }, () => {
            if(event && event.lassoPoints)
                this.openModal('openAssignCall');
        })
    }

    onPointsDeselection(){
        this.setState({
            selectedData: [],
            failScatterPlotSelectedPoints: [],
            posScatterPlotSelectedPoints: [],
            negScatterPlotSelectedPoints: [],
            uncallableScatterPlotSelectedPoints: [],
            cherrypickedScatterPlotSelectedPoints: []
        })
    }

    prepareText(wellInfo){
        let info = "Well: "+wellInfo.wellName+"</br>";
        info += "Name: "+wellInfo.sampleName+"</br>";
        info += "Type: "+wellInfo.sampleClass+"</br>";
        info += "ROX: "+wellInfo.roxIntensity+"</br>";
        info += "VIC: "+wellInfo.vicIntensity+"</br>";
        info += "FAM: "+wellInfo.famIntensity+"</br>";
        info += "Call: "+wellInfo.predictedCall+"</br>";
        info += "Probability: "+wellInfo.maxProbability;
        return info;
    }

    initializePoints(scatterPlotData, sCurveData){
        this.initializeDataPoints(scatterPlotData, sCurveData);
    }

    initializeDataPoints(scatterPlotData, sCurveData){
        const { posScatterPlotSelectedPoints, negScatterPlotSelectedPoints, uncallableScatterPlotSelectedPoints, failScatterPlotSelectedPoints, scurveLayouts,
            cherrypickedScatterPlotSelectedPoints} = this.state;
        _.extend(scatterPlotData[5], this.props.scatterPlotGraphData.pos);
        _.extend(scatterPlotData[5].marker.opacity, this.props.scatterPlotGraphData.pos.opacity);
        _.extend(scatterPlotData[6], this.props.scatterPlotGraphData.neg);
        _.extend(scatterPlotData[6].marker.opacity, this.props.scatterPlotGraphData.neg.opacity);
        _.extend(scatterPlotData[7], this.props.scatterPlotGraphData.uncallable);
        _.extend(scatterPlotData[7].marker.opacity, this.props.scatterPlotGraphData.uncallable.opacity);
        _.extend(scatterPlotData[3], this.props.scatterPlotGraphData.fail);
        _.extend(scatterPlotData[3].marker.opacity, this.props.scatterPlotGraphData.fail.opacity);
        _.extend(scatterPlotData[4], this.props.scatterPlotGraphData.standardControl);

        _.extend(scatterPlotData[8], this.props.scatterPlotGraphData.cherrypicked);
        _.extend(scatterPlotData[8].marker.opacity, this.props.scatterPlotGraphData.cherrypicked.opacity);

        /* this is for auto selection of points in s-curve whenever data is selecetd in scatter plot */
        scurveLayouts.data[5].selectedpoints = posScatterPlotSelectedPoints.length > 0 ? posScatterPlotSelectedPoints : ((negScatterPlotSelectedPoints.length > 0 || uncallableScatterPlotSelectedPoints.length > 0 || failScatterPlotSelectedPoints.length || cherrypickedScatterPlotSelectedPoints.length > 0) > 0 ? [] : null);
        scurveLayouts.data[6].selectedpoints = negScatterPlotSelectedPoints.length > 0 ? negScatterPlotSelectedPoints : ((posScatterPlotSelectedPoints.length > 0 || uncallableScatterPlotSelectedPoints.length > 0 || failScatterPlotSelectedPoints.length || cherrypickedScatterPlotSelectedPoints.length > 0) > 0 ? [] : null);
        scurveLayouts.data[7].selectedpoints = uncallableScatterPlotSelectedPoints.length > 0 ? uncallableScatterPlotSelectedPoints : ((posScatterPlotSelectedPoints.length > 0 || negScatterPlotSelectedPoints.length > 0 || failScatterPlotSelectedPoints.length || cherrypickedScatterPlotSelectedPoints.length > 0) > 0 ? [] : null);
        scurveLayouts.data[3].selectedpoints = failScatterPlotSelectedPoints.length > 0 ? failScatterPlotSelectedPoints : ((posScatterPlotSelectedPoints.length > 0 || negScatterPlotSelectedPoints.length > 0 || uncallableScatterPlotSelectedPoints.length || cherrypickedScatterPlotSelectedPoints.length > 0) > 0 ? [] : null);
        scurveLayouts.data[8].selectedpoints = cherrypickedScatterPlotSelectedPoints.length > 0 ? cherrypickedScatterPlotSelectedPoints : ((posScatterPlotSelectedPoints.length > 0 || negScatterPlotSelectedPoints.length > 0 || uncallableScatterPlotSelectedPoints.length || failScatterPlotSelectedPoints.length > 0) > 0 ? [] : null);

        _.extend(sCurveData[5], this.props.sCurveGraphData.pos);
        _.extend(sCurveData[5].marker.opacity, this.props.sCurveGraphData.pos.opacity);
        _.extend(sCurveData[6], this.props.sCurveGraphData.neg);
        _.extend(sCurveData[6].marker.opacity, this.props.sCurveGraphData.neg.opacity);
        _.extend(sCurveData[7], this.props.sCurveGraphData.uncallable);
        _.extend(sCurveData[7].marker.opacity, this.props.sCurveGraphData.uncallable.opacity);
        _.extend(sCurveData[3], this.props.sCurveGraphData.fail);
        _.extend(sCurveData[3].marker.opacity, this.props.sCurveGraphData.fail.opacity);
        _.extend(sCurveData[4], this.props.sCurveGraphData.standardControl);

        _.extend(sCurveData[8], this.props.sCurveGraphData.cherrypicked);
        _.extend(sCurveData[8].marker.opacity, this.props.sCurveGraphData.cherrypicked.opacity);
    }

    customizeScatterPlotForMaximizing(){
        const {maximizeScatterPlot, modeBarButtonsToAdd, scatterPlotLayouts } = this.state;
        let name = modeBarButtonsToAdd.scatterPlotModeBarButtonsToAdd.maximize.name;
        if(maximizeScatterPlot){
            this.removeFromObjArray(scatterPlotLayouts.config.modeBarButtonsToAdd,"name",name);
        }else{
            if (scatterPlotLayouts.config.modeBarButtonsToAdd.findIndex(o => o.name === name) < 1){
                scatterPlotLayouts.config.modeBarButtonsToAdd.push(modeBarButtonsToAdd.scatterPlotModeBarButtonsToAdd.maximize);
            }
        }
    }

    customizeSCurvePlotForMaximizing(){
        const {maximizeSCurvePlot, modeBarButtonsToAdd, scurveLayouts } = this.state;
        let name = modeBarButtonsToAdd.sCurvePlotModeBarButtonsToAdd.maximize.name;
        if(maximizeSCurvePlot){
            this.removeFromArray(scurveLayouts.config.modeBarButtonsToAdd,name);
        }else{
            if (scurveLayouts.config.modeBarButtonsToAdd.findIndex(o => o.name === name) < 1){
                scurveLayouts.config.modeBarButtonsToAdd.push(modeBarButtonsToAdd.sCurvePlotModeBarButtonsToAdd.maximize);
            }
        }
    }

    removeFromObjArray(arr, prop, value){
        let index = arr.findIndex(obj => obj[prop] === value);
        if(index > 0){
            arr.splice(index, 1);
        }
    }

    removeFromArray(arr, value){
        let index = arr.findIndex(i => arr[i] === value);
        if(index > 0){
            arr.splice(index, 1);
        }
    }

    render() {
        const { openDownload, openAssignCall, selectedData, maximizeScatterPlot, maximizeSCurvePlot, splitScatterPlot, scurveLayouts, scatterPlotLayouts, showPlateMapView } = this.state;
        let scatterPlotData = Object.assign([], scatterPlotLayouts.data);
        let sCurveData = Object.assign([], scurveLayouts.data);
        this.initializePoints(scatterPlotData, sCurveData);
        this.customizeScatterPlotForMaximizing();
        this.customizeSCurvePlotForMaximizing();
        let selectedRows = this.props.selectedRows;
        let plateIds = [];
        for(var key in selectedRows){
            plateIds.push(selectedRows[key].data.plateId);
        }
        let scatterPlot = (
            <Plotly
                divId={"mainScatterPlot"}
                data={scatterPlotData}
                layout={scatterPlotLayouts.layout}
                frames={scatterPlotLayouts.frames}
                config={scatterPlotLayouts.config}
                useResizeHandler={true}
                style={{height:'100%', width:'100%'}}
                onSelected={(selectedPoints) => {
                    this.onPointsSelection(selectedPoints)
                }}
                onDeselect={() => {
                    this.onPointsDeselection();
                }}
            />
        );
        let scurve = (
            <Plotly
                divId={"mainSCurve"}
                data={sCurveData}
                layout={scurveLayouts.layout}
                frames={scurveLayouts.frames}
                config={scurveLayouts.config}
                useResizeHandler={true}
                style={{height:'100%', width:'100%'}}
                onSelected={(selectedPoints) => {
                    this.onPointsSelection(selectedPoints)
                }}
                onDeselect={() => {
                    this.onPointsDeselection();
                }}
            />
        );
        let assignAnalyst;
        assignAnalyst = (
            <div>
                <h3>Assign Call</h3>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.pos, selectedData)} value={trace_types.pos}/> POS (A)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.neg, selectedData)} value={trace_types.neg}/> NEG (S)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.uncallable, selectedData)} value={trace_types.uncallable}/> UNCALLABLE (D)<br/>
                <input type="radio" name="scoringoption" onClick={this.updatePredictedCall.bind(this,trace_types.fail, selectedData)} value={trace_types.fail}/> FAIL (SPACE)<br/>
            </div>
        );
        return (
            <div id="plot-row-by-plate" className={"outline0"}>
                {/* all modals */}
                <div>
                    <Modal visible={splitScatterPlot} width="1400" height="900" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'splitScatterPlot')}>
                        <SplittedScatterPlot currentUser={this.props.currentUser} splitScatterPlot={splitScatterPlot} reloadData={this.props.reloadData}
                                             scatterPlotDataByPlates={this.props.scatterPlotDataByPlate} projectId={this.props.projectId} workflowType={this.props.workflowType}
                                             updatePredictedCall={this.updatePredictedCall} projectType={this.props.projectType} labCode={this.props.labCode}
                        />
                    </Modal>
                    <Modal visible={maximizeScatterPlot} width="1400" height="900" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'maximizeScatterPlot')}>
                        {scatterPlot}
                    </Modal>
                    <Modal visible={maximizeSCurvePlot} width="1400" height="900" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'maximizeSCurvePlot')}>
                        {scurve}
                    </Modal>
                    <Modal visible={openAssignCall} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openAssignCall')}>
                        <div className="center-contents-div">
                            {assignAnalyst}
                        </div>
                    </Modal>
                    <Modal visible={openDownload} width="400" height="300" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openDownload')}>
                        <div className="center-contents-div">
                            <PlotExport excelData={selectedData}/>
                        </div>
                    </Modal>
                    {showPlateMapView &&
                        <Modal visible={showPlateMapView} width="1500" height="900" effect="fadeInUp"
                               onClickAway={this.closeModal.bind(this, 'showPlateMapView')}>
                            <PlateMapView projectId={this.props.projectId} plateIds={plateIds}
                                          workflowType={this.props.workflowType}/>
                        </Modal>
                    }
                </div>
                <div>
                    <div style={{height:'42vh', width:'55vh'}}>
                        {scatterPlot}
                    </div>
                    <div style={{height:'42vh', width:'55vh'}}>
                        {scurve}
                    </div>
                </div>
            </div>
        );
    }
}

module.exports = App;