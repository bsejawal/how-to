import React from 'react';
import {$} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";
import {toast} from "react-toastify";

class ReadyToReviewData extends React.Component {
    constructor(props){
        super(props);
        this.state = ({

        })
    }

    notifyForReview(){
        $.ajax({
            url: urls.readyToReviewRoute,
            contentType: 'application/json',
            data:JSON.stringify({projectId: this.props.projectId, userId: this.props.currentUser.email}),
            type:'POST',
            cache: true,
            success: function(data) {
                let status = data["status"];
                if(status === "1"){
                    toast.error("Error notifying PST users. Please check server logs.")
                }else{
                    toast.success("Notified PST user successfully!")
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error notifying PST users. Please check server logs..");
            }.bind(this)
        });
    }

    render(){
        return(
            <div>
                <h4 className={"center-contents-div"}>Ready To Review Data For {this.props.projectId} ?</h4>
                <span className={"center-contents-div"}><button className="button" onClick={this.notifyForReview.bind(this)}> Submit </button></span>
            </div>
        )
    }
}

module.exports = ReadyToReviewData;