import React from 'react';
import {$} from "../../../react-table/table/body/Page";
import urls from "../../../Urls";
import {toast} from "react-toastify";

class UpdateProject extends React.Component {
    constructor(props){
        super(props);
        this.state= ({

        })
    }

    sendBackToLab(){
        $.ajax({
            url: urls.updateProjectRoute,
            contentType: 'application/json',
            data:JSON.stringify([{requestId: this.props.projectId, setToInProcess: 'true'}]),
            type:'POST',
            cache: true,
            success: async function(data) {
                if(data["status"] === "0") {
                    toast.success("Request updated successfully.");
                    window.location.reload(true);
                }
                else {
                    toast.error("Error while updating.. please check server logs.")
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while updating request !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    render(){
        return(
            <div>
                <h4 className={"center-contents-div"}>Send {this.props.projectId} back to lab ?</h4>
                <span className={"center-contents-div"}><button className="button" onClick={this.sendBackToLab.bind(this)}> Submit </button></span>
            </div>
        )
    }

}

module.exports = UpdateProject;