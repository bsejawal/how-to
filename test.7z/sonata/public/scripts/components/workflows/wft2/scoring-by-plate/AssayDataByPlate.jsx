import React from 'react';
import {$, DataGrid} from '../../../react-table/table/body/Page.js';
import Plots from './plotly/Plots'
import {connect} from 'react-redux'
import _ from 'underscore'
import Modal from 'react-awesome-modal';
import {toast, ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import SubmitRedo from '../../../SubmitRedo'
import ReadyToReview from './ReadyToReviewData'
import UpdateProject from './UpdateProject'
import Select from 'react-select'
import ProjectConstants from '../../../util/ProjectConstants'
import {colorConfigs} from './plotly/layouts'
import orderby from 'lodash.orderby';

import urls from '../../../Urls';
import Notes from "../../../Notes";

const Config = require ('../../../config/workflows/wft2/AssayDataByPlateConfig');
const trace_types = ProjectConstants.trace_types;
// const STRD_CTRL_FONT_COLOR = {"S1":"#9467bd","S2":"#FF5733","S3":"FF5233","S4":"","S5":"","S6":"","Z":"","E":""};


class AssayDataByPlate extends React.Component {
    constructor(props) {
        super(props);
        this.fetchData = this.fetchData.bind(this);
        this.fetchConfig = this.fetchConfig.bind(this);
        this.onRowClick = this.onRowClick.bind(this);
        this.getNormalizedIntensities = this.getNormalizedIntensities.bind(this);
        this.setWellData = this.setWellData.bind(this);
        this.reloadData = this.reloadData.bind(this);
        this.submitRedo = this.submitRedo.bind(this);
        this.readyToReview = this.readyToReview.bind(this);
        this.sendBackToLab = this.sendBackToLab.bind(this);
        this.state = { projectId: this.props.match.params.requestId, projectType:"", labCode: "", workflowType: this.props.match.params.wf,
            data: [], requestDetails: {}, notificationMessage: "",
            scatterPlotData: {hom_fam:{}, hom_vic:{}, hemi: {}, fail:{}, pos: {}, neg: {}, uncallable: {}, cherrypicked: {}},
            sCurvePlotData: {hom_fam:{}, hom_vic:{}, hemi: {}, fail:{}, pos: {}, neg: {}, uncallable: {}, cherrypicked: {}},
            wellsData: {}, openUpdateProjectModal: false,
            gridConfig : [], renderGrid: false, selectedRows: {}, appCode: ProjectConstants["app-codes"].ASSAY_DATA_BY_PLATE_WFT2,
            openSubmitRedoModal: false,openDeliverRequestModal: false, statusInfo_redo: [], statusInfo_okay: [], statusInfo_drop: [],
            statusInfo_selectedDefault:{},statusInfo_selected:{}, totalPlates:0, statusCounts:{}, currentUser: {}, statusOptions: [],
            statusObjs: {}, scatterPlotDataByPlate: {}, recentSelectedStatus: {},
            openReadyToReviewModal: false, projectStatus: ""
        };
        this.modifiedNotes = {};
    }

    componentDidMount() {
        this.startListeningToNewArrivals();
        $.ajax({
            url: urls.getStatusListRoute,
            contentType: 'application/json',
            data:JSON.stringify({"applicationCode": "assay-data", "dropdownCode": "status", "projectId": this.state.projectId}),
            type:'POST',
            cache: true,
            success: function(data) {
                let statusObject = this.prepareStatus(data);
                this.setState({
                    statusOptions: statusObject.statusOptions,
                    statusObjs: statusObject.statusObjs
                }, () => this.fetchData() )
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching data from api !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    reloadPage(){
        window.location.reload(true);
    }

    createNewArrivalsNotificationDiv(){
        return (
            <div>New plates arrived for this Project. Would you like to reload page? <button className={"button"} onClick={this.reloadPage}>Reload</button></div>
        )
    }

    startListeningToNewArrivals(){
        // let _this = this;
        // var eventSource = new EventSource(urls.listenerUrl);
        // eventSource.addEventListener(this.state.projectId, function(e) {
        //     toast.success(({ closeToast }) => _this.createNewArrivalsNotificationDiv());
        // });
    }

    onRowClick(event, data, rowId){
        let normalizedFAMIntensity_FAIL = [];
        let normalizedFAMIntensity_NEG = [];
        let normalizedFAMIntensity_POS = [];
        let normalizedFAMIntensity_MISSING = [];
        let normalizedFAMIntensity_CHERRYPICKED = [];

        let normalizedVICIntensity_FAIL = [];
        let normalizedVICIntensity_POS = [];
        let normalizedVICIntensity_NEG = [];
        let normalizedVICIntensity_MISSING = [];
        let normalizedVICIntensity_CHERRYPICKED = [];

        let standardControlFAM = [];
        let standardControlVIC = [];
        let standardControlVicByFam = [];

        let normalized_FAIL_metadata = [];
        let normalized_POS_metadata = [];
        let normalized_NEG_metadata = [];
        let normalized_MISSING_metadata = [];
        let normalized_CHERRYPICKED_metadata = [];
        let standardControl_metadata = [];

        let standardControl_text = [];
        let standardControl_text_fontColor = [];

        let fail_hoverText = [];
        let pos_hoverText = [];
        let neg_hoverText = [];
        let missing_hoverText = [];
        let cherrypicked_hoverText = [];
        let standardControl_hoverText = [];

        // for s-curve
        let normalizedVicByFamIntensity_FAIL = [];
        let normalizedVicByFamIntensity_POS = [];
        let normalizedVicByFamIntensity_NEG = [];
        let normalizedVicByFamIntensity_MISSING = [];
        let normalizedVicByFamIntensity_CHERRYPICKED = [];

        let FAIL_RANGE = [];
        let POS_RANGE = [];
        let NEG_RANGE = [];
        let MISSING_RANGE = [];
        let CHERRYPICKED_RANGE = [];
        let standardControlRange = [];

        let opacity_FAIL = [];
        let opacity_POS = [];
        let opacity_NEG = [];
        let opacity_MISSING = [];
        let opacity_CHERRYPICKED = [];

        let rows = data;

        let scatterPlotDataByPlate = {};

        let id = 1;
        for(let row in rows){
            let _temp = this.getNormalizedIntensities(this.state.wellsData[row], row, rows[row]["data"]["markerName"], id);
            normalizedFAMIntensity_FAIL.push(..._temp.fam_fail);
            normalizedFAMIntensity_POS.push(..._temp.fam_pos);
            normalizedFAMIntensity_NEG.push(..._temp.fam_neg);
            normalizedFAMIntensity_MISSING.push(..._temp.fam_missing);
            normalizedFAMIntensity_CHERRYPICKED.push(..._temp.fam_cherrypicked);

            normalizedVICIntensity_FAIL.push(..._temp.vic_fail);
            normalizedVICIntensity_POS.push(..._temp.vic_pos);
            normalizedVICIntensity_NEG.push(..._temp.vic_neg);
            normalizedVICIntensity_MISSING.push(..._temp.vic_missing);
            normalizedVICIntensity_CHERRYPICKED.push(..._temp.vic_cherrypicked);

            standardControlVIC.push(..._temp.standardControl_vic);
            standardControlFAM.push(..._temp.standardControl_fam);

            standardControlVicByFam.push(..._temp.standardControlVicByFam);

            normalizedVicByFamIntensity_FAIL.push(..._temp.vicByFam_fail);
            normalizedVicByFamIntensity_POS.push(..._temp.vicByFam_pos);
            normalizedVicByFamIntensity_NEG.push(..._temp.vicByFam_neg);
            normalizedVicByFamIntensity_MISSING.push(..._temp.vicByFam_missing);
            normalizedVicByFamIntensity_CHERRYPICKED.push(..._temp.vicByFam_cherrypicked);

            FAIL_RANGE.push(..._temp.fail_range);
            POS_RANGE.push(..._temp.pos_range);
            NEG_RANGE.push(..._temp.neg_range);
            MISSING_RANGE.push(..._temp.missing_range);
            CHERRYPICKED_RANGE.push(..._temp.cherrypicked_range);
            standardControlRange.push(..._temp.standardControlRange);

            normalized_FAIL_metadata.push(..._temp.fail_metadata);
            normalized_POS_metadata.push(..._temp.pos_metadata);
            normalized_NEG_metadata.push(..._temp.neg_metadata);
            normalized_MISSING_metadata.push(..._temp.missing_metadata);
            normalized_CHERRYPICKED_metadata.push(..._temp.cherrypicked_metadata);
            standardControl_metadata.push(..._temp.standardControl_metadata);

            standardControl_text.push(..._temp.standardControl_text);
            standardControl_text_fontColor.push(..._temp.standardControl_text_fontColor);

            fail_hoverText.push(..._temp.fail_hoverText);
            pos_hoverText.push(..._temp.pos_hoverText);
            neg_hoverText.push(..._temp.neg_hoverText);
            missing_hoverText.push(..._temp.missing_hoverText);
            cherrypicked_hoverText.push(..._temp.cherrypicked_hoverText);
            standardControl_hoverText.push(..._temp.standardControl_hoverText);

            opacity_FAIL.push(..._temp.opacity_fail);
            opacity_POS.push(..._temp.opacity_pos);
            opacity_NEG.push(..._temp.opacity_neg);
            opacity_MISSING.push(..._temp.opacity_missing);
            opacity_CHERRYPICKED.push(..._temp.opacity_cherrypicked);

            scatterPlotDataByPlate[row] = {
                neg: {marker: {opacity: _temp.opacity_neg}, y: _temp.vic_neg, x: _temp.fam_neg, METADATA: _temp.neg_metadata, hovertext: _temp.neg_hoverText, opacity: _temp.opacity_neg},
                pos: {marker: {opacity: _temp.opacity_pos}, y: _temp.vic_pos, x: _temp.fam_pos, METADATA: _temp.pos_metadata, hovertext: _temp.pos_hoverText, opacity: _temp.opacity_pos},
                missing: {marker: {opacity: _temp.opacity_missing}, y: _temp.vic_missing, x: _temp.fam_missing, METADATA: _temp.missing_metadata, hovertext: _temp.missing_hoverText, opacity: _temp.opacity_missing},
                fail: {marker: {opacity: _temp.opacity_fail}, y: _temp.vic_fail, x: _temp.fam_fail, METADATA: _temp.fail_metadata, hovertext: _temp.fail_hoverText, opacity: _temp.opacity_fail},
                cherrypicked: {marker: {opacity: _temp.opacity_cherrypicked}, y: _temp.vic_cherrypicked, x: _temp.fam_cherrypicked, METADATA: _temp.cherrypicked_metadata, hovertext: _temp.cherrypicked_hoverText, opacity: _temp.opacity_cherrypicked},
                standardControl: {y: _temp.standardControl_vic, x: _temp.standardControl_fam, METADATA: _temp.standardControl_metadata, hovertext: _temp.standardControl_hoverText,
                    marker: {symbol: _temp.standardControl_text, color: _temp.standardControl_text_fontColor, size: 10, opacity: 0.8 }
                },
                range_x_lower: _temp.fam_lower_range, range_x_upper: _temp.fam_upper_range, range_y_lower: _temp.vic_lower_range, range_y_upper: _temp.vic_upper_range,
                ids: _temp.ids
            }

            id=+_temp.ids[_temp.ids.length-1]+1;
        }

        this.setState({
            scatterPlotData: {
                pos: {y: normalizedVICIntensity_POS, x: normalizedFAMIntensity_POS, METADATA: normalized_POS_metadata, hovertext: pos_hoverText, opacity: opacity_POS},
                neg: {y: normalizedVICIntensity_NEG, x: normalizedFAMIntensity_NEG, METADATA: normalized_NEG_metadata, hovertext: neg_hoverText, opacity: opacity_NEG},
                uncallable: {y: normalizedVICIntensity_MISSING, x: normalizedFAMIntensity_MISSING, METADATA: normalized_MISSING_metadata, hovertext: missing_hoverText, opacity: opacity_MISSING},
                fail: {y: normalizedVICIntensity_FAIL, x: normalizedFAMIntensity_FAIL, METADATA: normalized_FAIL_metadata, hovertext: fail_hoverText, opacity: opacity_FAIL},
                cherrypicked: {y: normalizedVICIntensity_CHERRYPICKED, x: normalizedFAMIntensity_CHERRYPICKED, METADATA: normalized_CHERRYPICKED_metadata, hovertext: cherrypicked_hoverText, opacity: opacity_CHERRYPICKED},
                standardControl: {y: standardControlVIC, x: standardControlFAM, METADATA: standardControl_metadata, hovertext: standardControl_hoverText,
                    marker: {symbol: standardControl_text, color: standardControl_text_fontColor, size: 10, opacity: 0.8 }
                }
            },
            sCurvePlotData: {
                pos: {x: POS_RANGE, y: normalizedVicByFamIntensity_POS, METADATA: normalized_POS_metadata, hovertext: pos_hoverText, opacity: opacity_POS },
                neg: {x: NEG_RANGE, y: normalizedVicByFamIntensity_NEG, METADATA: normalized_NEG_metadata, hovertext: neg_hoverText, opacity: opacity_NEG },
                uncallable: { x: MISSING_RANGE, y: normalizedVicByFamIntensity_MISSING,  METADATA: normalized_MISSING_metadata, hovertext: missing_hoverText, opacity: opacity_MISSING },
                fail: { x: FAIL_RANGE, y: normalizedVicByFamIntensity_FAIL, METADATA: normalized_FAIL_metadata, hovertext: fail_hoverText, opacity: opacity_FAIL },
                cherrypicked: { x: CHERRYPICKED_RANGE, y: normalizedVicByFamIntensity_CHERRYPICKED, METADATA: normalized_CHERRYPICKED_metadata, hovertext: cherrypicked_hoverText, opacity: opacity_CHERRYPICKED },
                standardControl: {x: standardControlRange, y: standardControlVicByFam, METADATA: standardControl_metadata, hovertext: standardControl_hoverText,
                    marker: {symbol: standardControl_text, color: standardControl_text_fontColor, size: 10, opacity: 0.8 }
                }
            }
            , selectedRows: data, scatterPlotDataByPlate: scatterPlotDataByPlate
        });
    }

    getNormalizedIntensities(wells, plateMarkerId, markerName, id){
        // for scatter plot
        let normalizedFAMIntensity_FAIL = [];
        let normalizedFAMIntensity_POS = [];
        let normalizedFAMIntensity_NEG = [];
        let normalizedFAMIntensity_MISSING = [];
        let normalizedFAMIntensity_CHERRYPICKED = [];

        let normalizedVICIntensity_FAIL = [];
        let normalizedVICIntensity_POS = [];
        let normalizedVICIntensity_NEG = [];
        let normalizedVICIntensity_MISSING = [];
        let normalizedVICIntensity_CHERRYPICKED = [];

        let standardControlFAM = [];
        let standardControlVIC = [];
        let standardControlVicByFam = [];
        let standardControlRange = [];

        let normalized_FAIL_metadata = [];
        let normalized_POS_metadata = [];
        let normalized_NEG_metadata = [];
        let normalized_MISSING_metadata = [];
        let normalized_CHERRYPICKED_metadata = [];
        let standardControl_metadata = [];

        let fail_hoverText = [];
        let pos_hoverText = [];
        let neg_hoverText = [];
        let missing_hoverText = [];
        let cherrypicked_hoverText = [];
        let standardControl_hoverText = [];

        let standardControl_text = [];
        let standardControl_text_fontColor = [];

        // for s-curve
        let normalizedVicByFamIntensity_FAIL = [];
        let normalizedVicByFamIntensity_POS = [];
        let normalizedVicByFamIntensity_NEG = [];
        let normalizedVicByFamIntensity_MISSING = [];
        let normalizedVicByFamIntensity_CHERRYPICKED = [];

        let FAIL_RANGE = [];
        let POS_RANGE = [];
        let NEG_RANGE = [];
        let MISSING_RANGE = [];
        let CHERRYPICKED_RANGE = [];

        let opacity_FAIL = [];
        let opacity_POS = [];
        let opacity_NEG = [];
        let opacity_MISSING = [];
        let opacity_CHERRYPICKED = [];

        wells = orderby(wells,['ratio'],['asc']);
        let fam_lower_range = 20, fam_upper_range = -20, vic_lower_range = 20, vic_upper_range = -20;
        let ids = [];
        for(let well in wells){
            ids.push(""+ id++);
            var _tempWell = wells[well];
            _tempWell["plateMarkerId"] = plateMarkerId;
            _tempWell["markerName"] = markerName;
            let vicByFam = _tempWell["ratio"];
            _tempWell["sampleRankings"] = vicByFam;
            let famByRox = _tempWell.famIntensity / _tempWell.roxIntensity;
            let vicByRox = _tempWell.vicIntensity / _tempWell.roxIntensity;

            if(famByRox < fam_lower_range)
                fam_lower_range = famByRox;
            if(famByRox > fam_upper_range)
                fam_upper_range = famByRox;
            if(vicByRox < vic_lower_range)
                vic_lower_range = vicByRox;
            if(vicByRox > vic_upper_range)
                vic_upper_range = vicByRox;

            if( _.isUndefined(_tempWell.standardControl) ||
                _.isNull(_tempWell.standardControl) ||
                _tempWell.standardControl === ""
            ){
                // fail
                if(_tempWell.predictedCall.toLowerCase() === trace_types.fail.toLowerCase()){
                    normalizedFAMIntensity_FAIL.push(famByRox);
                    normalizedVICIntensity_FAIL.push(vicByRox);
                    normalized_FAIL_metadata.push(_tempWell);
                    fail_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_FAIL.push(vicByFam);
                    FAIL_RANGE.push(well);

                    opacity_FAIL.push(_tempWell.maxCallProbability);
                    // pos
                }else if(_tempWell.predictedCall.toLowerCase() === trace_types.pos.toLowerCase()){
                    normalizedFAMIntensity_POS.push(famByRox);
                    normalizedVICIntensity_POS.push(vicByRox);
                    normalized_POS_metadata.push(_tempWell);
                    pos_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_POS.push(vicByFam);
                    POS_RANGE.push(well);

                    opacity_POS.push(_tempWell.maxCallProbability);
                    //neg
                }else if(_tempWell.predictedCall.toLowerCase() === trace_types.neg.toLowerCase()){
                    normalizedFAMIntensity_NEG.push(famByRox);
                    normalizedVICIntensity_NEG.push(vicByRox);
                    normalized_NEG_metadata.push(_tempWell);
                    neg_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_NEG.push(vicByFam);
                    NEG_RANGE.push(well);

                    opacity_NEG.push(_tempWell.maxCallProbability);
                    // missing
                }else if(_tempWell.predictedCall.toLowerCase() === trace_types.missing.toLowerCase()
                    || _tempWell.predictedCall.toLowerCase() === trace_types.uncallable.toLowerCase()){
                    normalizedFAMIntensity_MISSING.push(famByRox);
                    normalizedVICIntensity_MISSING.push(vicByRox);
                    normalized_MISSING_metadata.push(_tempWell);
                    missing_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_MISSING.push(vicByFam);
                    MISSING_RANGE.push(well);

                    opacity_MISSING.push(_tempWell.maxCallProbability);
                }else if(_tempWell.predictedCall.toLowerCase() === trace_types.cherrypicked.toLowerCase()){
                    normalizedFAMIntensity_CHERRYPICKED.push(famByRox);
                    normalizedVICIntensity_CHERRYPICKED.push(vicByRox);
                    normalized_CHERRYPICKED_metadata.push(_tempWell);
                    cherrypicked_hoverText.push(this.prepareText(_tempWell));

                    normalizedVicByFamIntensity_CHERRYPICKED.push(vicByFam);
                    CHERRYPICKED_RANGE.push(well);

                    opacity_CHERRYPICKED.push(_tempWell.maxCallProbability);
                }
            } else{
                standardControlFAM.push(famByRox);
                standardControlVIC.push(vicByRox);
                standardControl_metadata.push(_tempWell);
                standardControl_hoverText.push(this.prepareText(_tempWell));

                standardControlVicByFam.push(vicByFam);
                standardControlRange.push(well);

                standardControl_text.push(this.getStandardControlsText(_tempWell.standardControl));
                standardControl_text_fontColor.push(colorConfigs[_tempWell.standardControl]);
            }
        }
        return {
            "fam_fail": normalizedFAMIntensity_FAIL,
            "vic_fail": normalizedVICIntensity_FAIL,
            "fail_metadata": normalized_FAIL_metadata,
            "fail_hoverText":fail_hoverText,

            "fam_pos": normalizedFAMIntensity_POS, "fam_neg": normalizedFAMIntensity_NEG, "fam_missing": normalizedFAMIntensity_MISSING,
            "vic_pos": normalizedVICIntensity_POS, "vic_neg": normalizedVICIntensity_NEG, "vic_missing": normalizedVICIntensity_MISSING,
            "pos_metadata": normalized_POS_metadata, "neg_metadata": normalized_NEG_metadata, "missing_metadata": normalized_MISSING_metadata,
            "pos_hoverText":pos_hoverText, "neg_hoverText":neg_hoverText, "missing_hoverText":missing_hoverText,

            "fam_cherrypicked": normalizedFAMIntensity_CHERRYPICKED,
            "vic_cherrypicked": normalizedVICIntensity_CHERRYPICKED,
            "cherrypicked_metadata": normalized_CHERRYPICKED_metadata,
            "cherrypicked_hoverText": cherrypicked_hoverText,

            "vicByFam_fail": normalizedVicByFamIntensity_FAIL, "fail_range":FAIL_RANGE,

            "vicByFam_pos": normalizedVicByFamIntensity_POS, "vicByFam_neg": normalizedVicByFamIntensity_NEG, "vicByFam_missing": normalizedVicByFamIntensity_MISSING,
            "pos_range":POS_RANGE, "neg_range":NEG_RANGE, "missing_range": MISSING_RANGE,

            "vicByFam_cherrypicked": normalizedVicByFamIntensity_CHERRYPICKED,
            "cherrypicked_range": CHERRYPICKED_RANGE,

            "standardControl_fam": standardControlFAM, "standardControl_vic": standardControlVIC, "standardControlVicByFam": standardControlVicByFam, "standardControlRange": standardControlRange,
            "standardControl_metadata": standardControl_metadata, "standardControl_text_fontColor": standardControl_text_fontColor,
            "standardControl_hoverText": standardControl_hoverText, "standardControl_text": standardControl_text,

            "opacity_fail": opacity_FAIL,
            "opacity_pos": opacity_POS, "opacity_neg": opacity_NEG, "opacity_missing": opacity_MISSING,

            "opacity_cherrypicked": opacity_CHERRYPICKED,

            "fam_lower_range": fam_lower_range, "fam_upper_range": fam_upper_range,
            "vic_lower_range": vic_lower_range, "vic_upper_range": vic_upper_range,

            "ids": ids
        }
    }

    getStandardControlsText(control){
        if(control === 'S1')
            return 'diamond';
        else if(control === 'S2')
            return 'triangle-up';
        else if(control === 'S3')
            return 'square';
        else if(control === 'S4')
            return 'diamond';
    }

    prepareText(wellInfo){
        let info = "Well: "+wellInfo.wellName+"<br>";
        info += "Ratio: "+wellInfo.ratio+"<br>";
        info += "ROX: "+wellInfo.roxIntensity+"<br>";
        info += "VIC: "+wellInfo.vicIntensity+"<br>";
        info += "FAM: "+wellInfo.famIntensity+"<br>";
        info += "Call: "+wellInfo.predictedCall+"<br>";
        info += "Probability: "+wellInfo.maxCallProbability+"<br>";
        info += "SampleId: "+wellInfo.sampleId;
        return info;
    }

    prepareStatus(statusArr){
        let statusOptions = [];
        let statusObjs = {};
        let description = "", code = "";
        for(let obj in statusArr){
            description = statusArr[obj]["description"];
            code = statusArr[obj]["code"];
            statusOptions.push({label: description, value: code});
            statusObjs[code] = description
        }
        return {statusOptions, statusObjs};
    }

    reloadData(data){
        this.setState({
            data: data,
            wellsData: this.setWellData(data).wellData
        },() =>{ this.onRowClick({}, this.state.selectedRows) })
    }

    fetchData(){
        let requestId = this.state.projectId;
        $.ajax({
            url: urls.assayDataRoute+(requestId?"?projectId="+requestId:""),
            contentType: 'application/json',
            data:{},
            type:'GET',
            cache: true,
            success: function(data) {
                this.fetchConfig(data);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching data from api !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        })
    }

    fetchConfig(gridData){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, appCode: this.state.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                let _wellData = this.setWellData(gridData.markerPlateVOList);
                if(!(data.length > 0)) data = Config;
                this.setState({data:gridData.markerPlateVOList, totalPlates: gridData.markerPlateVOList.length, renderGrid:true,
                    projectType: gridData.project.projectType, labCode: gridData.project.labCode, projectStatus: gridData.project.projectStatus,
                    gridConfig: data, wellsData: _wellData.wellData, statusCounts: gridData.statusCount, currentUser: this.props.currentUser}, () => {
                    // this.onRowClick(null, this.state.selectedRows)
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    setWellData(data){
        let wellData = {};
        for( let row in data){
            var _thisData = data[row];
            wellData[_thisData.plateMarkerId] = _thisData.wells;
            _thisData.wells = []
        }
        return {"wellData": wellData};
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    submitRedo(){
        this.setState({
            openSubmitRedoModal: true
        })
    }

    readyToReview(){
        this.setState({
            openReadyToReviewModal: true
        })
    }
    sendBackToLab(){
        this.setState({
            openUpdateProjectModal: true
        })
    }

    saveStatus(rowId, selectedOption){
        $.ajax({
            url: urls.savePlateStatusRoute,
            contentType: 'application/json',
            data:JSON.stringify({plateMarkerId: rowId, status: selectedOption.value, projectId: this.state.projectId, userId: this.props.currentUser.id}),
            type:'POST',
            cache: true,
            success: function(data) {
                let statusInfo_selected = this.state.statusInfo_selected;
                statusInfo_selected[rowId] = selectedOption.label;
                this.setState({
                    statusCounts:data,
                    statusInfo_selected: statusInfo_selected,
                    recentSelectedStatus: selectedOption.label !== null? selectedOption : this.state.recentSelectedStatus
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration. ");
            }.bind(this)
        });
    }

    handleStatusDropDownChange(rowId, selectedOption){
        if(_.isEmpty(selectedOption)){ selectedOption.value = ""; selectedOption.label = null }
        // const {statusInfo_selected} = this.state;
        // statusInfo_selected[rowId] = selectedOption.label;
        this.saveStatus(rowId, selectedOption);
    }

    removeFromObjArray(arr, prop, value){
        let index = this.findIndexFromArray(arr, prop, value);
        if(index > -1){
            arr.splice(index, 1);
        }
    }

    findIndexFromArray(arr, prop, value){
        return arr.findIndex(obj => obj[prop] === value);
    }

    statusDropDown(props, state, columnMeta, index, rowId, defaultValue){
        this.state.statusInfo_selectedDefault[rowId] = this.state.statusObjs[defaultValue];
        let options = this.state.statusOptions;
        return (
            <Select
                value={{label: (!_.isUndefined(this.state.statusInfo_selected[rowId]))?this.state.statusInfo_selected[rowId]:this.state.statusInfo_selectedDefault[rowId],  value: defaultValue}}
                onChange={this.handleStatusDropDownChange.bind(this, rowId)}
                options={options}
                className="status-drop-down"
                classNamePrefix="status-drop-down"
                placeholder="choose status..."
                id={rowId}
                isDisabled={!props.data.allSamplesScored}
            />
        );
    }

    handleNoteChange(rowId, event){
        this.modifiedNotes[rowId] = event.target.value;
    }

    saveNote(rowId){
        $.ajax({
            url: urls.saveNotesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, noteType: "plate", parentId: rowId, note: this.modifiedNotes[rowId]}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] === "0"){
                    toast.success("Note saved successfully.");
                }
                else {
                    toast.error("Error while saving note! Please check server logs.")
                }
                this.fetchData();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving note !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    deleteNote(rowId){
        $.ajax({
            url: urls.deleteNotesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, noteType: "plate", parentId: rowId}),
            type:'POST',
            cache: true,
            success: async function(data) {
                toast.success("Note deleted successfully.");
                this.fetchData();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving note !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    note(props, state, columnMeta, index, rowId, defaultValue){
        return (
            <Notes
                defaultValue={defaultValue}
                onNoteChange={this.handleNoteChange.bind(this, rowId)}
                onSaveClick={this.saveNote.bind(this, rowId)}
                onDeleteClick={this.deleteNote.bind(this, rowId)}
            />
        );
    }


    render() {
        const {data,requestDetails, notificationMessage, scatterPlotData, scatterPlotDataByPlate, sCurvePlotData, wellsData, maxCallProbability, statusCounts, projectStatus,
            gridConfig , renderGrid, selectedRows, appCode, openSubmitRedoModal,openReadyToReviewModal, statusInfo_redo, totalPlates, currentUser, projectId, labCode, projectType,
            openUpdateProjectModal, workflowType} = this.state;
        let customCellFormatters = {
            "statusDropDown" : this.statusDropDown.bind(this),
            "note": this.note.bind(this)
        };
        let submitButtonClassName = 'button';
        let submitButtonDisabled = '';
        let reviewDataButtonClassName = 'button';
        let reviewDataButtonDisabled = "";
        let sendBackToLabButtonClassName = 'button';
        let sendBackToLabButtonDisabled = '';
        if(projectStatus !== ProjectConstants.project_status.ready_to_review_process){
            sendBackToLabButtonClassName = 'disabled-button';
            sendBackToLabButtonDisabled = 'disabled';
        }

        if(!(statusCounts.redocount>0 && (statusCounts.redocount + statusCounts.dropcount + statusCounts.okcount) === totalPlates)){
            submitButtonClassName = 'disabled-button';
            submitButtonDisabled = 'disabled';
        }
        if((statusCounts.redocount + statusCounts.dropcount + statusCounts.okcount) !== totalPlates){
            reviewDataButtonClassName = 'disabled-button';
            reviewDataButtonDisabled = "disabled"
        }
        return (
            <div>
                <ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>
                <Modal visible={openSubmitRedoModal}  width="400" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openSubmitRedoModal')}>
                    <SubmitRedo projectId={projectId} currentUser={currentUser}/>
                </Modal>
                <Modal visible={openReadyToReviewModal}  width="400" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openReadyToReviewModal')}>
                    <ReadyToReview projectId={projectId} currentUser={currentUser}/>
                </Modal>
                <Modal visible={openUpdateProjectModal}  width="400" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openUpdateProjectModal')}>
                    <UpdateProject projectId={projectId} currentUser={currentUser}/>
                </Modal>
                <div id="assay-data-plots-holder-by-plate" className={"container-fluid"}>
                    {renderGrid &&
                    <div className={'row'}>
                        <div id="assay-data-by-plate" tabIndex="1" style={{width: '65%'}} className={"outline0"}>
                            <div style={{float: "right"}}>
                                <button id="submit-redo" onClick={this.submitRedo} disabled={submitButtonDisabled}
                                        className={submitButtonClassName}>Submit Redo
                                </button>
                                <button id="ready-to-review" onClick={this.readyToReview} disabled={reviewDataButtonDisabled}
                                        className={reviewDataButtonClassName}>Ready To Review
                                </button>
                                <button id="send-back-to-lab" onClick={this.sendBackToLab} disabled={sendBackToLabButtonDisabled}
                                        className={sendBackToLabButtonClassName}>Send back to lab
                                </button>
                            </div>

                            <DataGrid
                                appCode={appCode}
                                fixedHeight={60}
                                resultsPerPage={500}
                                showAllData={false}
                                onRowClick={this.onRowClick}
                                showCheckBox={true}
                                showCheckAllCheckbox={false}
                                config={gridConfig}
                                //colorConfig={colorConfig}
                                customCellFormatters={customCellFormatters}
                                data={data}
                                heading={"Score Marker Assay Data"}
                                refreshData={this.fetchData}
                                settingOptions={true}
                                filterOptions={false}
                                indexColumn={"plateMarkerId"}
                            />

                        </div>
                        <div id="plots-by-plate" tabIndex="2" style={{width: '35%'}} className={"outline0"}>
                            <div>
                                <Plots projectId={projectId} traceTypes={trace_types}
                                       scatterPlotGraphData={scatterPlotData}
                                       scatterPlotDataByPlate={scatterPlotDataByPlate}
                                       sCurveGraphData={sCurvePlotData}
                                       reloadData={this.reloadData}
                                       selectedRows={selectedRows}
                                       currentUser={currentUser}
                                       labCode={labCode}
                                       projectType={projectType}
                                       workflowType={workflowType}
                                />
                            </div>
                        </div>
                    </div>
                    }
                </div>
            </div>
        );
    }
}

AssayDataByPlate.defaultProps = {
    gridConfig:[]
};

function mapStateToProps(state) {
    return {
        currentUser: state.currentUser
    };
}



export default connect(mapStateToProps)(AssayDataByPlate);