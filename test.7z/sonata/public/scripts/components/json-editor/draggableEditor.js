import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import {$, AjaxLoader} from "../react-table/common/Ajaxsetup";
import urls from "../Urls";
import {toast} from "react-toastify";
import _ from 'underscore'
const Config = require ('../config/GridConfig');

const grid = 8;

function getItemStyle(isDragging, draggableStyle){
    let style = {
        userSelect: 'green',
        padding: grid * 2,
        margin: `0 0 ${grid}px 0`,

        // change background colour if dragging
        background: 'lightgrey',

        // styles we need to apply on draggables
        draggableStyle: draggableStyle
    };
    _.extend(style, draggableStyle);
    return style;
}

function getListStyle(isDraggingOver){
    let style = {
        background: isDraggingOver ? '#2980b9' : 'grey',
        // padding: grid,
        margin: `2% 0 0 0`,
        width: 700,
        height: 800,
        overflowY: 'scroll'
    };
    return style;
}

class List extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data:this.props.data
        };
        this.onDragEnd = this.onDragEnd.bind(this);
    }

    onDragEnd(result) {
        // dropped outside the list
        if (!result.destination) {
            return;
        }
        var data = this.state.data;
        var from = Number(result.source.index);
        var to = Number(result.destination.index);
        // if(from < to) to--;
        data.splice(to, 0, data.splice(from, 1)[0]);
        data.map((item, i) => {
            item.order = i+1
        });
        this.setState({data: data});
    }

    handleOnChange(i, e){
        let data = this.state.data;
        data[i][e.target.name] = e.target.value;
        this.setState({
            data: data
        })
    }

    syncConfig(){
        $.ajax({
            url: urls.syncGridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({
                userId:this.props.currentUser.email,
                appCode: this.props.appCode,
                newSettings: JSON.stringify(Config[this.props.appCode]),
                propertiesToUpdate: ["columnName","search","sort","classNames","type","indexCol","status"]
            }),
            type:'POST',
            cache: true,
            success: function(data) {
                toast.success("Successfully synced configuration");
                window.location.reload(true);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration!! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    restoreToDetault(){
        $.ajax({
            url: urls.resetGridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({ userId: this.props.currentUser.email, appCode: this.props.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                toast.success("Successfully restored configuration");
                window.location.reload(true);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving configuration!! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    saveData(){
        $.ajax({
            url: urls.saveGridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({requestData: this.state.data, userId: this.props.currentUser.email, appCode: this.props.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                toast.success("Successfully saved configuration");
                window.location.reload(true);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving configuration!! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    // Normally you would want to split things out into separate components.
    // But in this example everything is just done in one place for simplicity
    render() {
        return (
            <div>
                <DragDropContext onDragEnd={this.onDragEnd}>
                    <Droppable droppableId="droppable">
                        {(provided, snapshot) => (
                            <div
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                            >
                                {this.state.data.map((item, index) => {
                                    return <Draggable key={item.order} draggableId={item.order} index={index}>
                                        {(provided, snapshot) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                style={getItemStyle(
                                                    snapshot.isDragging,
                                                    provided.draggableProps.style
                                                )}
                                            >
                                                {<table>
                                                    <thead>
                                                    <tr>
                                                        <th>Property </th>
                                                        <th>Value</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td>Column Name</td>
                                                        <td><input className="form-control" type="SmartInput" draggable='true' name="displayName" value={item.displayName} onChange={this.handleOnChange.bind(this,index)}/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Hidden</td>
                                                        <td>
                                                            <select className="form-control" name="hidden" value={item.hidden} onChange={this.handleOnChange.bind(this, index)}>
                                                                <option value="true">True</option>
                                                                <option value="false">False</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Order</td>
                                                        <td>{index+1}</td>
                                                    </tr>
                                                    </tbody>
                                                </table>}
                                            </div>
                                        )}
                                    </Draggable>
                                })}
                                {provided.placeholder}
                            </div>
                        )}
                    </Droppable>
                    <ul>
                        <li id="save-grid-settings">
                            <button type={"button"} className="button" onClick={this.saveData.bind(this)}> Save </button>
                        </li>
                        <li id="save-grid-settings">
                            <button className="button" onClick={this.restoreToDetault.bind(this)}> Restore To Detaults </button>
                        </li>
                        <li id="save-grid-settings">
                            <button className="button" onClick={this.syncConfig.bind(this)}> Sync </button>
                        </li>
                    </ul>
                </DragDropContext>
            </div>
        );
    }
}


class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            config:[], renderJson: false
        };
        this.fetchConfig = this.fetchConfig.bind(this);
    }

    componentDidMount(){
        this.fetchConfig();
    }

    fetchConfig(){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, appCode: this.props.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                this.setState({
                    config: data.length > 0 ? data : Config[this.props.appCode], renderJson: true
                })
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration!! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }


    render() {
        return (
            <div>
                { this.state.renderJson && <List currentUser={this.props.currentUser} data={this.state.config} appCode={this.props.appCode}
                                                 refreshData={this.props.refreshData}/> }
            </div>
        )
    }
}
module.exports = App;
