import React from 'react';
import DraggableEditor from './draggableEditor'
import { connect } from 'react-redux'
import Modal from "react-responsive-modal"

class ConfigWrapper extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            config:[], userId: "", appCode:this.props.appCode, openSettingsModal: false
        };
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    render() {
        return (
            <div id="settings">
                <button type={"button"} className="btn btn-primary btn-raised btn-xs" onClick={this.openModal.bind(this,"openSettingsModal")}> Settings <i className="fa fa-cogs" /> </button>
                <Modal open={this.state.openSettingsModal} onClose={this.closeModal.bind(this,'openSettingsModal')} center>
                {/*<Modal visible={this.state.openSettingsModal} width="800" height="825" effect="fadeInUp" onClickAway={this.closeModal.bind(this,'openSettingsModal')}>*/}
                    {/*<Notification ref="notificationholder" name="gridconfignotification"/>*/}
                    {/*<ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>*/}
                    {/*<div> {this.state.renderJson && <JsonEditor title={"Grid Config"} notification={Notification} name={"gridConfig"} initial={this.state.config} />}</div>*/}
                    <DraggableEditor
                        currentUser={this.props.currentUser}
                        title={"Grid Config"}
                        name={"gridConfig"}
                        appCode={this.state.appCode}
                        refreshData={this.props.refreshData}
                    />
                </Modal>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        currentUser: state.currentUser
    };
}

module.exports = connect(mapStateToProps)(ConfigWrapper);