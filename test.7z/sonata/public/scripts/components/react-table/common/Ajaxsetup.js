import React from 'react'

import Loader from './Loader'
import $ from 'jquery'
const {getAuthHeader, enableAuthTokenSupport} = require('@monsantoit/profile-client');


class AjaxLoader extends React.Component {
    constructor(props){
        super(props);
    }
    componentDidMount(){
        let _this = this;
        return enableAuthTokenSupport()
            .then(() => {
                $.ajaxSetup({
                    beforeSend: function(xhr){
                        xhr.setRequestHeader('Authorization',getAuthHeader());
                        Loader.showLoader();
                    },
                    complete: function(){
                        Loader.hideLoader();
                    },
                    error: function(xhr,status,error) {
                        console.log("error in ajax >> "+error);
                        Loader.hideLoader();
                    }

                });
            })
    }

    render(){
        return <Loader ref="custom-loader"/>
    }
}

module.exports = {$, AjaxLoader};

