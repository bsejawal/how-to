import React from 'react'
const status = {"success":"green","failure":"red"};

class Notification extends React.Component {

    constructor(props){
        super(props);
    }

    // @message = message to display on pop up
    // @type = either success or failure
    showPopUp(message, type, callback){
        let divName = this.props.name;
        let div = this.refs["notification-"+divName];
        div.style.opacity = "1";
        div.style.backgroundColor = status[type];
        div.style.zIndex = 15000;
        div.innerHTML = message;
        setTimeout(function(){ div.style.opacity = "0"; div.style.zIndex = -999}, 2000);
        if(callback) callback();
    }

    render() {
        const msg = this.props.message;
        return (
            <div ref={"notification-"+this.props.name} className="form-control notification-div" />
        )
    }
}

module.exports = Notification;