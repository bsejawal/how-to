import React from 'react'

class Loader extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            displayProp:"none"
        };
        Loader.showLoader = Loader.showLoader.bind(this);
        Loader.hideLoader = Loader.hideLoader.bind(this);
    }

    static showLoader(){
        this.setState({
            displayProp: "block"
        })
    }

    static hideLoader(){
        this.setState({
            displayProp:"none"
        });
    }

    render() {
        let style = {"display":this.state.displayProp, "zIndex":15000};
        return (
            <div id="overlay" style={style}>
                {/*<div style={style} className="loader" >Loading... Please Wait.</div>*/}
                <div className="loading5 mid-position"><i/><i/><i/><i/></div>
                {/*<div style={style} className="ball"/>*/}
                <div style={style} className="mid-position line"/>
            </div>
        )
    }
}

module.exports = Loader;