import React, {useState, useEffect, useRef} from 'react';
import GridRow from './GridRow.js';
import $ from "jquery";
import _ from 'underscore'

let indexCol = null;

class GridRows extends React.PureComponent {
    constructor(props){
        super(props);
        this.state = ({
            selectedRowIds: [], lastSelectedRowId:"", pressedCtrlKey: false, isMouseButtonPressed: false, lastSelectedRowIndex: 0,
            selectedRows: []
        })
    }

    componentDidMount(){
    }

    onMouseOver(data, rowId, event){
        let {selectedRows,selectedRowIds,isMouseButtonPressed} = this.state;
        if (isMouseButtonPressed) {
            event.preventDefault();
            if(selectedRows[rowId]){
                delete selectedRows[rowId];
            }
            selectedRows[rowId] = {
                rowId: rowId,
                data: data
            };
            let index = selectedRowIds.indexOf(rowId);
            if(index > -1){
                selectedRowIds.splice(index, 1);
            }
            selectedRowIds.push(rowId);
            $("#"+rowId).focus();
        }
    }

    onMouseDown(data, rowId, rowIndex, rowIndexOffset, event){
        const {selectedRowIds, selectedRows, triggerMouseUp, lastSelectedRowIndex} = this.state;
        var _selectedRowIds = event.ctrlKey || event.shiftKey ? selectedRowIds : [];
        var _selectedRows = event.ctrlKey || event.shiftKey ? selectedRows : [];
        if(event.shiftKey){
            event.preventDefault();
            let _indexCol = this.props.indexColumn;
            let _data = this.props.data;
            let startIndex = lastSelectedRowIndex+1 , endIndex = rowIndex;
            if(rowIndex < lastSelectedRowIndex){
                startIndex = rowIndex;
                endIndex = lastSelectedRowIndex-1;
            }
            for(let i= startIndex; i <= endIndex; i++){
                let rowId = _data[i][_indexCol];
                _selectedRows[rowId] = {
                    rowId: rowId,
                    data: _data[i]
                };
                _selectedRowIds.push(rowId);
            }
        }else {
            if (_selectedRows[rowId]) {
                delete _selectedRows[rowId];
                // toggle if ctrl key is pressed
                if (!event.ctrlKey) {
                    _selectedRows[rowId] = {
                        rowId: rowId,
                        data: data
                    };
                }
            } else {
                _selectedRows[rowId] = {
                    rowId: rowId,
                    data: data
                };
            }
            let index = _selectedRowIds.indexOf(rowId);
            if (index > -1) {
                _selectedRowIds.splice(index, 1);
                // toggle if ctrl key is pressed
                if (!event.ctrlKey) {
                    _selectedRowIds.push(rowId);
                }
            } else
                _selectedRowIds.push(rowId);
        }
        $("#"+rowId).focus();
        this.setState({
            selectedRows: _selectedRows, selectedRowIds: _selectedRowIds,isMouseButtonPressed: true
        }, () => {
            if(event.callMouseUp){
                this.onMouseUp(rowId, rowIndex, rowIndexOffset, event);
            }
        })
    }

    async onMouseUp(rowId, rowIndex, rowIndexOffset, event){
        const {selectedRows, selectedRowIds} = this.state;
        let _this = this;
        await this.props.onRowClick(event, selectedRows, rowId);
        this.setState({
            lastSelectedRowId : selectedRowIds[selectedRowIds.length-1],
            lastSelectedRowIndex :  rowIndexOffset+rowIndex
        },()=>{
            _this.state.isMouseButtonPressed = false;
        });
    }

    handleKeyPress(data, rowId, previousData, nextData, rowIndex, rowIndexOffset, event){
        let _this = this;
        if(event.keyCode === 38)
            this.onUpArrowPress(event, previousData, rowIndex, rowIndexOffset);
        else if(event.keyCode === 40)
            this.onDownArrowPress(event, nextData, rowIndex, rowIndexOffset);
    }

    onUpArrowPress(event, data, rowIndex, rowIndexOffset){
        let _this = this;
        var row = $("#"+this.state.lastSelectedRowId);
        let ancestor = row.prev();
        let ancestorId = ancestor.attr("id");
        if(ancestorId!==null && ancestorId!==undefined){
            ancestor.on('mousedown', function(){
                event.callMouseUp = true;
                event.upArrowPressed = true;
                event.downArrowPressed = false;
                _this.onMouseDown(data, ancestorId, rowIndex, rowIndexOffset, event);
            });
            _this.state.lastSelectedRowId = ancestorId;
            ancestor.trigger('mousedown');
            ancestor.unbind('mousedown');
        }
    }

    onDownArrowPress(event, data, rowIndex, rowIndexOffset,){
        let _this = this;
        var row = $("#"+this.state.lastSelectedRowId);
        let successor = row.next();
        let successorId = successor.attr("id");
        if(successorId!==null && successorId!==undefined){
            successor.on('mousedown', function () {
                event.callMouseUp = true;
                event.downArrowPressed = true;
                event.upArrowPressed = false;
                _this.onMouseDown(data, successorId, rowIndex, rowIndexOffset, event);
            });
            _this.state.lastSelectedRowId = successorId;
            successor.trigger("mousedown");
            successor.unbind('mousedown')
        }
    }

    render(){
        const {selectedRowIds, selectedRows,lastSelectedRowId, lastSelectedRowIndex} = this.state;
        var _indexCol = this.props.indexColumn;
        var rowclassName = this.props.row ? 'customRowContainer' : 'defaultRowContainer';
        rowclassName += this.props.showCheckbox ? ' showCheck' : '';
        let indexOffSet = this.props.indexOffset;
        let columnMetaData = this.props.columnMetadata.sort(function(a,b) {return a.order - b.order});
        let rowValColor = this.props.data[this.props.columnMetadata.filter(function(c){ return c.status === "true" }).map(function(c){return c.columnName})];
        let data = this.props.data;
        var rows = [];
        var rowLinkProps = this.props.rowLinkProps;
        for (var index = 0, len = data.length; index < len; index++) {
            let item = data[index];
            let rowId = item[_indexCol] ? item[_indexCol] : index + indexOffSet;
            let rowClass = "row-" + rowId;
            rowClass += " table-row ";
            var columnKey = this.props.rowLink;
            if(rowLinkProps.length > 0){
                rowLinkProps.map((prop) => {
                    columnKey += "/"+item[prop]
                })
            }
            let mustUpdate = selectedRowIds.indexOf(rowId) > -1;
            if (mustUpdate)
                rowClass += " table-success";
            let style = {height:'0vh'};
            let gridRow = (
                <GridRow {...this.props}
                         rowValColor={rowValColor}
                         columnMetaData={columnMetaData}
                         rowId={rowId}
                         data={item}
                         rowClass={rowClass}
                         keyIndex={index}
                         key={index} className={rowclassName + " " + rowClass}
                         mustUpdate={this.state.isMouseButtonPressed ? mustUpdate : this.props.mustUpdate}
                         link={columnKey}
                />
            );
            let _tr = (
                <tr tabIndex={0} key={index} className={rowClass} id={rowId}
                            onMouseDown={this.onMouseDown.bind(this, item, rowId, index, indexOffSet)}
                            onMouseUp={this.onMouseUp.bind(this, rowId, index, indexOffSet)}
                            onMouseOver={this.onMouseOver.bind(this, item, rowId)}
                            onKeyUp={this.handleKeyPress.bind(this, item, rowId, data[index - 1], data[index + 1], index, indexOffSet)}
                            style={style}
                >
                    {gridRow}
                </tr>
            );
            rows.push(_tr);
        }

        return (
            <React.Fragment>{rows}</React.Fragment>
        );
    }
};

/**
 * @return {null}
 */
function TrWithHook(props){
    const { observerEntry, elRef } = useIntersection({ threshold: 0 });
    let style = _.extend({}, props.style);
    style.visibility = observerEntry.isIntersecting ? "visible" : "hidden";
    return (
        <tr ref={elRef}
            tabIndex={props.tabIndex} key={props.index} className={props.className} id={props.id}
            onMouseDown={props.onMouseDown}
            onMouseUp={props.onMouseUp}
            onMouseOver={props.onMouseOver}
            onKeyUp={props.onKeyUp}
            style={style}>
            {props.child}
        </tr>
    );
}

function useIntersection(options) {
    const [observerEntry, setEntry] = useState({});
    const elRef = useRef();
    useEffect(
        () => {
            const observer = new IntersectionObserver(
                entries => setEntry(entries[0]),
                options
            );
            observer.observe(elRef.current);
            return () => observer.disconnect();
        },
        [elRef]
    );
    return { observerEntry, elRef };
}

GridRows.defaultProps = {
    data: [],
    columnMetadata: [],
    onRowClick:()=>{},
    onChangeGrid:()=>{}
}

module.exports = GridRows;
