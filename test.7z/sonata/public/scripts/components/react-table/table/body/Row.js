const React = require('react');
const Link = require('react-router').Redirect;
const Route = require("react-router").Route;
const CustomLink = require("./Link");
import $ from 'jquery'

class DefaultRow extends React.Component {
    constructor(props) {
        super(props);
        this.state = { expand: false, rowLink: "" }
    }

    render() {
        var columnKey = this.props.link;
        var rowValColor = this.props.rowValColor;
        var rowColorClass = this.props.colorConfig[rowValColor];
        var expandIcon = (this.state.expand || this.props.expandAll)? <i className="fa fa-angle-up"/>:<i className="fa fa-angle-down"/> ;
        var metaData = this.props.columnMetadata;
        var data = this.props.data;
        var rowCells = [];
        for (var columnIndex = 0, len = metaData.length; columnIndex < len; columnIndex++) {
            let columnMeta = metaData[columnIndex];
            var thisColumn = data[columnMeta.columnName];
            var displayDiv = "";
            if (columnMeta.hidden === 'false') {
                var style = (columnMeta.flexBasis !== undefined) ? {
                    flexBasis: columnMeta.flexBasis,
                    flexGrow: 0,
                    flexShrink: 0
                } : {};
                if (columnMeta.flexGrow !== undefined) {
                    style.flexGrow = columnMeta.flexGrow;
                }
                if (typeof columnMeta.render === "function") {
                    var cell = columnMeta.render(this.props, this.state, columnMeta, columnIndex);
                }
                else if (typeof columnMeta.render !== "undefined") {
                    var customCellFormatter = this.props.customCellFormatters[columnMeta.render];
                    cell = customCellFormatter(this.props, this.state, columnMeta, columnIndex, this.props.rowId, thisColumn);
                } else {
                    cell = thisColumn;
                    if (typeof cell === 'string')
                        cell = cell.trim();
                    style.overflow = 'hidden'
                }
                if (typeof columnMeta.formatter === 'function') {
                    var cellToolTip = columnMeta.formatter(thisColumn);
                } else if (typeof thisColumn === 'string') {
                    cellToolTip = thisColumn;
                } else {
                    cellToolTip = columnMeta.displayName;
                }
                style = Object.assign(style, columnMeta.style);
                displayDiv = (
                    <td tabIndex={columnIndex} key={columnIndex} style={{overflow: 'visible', width: '100px'}}
                        className={"td"}>
                        <div id={"column-" + this.props.rowId + "-" + columnIndex}
                             className={rowColorClass + ' defaultCell .table-hover cell column-' + columnIndex + ' column-' + columnMeta.columnName + " " + columnMeta.className}
                             style={style} key={columnIndex} title={cellToolTip}>
                            {(this.props.rowLink && columnMeta.indexCol === "true") ?
                                <CustomLink className={"anchor " + rowColorClass} link={columnKey}
                                            body={cell}
                                            target={this.props.target ? this.props.target : "_blank"}/> : cell}

                        </div>
                    </td>
                )
            }
            rowCells.push(displayDiv);
        }
        return (
            <React.Fragment>{rowCells}</React.Fragment>
        )
    }
}

DefaultRow.defaultProps = {
    data: {},
    columnMetadata: [],
    className: '',
    onExpand: () => { },
    onRowClick: () => { },
    onRowDoubleClick: () => { }
};

module.exports = DefaultRow;
