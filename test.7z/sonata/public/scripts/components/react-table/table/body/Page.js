import React from 'react';
import Table from './MainTable'
import DefaultConfig from '../config/DefaultConfig.json'
import Notification from '../../common/Notification'
import {$, AjaxLoader} from '../../common/Ajaxsetup'

const _ = require('underscore');

class Page extends React.Component {
    constructor(props) {
        super(props);
        this.onChangeGrid = this.onChangeGrid.bind(this);
        this.state = {
            tableConfig: {
                showAllTools: props.showAllTools,
                gridId:props.gridId ? props.gridId : "react-grid-table",
                currentPage: 1,
                showCheckbox: props.showCheckBox ? props.showCheckBox : false,
                filterOptions: props.filterOptions ? props.filterOptions : false,
                getAdvanceFilter: props.getAdvanceFilter,
                saveAdvanceFilter: props.saveAdvanceFilter,
                deleteAdvanceFilter: props.deleteAdvanceFilter,
                applyAdvanceFilter: props.applyAdvanceFilter,
                settingOptions: props.settingOptions,
                refreshOptions: props.refreshOptions,
                appCode: props.appCode,
                showCheckAllCheckbox: props.showCheckAllCheckbox ? props.showCheckAllCheckbox : false,
                showAllData: props.showAllData ? props.showAllData : false,
                onChangeGrid: props.onChangeGrid ? props.onChangeGrid : this.onChangeGrid,
                selectedRows: {},
                onRowClick: props.onRowClick ? props.onRowClick: this.onRowClick,
                onRowDoubleClick: props.onRowDoubleClick ? props.onRowDoubleClick:this.onRowDoubleClick,
                resultsPerPage: props.resultsPerPage ? props.resultsPerPage : 10,
                row: require('./Row.js'),
                header: require('../header/Header.js'),
                pagination: require('../pagination/Pagination.js'),
                showHeader: props.showHeader ? props.showHeader : true,
                showPagination: props.showPagination ? props.showPagination : true,
                masterSearch: props.masterSearch,
                heading:props.heading ? props.heading : "",
                rowLink: props.rowLink ? props.rowLink : null,
                rowLinkProps: props.rowLinkProps ? props.rowLinkProps : [],
                customCellFormatters: props.customCellFormatters ? props.customCellFormatters : null,
                colorConfig: props.colorConfig ? props.colorConfig : {},
                settingsLink: props.settingsLink ? props.settingsLink : null,
                indexOffset: 0,
                checkAll: false,
                totalCount: 0,
                indexColumn: props.indexColumn ? props.indexColumn : null,
                fixedHeight:props.fixedHeight,
                refreshData: props.refreshData,
                enableColumnResizer: props.enableColumnResizer
                // width: '1000px'
            }
        }
    }

    onChangeGrid(event, data) {
        let tableConfig = this.state.tableConfig;
        _.extend(tableConfig, data);
        this.setState({
            tableConfig: tableConfig
        });

        // if(this.props.showCheckBox){
        //     this.props.onCheckBoxChange(event,data);
        // }
    }

    render() {
        return (
            <div>
                <Table columnMetadata={this.props.config ? this.props.config : DefaultConfig}
                       data={this.props.data ? this.props.data : []}
                       advanceFilters={this.props.advanceFilters ? this.props.advanceFilters : {}}
                       style={{ margin: '30px' }} {...this.state.tableConfig} />
            </div>
        )
    }
}

module.exports = {DataGrid: Page,Notification: Notification,AjaxLoader: AjaxLoader,$: $};

