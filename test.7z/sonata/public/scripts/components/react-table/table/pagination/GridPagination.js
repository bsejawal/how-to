import React from 'react';

class GridFooter extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            totalPages : Math.ceil(this.props.numberOfEntries / this.props.resultsPerPage)
        };
        this.onChangeGrid = this.onChangeGrid.bind(this);
    }
    onChangeGrid(event, data) {
        var newData = data;
        // newData.selectedRows = {};
        this.props.onChangeGrid(event, newData);
    }
    
    render () {
        var optionsArray = [];
        for (var i = 1; i <= this.state.totalPages; i++) {
            optionsArray.push(
                <option >{i}</option>
            )
        }
        var Pagination = this.props.showPagination ? this.props.pagination : null;

        return (
            <div>
                {Pagination ? <Pagination {...this.props}
                                  onChangeGrid={this.onChangeGrid}
                                  /> : null}
            </div>
        )
    }
};

module.exports =  GridFooter;