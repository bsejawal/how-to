import React from 'react'
import FiltersWrapper from "../../filters/FiltersWrapper";
import Settings from "../../../json-editor/index"

class Tools extends React.Component {
    constructor(props){
        super(props);
        this.state = {

        }
    }

    render(){
        return(
            <div className={"list-in-line"} style={{margin:"1vh 0 0 0"}}>
                {/*refresh button*/}
                {
                    this.props.refreshOptions &&
                    (<div style={{margin:"0 1vh 0 0"}}>
                        <button onClick={this.props.refreshData} className={"btn btn-primary btn-raised btn-xs"} type="button">Reload <i className="glyphicon glyphicon-refresh"/></button>
                    </div>)
                }
                {/*settings options*/}
                {
                    this.props.settingOptions &&
                    (<div style={{margin:"0 1vh 0 0"}}>
                        <Settings {...this.props}/>
                    </div>)
                }
                {/*filter options*/}
                {
                    this.props.filterOptions &&
                    (<div style={{margin:"0 1vh 0 0"}}>
                        <FiltersWrapper
                            advanceFilters={this.props.advanceFilters}
                            getAdvanceFilter={this.props.getAdvanceFilter}
                            saveAdvanceFilter={this.props.saveAdvanceFilter}
                            deleteAdvanceFilter={this.props.deleteAdvanceFilter}
                            applyAdvanceFilter={this.props.applyAdvanceFilter}
                            columnMetaData={this.props.columnMetadata} />
                    </div>)
                }
            </div>
        )
    }
}

module.exports = Tools;