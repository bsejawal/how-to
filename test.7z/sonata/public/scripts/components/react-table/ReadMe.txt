Arguments:

Config (Json): file describing the table structure including header and configuration for each cell. -- required

Data (Json): data to be displayed in the grid in simple json format.

OnRowDoubleClick (function): function that will handle the row double click

OnRowClick (function): function that will handle the row click

RowLink (string) : link for each row. It will append the value of index column indicated as indexCol in config page.
eg: if provided value for rowLink props is "myApp/myPage" then final link on the row will be "<baseurl>/myApp/myPage/<indexCol>" and this url must be defined in the route to
take care of what should be displayed.

CustomCellFormatters (function) : if needed to display different cell contents than simple text values like dropdown then pass the object containing the mapping as
 value of render property in config : defined functions name

ShowAllData (boolean) : if needed to show all data at one single page without pagination, pass this props as true;

showCheckBox (boolean) : if needed to show the check box in the front of every rows, pass true else false;
checkBoxOnChange (function) : if showCheckBox is true, place this function to handle checkbox change event. will return row data. -- required if showCheckBox is true

showCheckAllCheckbox (function) : if needed to show checkall checkbox on top header, pass this props as true or false.

colorConfig (json object) :
"status":"true" should put into config file for the coloumn on which we need to make color dependent and pass color config as:
let colorConfig = {
            "TBD":"bg-green text-white",
            "In Remediation":"bg-red text-white",
            "failure":"bg-maroon text-white"
        };

resultsPerPage: for default number of rows per page. If not supplied, default is 10.
