import React from 'react'

class Equals extends React.Component{
    constructor(props){
        super(props)
    }

    render(){
        return (
            <div>
                Equals
            </div>
        )
    }
}

module.exports = Equals;