import React from 'react';
import Select from 'react-select';
import ProjectConstants from '../../util/ProjectConstants'

class FilterMain extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            samplesConfig: props.columnMetaData,
            selectedConfig: [],
            generatedFilters:{}, filterName: "Default", currentFilterDetails: {}, activeFilterId: "",
            filterDetailModal: false
        });
        this.createFieldOptions = this.createFieldOptions.bind(this);
        this.filterOptions = {
            "EQUALS_TO":"EQUALS TO",
            "NOT_EQUALS_TO":"NOT EQUALS TO",
            "BEGINS_WITH":"BEGINS WITH",
            "CONTAINS":"CONTAINS",
            "GREATER_THAN":"GREATER THAN",
            "LESS_THAN":"LESS THAN",
            "ENDS_WITH":"ENDS WITH",
            "IS_IN_LIST":"IS IN LIST",
            "NULL":"NULL",
            "NOT_EMPTY":"NOT EMPTY",
        }
    }

    componentDidMount(){
        // this.getAdvanceFilters();
    }

    openModal(type){
        this.setState({ [type]: true });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };

    handleFieldChange(objs){
        let generatedFilters = this.state.generatedFilters;
        let _generatedFilters = {};
        for(let field in objs){
            _generatedFilters[objs[field]["key"]] = generatedFilters[objs[field]["key"]]
        }
        this.setState({
            selectedConfig: objs,
            generatedFilters: _generatedFilters
        })
    }

    handleFilterNameChange(event){
        let filterName = event.target.value;
        this.setState({
            filterName: filterName
        })
    }

    handleFilterTypeChange(obj){
        const {generatedFilters} = this.state;
        if(typeof generatedFilters[obj.key] === "undefined")
            generatedFilters[obj.key] = {};
        generatedFilters[obj.key]["criteria"] = obj.value;
        generatedFilters[obj.key]["displayName"] = obj.displayName;
        generatedFilters[obj.key]["type"] = obj.type;
        this.setState({
            generatedFilters: generatedFilters
        })
    }

    handleFilterValueChange(fieldName, event ){
        const {generatedFilters} = this.state;
        if(typeof generatedFilters[fieldName] === "undefined")
            generatedFilters[fieldName] = {};
        generatedFilters[fieldName]["data"] = event.target.value;
        this.setState({
            generatedFilters: generatedFilters
        })
    }

    createFieldOptions(samplesConfig){
        let fieldOptions = [];
        for(let con in samplesConfig) {
            let conf = samplesConfig[con];
            fieldOptions.push({key:conf.columnName, value: conf.columnName, label: conf.displayName, type: conf.type})
        }
        return fieldOptions;
    }

    createFilterOptions(displayName, fieldName, fieldType ){
        const {generatedFilters} = this.state;
        let filterOptions = this.filterOptions;
        let fieldOptions = [];
        for(let fo in filterOptions) {
            let option = filterOptions[fo];
            fieldOptions.push({key: fieldName, value: fo, label: option, displayName: displayName, type: fieldType})
        }
        let currentValue = null;
        if(typeof generatedFilters[fieldName] !== "undefined"){
            currentValue = {key: fieldName, value: generatedFilters[fieldName]["criteria"], label: filterOptions[generatedFilters[fieldName]["criteria"]], displayName: displayName, type: fieldType}
        }
        return (
            <Select
                value={currentValue}
                onChange={this.handleFilterTypeChange.bind(this)}
                options={fieldOptions}
                className="small-drop-down"
                classNamePrefix="small-drop-down"
                placeholder="Choose..."
            />
        );
    }

    createFilterableDivs(selectedConfig){
        const {generatedFilters} = this.state;
        let filterableDivs = [];
        for(let conf in selectedConfig){
            let generatedFiltersForThisValue = generatedFilters[selectedConfig[conf].value];
            let currentFilterValue = "";
            let criteria = "";
            if(typeof generatedFiltersForThisValue !== "undefined"){
                currentFilterValue = generatedFiltersForThisValue["data"];
                criteria = generatedFiltersForThisValue["criteria"];
            }
            let dataField = (
                                <input type={selectedConfig[conf].type === "date" ? "date" : "text"} required value={currentFilterValue}
                                    onChange={this.handleFilterValueChange.bind(this,selectedConfig[conf].value)}/>
                            );
            if(criteria === "IS_IN_LIST"){
                dataField = (
                    <textarea required value={currentFilterValue} style={{minHeight: "15vh"}}
                           onChange={this.handleFilterValueChange.bind(this,selectedConfig[conf].value)}/>
                )
            }
            if(criteria === "NOT_EMPTY" || criteria === "NULL"){
                dataField = "";
            }
            filterableDivs.push(
                <div className={"row"} style={{margin: "0 0 1vh 0"}} key={selectedConfig[conf].key}>
                    <div style={{padding: "0vh 1vh 0vh 0vh", width: "20%"}}>
                        {selectedConfig[conf].label}
                    </div>
                    <div style={{padding: "0vh 1vh 0vh 0vh", width: "40%"}}>
                        {this.createFilterOptions(selectedConfig[conf].label, selectedConfig[conf].value, selectedConfig[conf].type)}
                    </div>
                    <div style={{padding: "0vh", width: "40%"}}>
                        {dataField}
                    </div>
                </div>
            )
        }
        return filterableDivs;
    }

    showFilterDetails(currentFilterDetails){
        let currentFilterDetailsValue = currentFilterDetails["value"];
        let generatedFilters = {};
        let selectedFilterOptions = [];
        for(let filterDetail in currentFilterDetailsValue){
            selectedFilterOptions.push(
                {key: filterDetail, value: filterDetail, label: currentFilterDetailsValue[filterDetail]["displayName"], type: currentFilterDetailsValue[filterDetail]["type"]}
            );
            generatedFilters[filterDetail] = {
                criteria: currentFilterDetailsValue[filterDetail]["criteria"],
                displayName: currentFilterDetailsValue[filterDetail]["displayName"],
                type: currentFilterDetailsValue[filterDetail]["type"],
                data: currentFilterDetailsValue[filterDetail]["data"]
            }
        }
        this.setState({
            selectedConfig: selectedFilterOptions,
            currentFilterDetails: currentFilterDetails,
            filterName: currentFilterDetails["name"]+Math.random().toString(36).substr(2, 5),
            generatedFilters: generatedFilters
        })
    }

    handleActiveFilterChange(event){
        this.setState({
            activeFilterId: event.target.value
        })
    }

    saveAdvanceFilter(){
        const {generatedFilters, filterName} = this.state;
        this.props.saveAdvanceFilter({"name": filterName, value: generatedFilters});
    }

    deleteAdvanceFilter(filterId){
        this.props.deleteAdvanceFilter({"filterId": filterId})
    }

    applyAdvanceFilter(){
        const {activeFilterId} = this.state;
        if(activeFilterId !== "")
            this.props.applyAdvanceFilter({"filterId": activeFilterId})
    }

    advanceFilterList(advanceFilters, activeFilterId){
        let advanceFilterList = [];
        for(let filter in advanceFilters){
            let _filter = advanceFilters[filter];
            let criteria = JSON.parse(_filter["metaData"]);
            let defaultActiveFilter = _filter["configCode"] === ProjectConstants.ADVANCE_FILTER_ACTIVE_CONFIG_CODE;
            let activeFilter = activeFilterId === "" ? defaultActiveFilter : _filter["id"] === parseInt(activeFilterId);
            advanceFilterList.push(
                <div className={"row"}>
                    <div className={"col-1"}>
                        <input type={"radio"} name={"active_filter"} value={_filter["id"]} defaultChecked={defaultActiveFilter} checked={activeFilter}
                               onClick={this.handleActiveFilterChange.bind(this)}/>
                    </div>
                    <div className={"col-6"} >
                        <a href={"javascript:void(0)"} onClick={this.showFilterDetails.bind(this, criteria)}> {criteria["name"]} </a>
                    </div>
                    <div className={"col-5"}>
                        <button type={"button"} className="btn btn-primary btn-xs"
                                onClick={this.deleteAdvanceFilter.bind(this, _filter["id"])}>Delete</button>
                    </div>
                </div>
            )
        }
        advanceFilterList.push(
            <div className={"row"}>
                <div className={"col"}>

                </div>
                <div className={"col"}>
                    <button type={"button"} className="btn btn-primary btn-raised btn-xs"
                            onClick={this.applyAdvanceFilter.bind(this)}> Apply </button>
                </div>
            </div>
        );
        return advanceFilterList;
    }

    getSelectedFilterOptions(currentFilterDetails, selectedConfig){
        let selectedFilterOptions = [];
        let currentFilterDetailsValue = currentFilterDetails["value"];
        for(let filterDetail in currentFilterDetailsValue){
            selectedFilterOptions.push(
                {key: filterDetail, value: filterDetail, label: currentFilterDetailsValue[filterDetail]["displayName"], type: currentFilterDetailsValue[filterDetail]["type"]}
            )
        }
        for(let config in selectedConfig){
            let option = selectedConfig[config];
            if(!selectedFilterOptions.filter(f => f["key"] === selectedConfig[config]["key"]).length > 0) {
                selectedFilterOptions.push(selectedConfig[config])
            }
        }
        return selectedFilterOptions;
    }

    render(){
        const { samplesConfig, selectedConfig, activeFilterId, filterName } = this.state;
        const { advanceFilters } = this.props;
        let advanceFilterList = this.advanceFilterList(advanceFilters, activeFilterId);
        let fieldOptions = this.createFieldOptions(samplesConfig);
        let filterableDivs = this.createFilterableDivs(selectedConfig);
        return (
            <div style={{margin: "2vh 2vh 2vh 2vh"}}>
                <div className="container-fluid filter-modal-container" style={{width:"100%"}}>
                    <div className="row">
                        <div style={{width: "55%"}}>
                            <div className={"container-fluid"}>
                                <div className={"row"} style={{margin:"1vh 2vh 2vh 1vh"}}>
                                    <div className={"col-8"}>
                                        Name: <input type={"text"} name={"filterName"} value={filterName} required={true} onChange={this.handleFilterNameChange.bind(this)}/>
                                    </div>
                                    <div className={"col-4"}>
                                        <button type={"button"} className="btn btn-primary btn-raised btn-xs"
                                                onClick={this.saveAdvanceFilter.bind(this)}>Save</button>
                                    </div>
                                </div>
                                <div className={"row"} style={{margin:"0vh 2vh 2vh 1vh"}}>
                                    <div className={"col"}>
                                        Select Fields:
                                        <Select
                                            value={selectedConfig}
                                            isMulti={"true"}
                                            onChange={this.handleFieldChange.bind(this)}
                                            options={fieldOptions}
                                            placeholder="Choose Field..."
                                            closeMenuOnSelect={false}
                                        />
                                    </div>
                                </div>
                                <div className={"row"} style={{margin:"0vh 0vh 1vh 0vh"}}>
                                    <div style={{width:"100%"}}>
                                        <div className={"container-fluid"} style={{margin:"0vh 0vh 1vh 0vh", height:"55vh", overflowY:"scroll"}}>
                                            {filterableDivs}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style={{width: "45%"}}>
                            <div className={"container-fluid"}>
                                {advanceFilterList}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

module.exports = FilterMain;