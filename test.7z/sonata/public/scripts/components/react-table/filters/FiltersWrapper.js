/**
 * Created by RNEUP on 3/1/2018.
 */
import React from 'react'
import FilterMain from './FilterMain'
import Modal from "react-responsive-modal"

class FiltersWrapper extends React.Component{
    constructor(props){
        super(props);
        this.state = ({
            filterProps: this.props.filterProps,
            openFilterModal: false
        })
    }


    openModal(type){
        this.setState({
            [type]: true
        }, ()=>{
            this.props.getAdvanceFilter();
        });
    };

    closeModal(type){
        this.setState({ [type]: false });
    };


    render(){
        return (
            <div>
                <button type={"button"} className="btn btn-primary btn-raised btn-xs" onClick={this.openModal.bind(this,"openFilterModal")}>Filter <i className="fa fa-filter"/></button>
                <Modal open={this.state.openFilterModal} onClose={this.closeModal.bind(this,'openFilterModal')} center  styles={{ modal: {width:"100vh", maxWidth:"1500vh" }}}>
                    <FilterMain {...this.props}/>
                </Modal>
            </div>
        )
    }
}

module.exports = FiltersWrapper;
