import React from 'react'

class Like extends React.Component{
    constructor(props){
        super(props)
    }

    render(){
        return <div>
            Like
        </div>
    }
}

module.exports = Like;