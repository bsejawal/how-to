const trace_types = {"hom_fam":"HOM_FAM", "hemi":"HEMI", "hom_vic":"HOM_VIC","fail":"FAIL","standard_controls":"STRD_CONTROLS",
                    "neg":"NEG","pos":"POS","uncallable":"UNCALLABLE", "missing":"MISSING", "cherrypicked":"CHERRYPICKED",
                    "tandem":"TANDEM", "multicopy":"MULTICOPY"};
const project_types = {"dpcr":"DPCR", "taqman":"TAQMAN", "agtaqman": "AGTAQMAN"};
const labs = {"stl":"MQ", "ank": "A"};
const customer_report = {"customer":{"type":"CUSTOMER","groupId":"STLTAQMANCUSTOMER"}, "lab_user":{"type":"LAB_USER"}};
const workflow_types = {"wft1":"WFT1", "wft2":"WFT2", "wft3":"WFT3", "wft4":"WFT4"};
const project_status = {"in_process":"IN_PROCESS", "ready_to_review_process": "READY_TO_REVIEW_PROCESS","delivered":"DELIVERED"};

const SONATA = "sonata";
const ASSAY_DATA_BY_PLATE_WFT1 = "assay-data-by-plate-wft1";
const ASSAY_DATA_BY_FAMILY_WFT1 = "assay-data-by-family-wft1";
const ASSAY_DATA_BY_PLATE_WFT2 = "assay-data-by-plate-wft2";
const ASSAY_DATA_BY_PLATE_WFT3 = "assay-data-by-plate-wft3";
const ASSAY_DATA_BY_FAMILY_WFT3 = "assay-data-by-family-wft3";
const ASSAY_DATA_BY_PLATE_WFT4 = "assay-data-by-plate-wft4";
const ASSAY_DATA_BY_FAMILY_WFT4 = "assay-data-by-family-wft4";
const ASSIGN_ANALYST = "assign-analyst";
const CHERRYPICK_WFT2 = "cherrypick-wft2";
const CUSTOMER_REPORT_PERCENT_MISSING_BY_PEDIGREE_WFT2 = "customer-report-percent-missing-by-pedigree-wft2" ;
const CUSTOMER_REPORT_RESULT_WFT2 = "customer-report-result-wft2";
const CUSTOMER_REPORT_SUMMARY_AGGREGATE_WFT2 = "customer-report-summary-aggregate-wft2";
const CUSTOMER_REPORT_SUMMARY_DETAILS_WFT2 = "customer-report-summary-details-wft2";
const SELECTED_DATA_BY_PLATE_WFT1 = "selected-data-by-plate-wft1";
const SELECTED_DATA_BY_FAMILY_WFT1 = "selected-data-by-family-wft1";

const ADVANCE_FILTER_CONFIG_CODE = "ADVANCE_FILTER";
const ADVANCE_FILTER_ACTIVE_CONFIG_CODE = "ADVANCE_FILTER_ACTIVE";

module.exports = {"trace_types":trace_types, "project_types": project_types,
    "labs": labs, "customer_report": customer_report, "workflow_types":workflow_types,
    "project_status": project_status,
    "app-codes" :
        {SONATA, ASSAY_DATA_BY_PLATE_WFT1, ASSAY_DATA_BY_PLATE_WFT2, ASSAY_DATA_BY_PLATE_WFT3, ASSAY_DATA_BY_FAMILY_WFT1, ASSAY_DATA_BY_FAMILY_WFT3,
        ASSIGN_ANALYST, CHERRYPICK_WFT2, CUSTOMER_REPORT_PERCENT_MISSING_BY_PEDIGREE_WFT2, CUSTOMER_REPORT_RESULT_WFT2, CUSTOMER_REPORT_SUMMARY_AGGREGATE_WFT2,
        CUSTOMER_REPORT_SUMMARY_DETAILS_WFT2,SELECTED_DATA_BY_PLATE_WFT1,SELECTED_DATA_BY_FAMILY_WFT1, ASSAY_DATA_BY_PLATE_WFT4, ASSAY_DATA_BY_FAMILY_WFT4},
    ADVANCE_FILTER_CONFIG_CODE, ADVANCE_FILTER_ACTIVE_CONFIG_CODE
};