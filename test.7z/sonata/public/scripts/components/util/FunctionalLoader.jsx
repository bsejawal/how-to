import React from 'react';

/**
 * Function for returning a FunctionalLoader component.
 * @param alertType - props handed from parent component
 * @returns React element
 */
const FunctionalLoader = ({ status }) => {

    switch (status) {
        case 'load':
            return (
                <div id="overlay" style={{"display":"block", "zIndex":15000}}>
                    {/*<div style={style} className="loader" >Loading... Please Wait.</div>*/}
                    <div className="loading5 mid-position"><i/><i/><i/><i/></div>
                    {/*<div style={style} className="ball"/>*/}
                    <div style={{"display":"block", "zIndex":15000}} className="mid-position line"/>
                </div>
            );
        default:
            return null;
    }
};

export default FunctionalLoader;
