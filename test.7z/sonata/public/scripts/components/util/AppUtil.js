function checkNull(input){
    return input === null;
}

function checkUndefined(input){
    return typeof input === 'undefined';
}

function checkEmpty(input){
    return input === '';
}

function isNullOrUndefinedOrEmpty(input){
    return checkNull(input) || checkUndefined(input) || checkEmpty(input)
}

function isNullAndUndefinedAndEmpty(input){
    return checkNull(input) && checkUndefined(input) && checkEmpty(input)
}

module.exports = {checkNull, checkUndefined, checkEmpty, isNullOrUndefinedOrEmpty, isNullAndUndefinedAndEmpty}