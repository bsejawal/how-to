import React from 'react';

class CloseButton extends React.Component{
    constructor(props){
        super(props);
        this.state= ({

        })
    }

    render(){
        return(
            <button onClick={this.props.onClick} style={{float:'right'}} type="button" className="close" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        )
    }

}

module.exports = CloseButton;