function stringToDate(_date){
    if(typeof _date === 'undefined' || _date === null){
        return null
    }
    return new Date(_date);
}

module.exports = {stringToDate: stringToDate}