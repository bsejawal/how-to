import React from 'react'
import {DataGrid} from './react-table/table/body/Page.js';
import urls from './Urls'
import AssignAnalystSelect from './AssignAnalystOptions';
import {connect} from 'react-redux'
import {toast, ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import Notes from './Notes'
import PlateReload from './PlateReload'

import ProjectConstants from "./util/ProjectConstants"
import {$, AjaxLoader} from './util/Ajaxsetup'
import _ from 'underscore'

const Config = require ('./config/AssignAnalystConfig.json');

class AssignAnalyst extends React.Component {
    constructor(props){
        super(props);
        document.title = "Sonata Projects";
        this.state = {
            gridConfig: Config, data: [], renderGrid: false, appCode:ProjectConstants["app-codes"].ASSIGN_ANALYST, selectedRows: [],
            filterOptions: {appCode: ProjectConstants["app-codes"].SONATA, currentUserId: this.props.currentUser.id, level: "project"},
            advanceFilterOptions: {appCode: ProjectConstants["app-codes"].SONATA, currentUserId: this.props.currentUser.id, level: "project-filter"},
            advanceFilters: {},
            notesModified: false
        };
        this.onRowClick = this.onRowClick.bind(this);
        this.fetchConfig = this.fetchConfig.bind(this);
        this.fetchData = this.fetchData.bind(this);
        this.getAdvanceFilter = this.getAdvanceFilter.bind(this);
        this.saveAdvanceFilter = this.saveAdvanceFilter.bind(this);
        this.deleteAdvanceFilter = this.deleteAdvanceFilter.bind(this);
        this.applyAdvanceFilter = this.applyAdvanceFilter.bind(this);
        // this.restyleRow = this.restyleRow.bind(this);

        this.modifiedNotes = {};
    }

    onRowClick(event, data){
        this.setState({
            selectedRows: data
        })
    }

    componentDidMount() {
        this.fetchData();
    }

    fetchData(){
        const {filterOptions, advanceFilterOptions} = this.state;
        _.extend(filterOptions,{"advanceFilterOptions": advanceFilterOptions});
        $.ajax({
            url: urls.getProjectsRoute,
            contentType: 'application/json',
            data:JSON.stringify(this.state.filterOptions),
            type:'POST',
            cache: true,
            success: function(data) {
                this.fetchConfig(data);
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching data, "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    fetchConfig(gridData){
        $.ajax({
            url: urls.gridConfigRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, appCode: this.state.appCode}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(!(data.length > 0)) data = Config;
                this.setState({data:gridData["projectVOS"], renderGrid:true, gridConfig: data, advanceFilters: gridData["advanceFilterAppConfigs"]});
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while fetching configuration from api !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    handleNoteChange(rowId, event){
        this.modifiedNotes[rowId] = event.target.value;
    }

    saveNote(rowId){
        $.ajax({
            url: urls.saveNotesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, noteType: "project", parentId: rowId, note: this.modifiedNotes[rowId]}),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] === "0"){
                    toast.success("Note saved successfully.");
                }
                else {
                    toast.error("Error while saving note! Please check server logs.")
                }
                this.fetchData();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving note !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    deleteNote(rowId){
        $.ajax({
            url: urls.deleteNotesRoute,
            contentType: 'application/json',
            data:JSON.stringify({userId:this.props.currentUser.email, noteType: "project", parentId: rowId}),
            type:'POST',
            cache: true,
            success: async function(data) {
                if(data["status"] === "1")
                    toast.error("Error occured while deleting note. Please check server logs!");
                else if(data["status"] === "2")
                    toast.warn("No notes found to delete.");
                else
                    toast.success("Note deleted successfully.");
                this.fetchData();
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving note !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    note(props, state, columnMeta, index, rowId, defaultValue){
        return (
            <Notes
                defaultValue={defaultValue}
                onNoteChange={this.handleNoteChange.bind(this, rowId)}
                onSaveClick={this.saveNote.bind(this, rowId)}
                onDeleteClick={this.deleteNote.bind(this, rowId)}
            />
        );
    }

    getAdvanceFilter(filterCriteria){
        let _filterCriteria = this.state.advanceFilterOptions;
        $.ajax({
            url: urls.getAdvanceFilterRoute,
            contentType: 'application/json',
            data:JSON.stringify(_filterCriteria),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] !== "0") {
                    toast.error("Error occured while getting filter options. Please check server logs!");
                }
                else {
                    this.setState({
                        advanceFilters: data["advanceFilters"]
                    })
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving filters !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    saveAdvanceFilter(filterCriteria){
        let _filterCriteria = this.state.advanceFilterOptions;
        _.extend(_filterCriteria, {"filterCriteria": filterCriteria});
        $.ajax({
            url: urls.saveAdvanceFilterRoute,
            contentType: 'application/json',
            data:JSON.stringify(_filterCriteria),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] !== "0") {
                    toast.error("Error occured while saving filter options. Please check server logs!");
                }
                else {
                    toast.success("Filter Saved Successfully.");
                    this.setState({
                        advanceFilters: data["advanceFilters"]
                    })
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while saving filters !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    deleteAdvanceFilter(deleteFilterData){
        let advanceFilterOptions = this.state.advanceFilterOptions;
        _.extend(advanceFilterOptions, deleteFilterData);
        $.ajax({
            url: urls.deleteAdvanceFilterRoute,
            contentType: 'application/json',
            data:JSON.stringify(advanceFilterOptions),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] !== "0") {
                    toast.error("Error occured while deleting filter options. Please check server logs!");
                }
                else {
                    toast.success("Filter Deleted Successfully.");
                    this.setState({
                        advanceFilters: data["advanceFilters"]
                    })
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while deleting filters !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }

    applyAdvanceFilter(applyFilterData){
        let advanceFilterOptions = this.state.advanceFilterOptions;
        _.extend(advanceFilterOptions, applyFilterData);
        $.ajax({
            url: urls.applyAdvanceFilterRoute,
            contentType: 'application/json',
            data:JSON.stringify(advanceFilterOptions),
            type:'POST',
            cache: true,
            success: function(data) {
                if(data["status"] !== "0")
                    toast.error("Error occured while applying filter. Please check server logs!");
                else{
                    window.location.reload(true);
                }
            }.bind(this),
            error: function(xhr, status, err) {
                toast.error("Error while applying filters !! Msg = "+err+". Check server logs. ")
            }.bind(this)
        });
    }


    breederQcLink(props, state, columnMeta, index, rowId, defaultValue){
        let link = "";
        if(props.data.projectStatus === ProjectConstants.project_status.delivered) {
            link = (
                <a href={"/breeder-qc/" + rowId} target={"_blank"}>
                    QC Results
                </a>
            )
        }
        return link;
    }
    platesReload(props, state, columnMeta, index, rowId, defaultValue){
        let platesReload = (
            <PlateReload projectId={rowId} userId={this.props.currentUser.id} />
        );
        return platesReload;
    }

    // restyleRow(props, state, columnMeta, columnIndex){
    //     let cell = props.data[columnMeta.columnName];
    //     if(parseInt(cell) > 0){
    //         let _divs = Array.from(document.getElementsByClassName(props.rowClass));
    //         for(let i in _divs){
    //             if(_divs[i].className.indexOf("disabled") < 0){
    //                 _divs[i].className += " disabled";
    //             }
    //         }
    //     }
    //     return(
    //         <span>{cell}</span>
    //     )
    // }

    render(){
        const {selectedRows, gridConfig, data, appCode, renderGrid, filterOptions, advanceFilters} = this.state;
        let customCellFormatters = {
            "note" : this.note.bind(this),
            "breederQcLink": this.breederQcLink.bind(this),
            "platesReload":this.platesReload.bind(this)
        };

        return(
            <div>
                <div><AssignAnalystSelect filterOptions={filterOptions} currentUser={this.props.currentUser} fetchConfig={this.fetchConfig} selectedRows={selectedRows} popup={this.refs.holder}/></div>
                <AjaxLoader/>
                <ToastContainer position={toast.POSITION.TOP_RIGHT} style={{zIndex:150000}}/>
                {renderGrid &&
                    <DataGrid
                        appCode={appCode}
                        resultsPerPage={500}
                        fixedHeight={60}
                        showAllData={false}
                        onRowClick={this.onRowClick}
                        showCheckBox={true}
                        showCheckAllCheckbox={false}
                        config={gridConfig}
                        //colorConfig={colorConfig}
                        customCellFormatters = {customCellFormatters}
                        data={data}
                        heading={"Review Requests"}
                        rowLink={["/smad-web/score-marker-assay-data"]}
                        rowLinkProps={["projectId","workFlowType"]}
                        refreshData={this.fetchData}
                        refreshOptions={true}
                        settingOptions={true}
                        filterOptions={true}
                        getAdvanceFilter={this.getAdvanceFilter}
                        applyAdvanceFilter={this.applyAdvanceFilter}
                        saveAdvanceFilter={this.saveAdvanceFilter}
                        deleteAdvanceFilter={this.deleteAdvanceFilter}
                        advanceFilters={advanceFilters}
                    />
                }
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        assignAnalystWarnings: state.assignAnalystWarnings,
        currentUser: state.currentUser
    };
}

module.exports = connect(mapStateToProps)(AssignAnalyst);
