import React from 'react';
import AssayDataWF1 from './workflows/wft1/AssayDataTabs'
import AssayDataWF2 from './workflows/wft2/AssayDataTabs'
import AssayDataWF3 from './workflows/wft3/AssayDataTabs'
import AssayDataWF4 from './workflows/wft4/AssayDataTabs'
import ProjectConstants from './util/ProjectConstants'
import {AjaxLoader} from "./util/Ajaxsetup";

class AssayDataMain extends React.Component {
    constructor(props){
        super(props);
        document.title = this.props.match.params.requestId+" Score";
        this.state = ({
            workflowType: this.props.match.params.wf,
            projectId: this.props.match.params.requestId
        })
    }

    render(){
        const {workflowType, projectId} = this.state;
        let returnPage = "";
        switch (workflowType) {
            case ProjectConstants.workflow_types.wft1:
                returnPage = <AssayDataWF1 {...this.props} projectId={projectId}/>;
                break;
            case ProjectConstants.workflow_types.wft2:
                returnPage = <AssayDataWF2 {...this.props} projectId={projectId}/>;
                break;
            case ProjectConstants.workflow_types.wft3:
                returnPage = <AssayDataWF3 {...this.props} projectId={projectId}/>;
                break;
            case ProjectConstants.workflow_types.wft4:
                returnPage = <AssayDataWF4 {...this.props} projectId={projectId}/>;
                break;
            default:
                returnPage = <div> This project is not under any workflow. Please add it to an existing workflow or define new one. </div>
                break;
        }
        return (
            <div>
                <AjaxLoader/>
                {returnPage}
            </div>
        );
    }
}

module.exports = AssayDataMain;