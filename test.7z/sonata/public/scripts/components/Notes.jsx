import React from 'react';
import Modal from "react-responsive-modal"
import {loadImage} from '../resources/ImageLoader';

class Notes extends React.Component {
    constructor(props){
        super(props);
        this.state = ({
            noteModal: false,
            note:""
        })
    }

    openModal(type, event){
        this.setState({ [type]: true });
    };

    closeModal(type, event){
        this.setState({ [type]: false });
    };

    onSaveClick(){
        this.closeModal("noteModal");
        this.props.onSaveClick();
    }

    onDeleteClick(){
        if(confirm("Are you sure to delete?")) {
            this.closeModal("noteModal");
            this.props.onDeleteClick();
        }
    }

    render(){
        const {onSaveClick, onDeleteClick, onUpdateClick, onNoteChange} = this.props;
        let defaultValue = this.props.defaultValue;
        const {noteModal, note} = this.state;
        if(typeof defaultValue === "undefined" || defaultValue === null)
            defaultValue = "";
        let hasNote = false;
        if(defaultValue!==null && typeof defaultValue !== "undefined" && defaultValue !== ""){
            hasNote = true;
        }
        let noteIcon = loadImage("note-icon.png",'icon',{borderRadius:"50%", height: "0.5vh", width:'0.5vh'});
        let noteDiv = (
            <div className={"container-fluid"}>
                <div className={"row"}>
                    <div style={{width:"33vh"}}>
                        <textarea onChange={onNoteChange} defaultValue={defaultValue} style={{height:"20vh", width:"30vh"}}/>
                    </div>
                </div>
                <div className={"row"} style={{margin:"1vh 0 0 0"}}>
                    <button type="button" style={{margin:"0 1vh 0 0"}} className={"btn btn-primary btn-raised btn-xs"} onClick={this.onSaveClick.bind(this)}>Save</button>
                    <button type="button" style={{margin:"0 1vh 0 0"}} className={"btn btn-primary btn-raised btn-xs"} onClick={this.onDeleteClick.bind(this)}>Delete</button>
                </div>
            </div>
        );
        let displayValue = [defaultValue.substr(0,20)];
        if(defaultValue.length > 20) {
            displayValue.push(noteIcon)
        }
        let addNote = (<a href={"javascript:void(0)"} onClick={this.openModal.bind(this,'noteModal')}>Add</a>)
        return (
            <div>
                <Modal open={noteModal} onClose={this.closeModal.bind(this,'noteModal')} center>
                    {noteDiv}
                </Modal>
                {hasNote ?
                    <div onClick={this.openModal.bind(this,'noteModal')}>
                        {displayValue}
                    </div> : addNote
                }

            </div>
        )
    }
}

module.exports = Notes;