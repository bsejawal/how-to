const express = require('express');
const router = express.Router();
const request = require("request");
const oauth = require("../oauthConfig/token");
const urls = require('../../Urls');

const data = require("../TestData.json");

router.get(urls.scoringAssayData,(req,response,next) =>{
    let projectId = req.query.projectId;
    // oauth.getToken('dpcr-scv').then(function() {
        request({
            url: (projectId?urls.allMarkerPlatesByProjectUrl+"?projectId="+projectId:urls.allMarkerPlatesUrl),
            method: "GET",
            auth: {
                'bearer': oauth.token.id
            }
        }, function (error, res, body) {
            if (error){
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body.replace(/\\/g, "")));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        })
    // });
});

router.post(urls.updatePredictedCall, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request({
            url: urls.updateWellInfoUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            },
            auth: {
                'bearer': oauth.token.id
            }
        }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    try {
                        response.send(JSON.parse(res.body.replace(/\\/g, "")).markerPlateVOList);
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});

router.post(urls.getGridConfig, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.getGridConfigUrl,
                method: "POST",
                body: JSON.stringify({userId: req.body.userId, appCode: req.body.appCode}),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    try {
                        let configData = [];
                        let _metaData = JSON.parse(res.body).metaData;
                        for (let meta in _metaData) {
                            configData.push(JSON.parse(_metaData[meta]));
                        }
                        response.send(configData);
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});


router.post(urls.saveGridConfig, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.saveGridConfigUrl,
                method: "POST",
                body: JSON.stringify({configProps: req.body.requestData, appCode:req.body.appCode, userId:req.body.userId}),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    response.send("success");
                }
            }
        )
    // })
});

router.post(urls.resetGridConfig, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.resetGridConfigUrl,
                method: "POST",
                body: JSON.stringify({appCode:req.body.appCode, userId:req.body.userId}),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    response.send("success");
                }
            }
        )
    // })
});


router.post(urls.getProjects, (req, response, next) => {
    console.log("send request to " + urls.getProjectsUrl)
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.getProjectsUrl,
                method: "POST",
                body: JSON.stringify(req.body),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    try{
                        response.send(JSON.parse(res.body));
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});


router.post(urls.assignAnalyst, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.assignAnalystUrl,
                method: "POST",
                body: JSON.stringify(req.body),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    try {
                        response.send(JSON.parse(res.body.replace(/\\/g, "")));
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});

router.post(urls.savePlateStatus, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.savePlateStatusUrl,
                method: "POST",
                body: JSON.stringify(req.body),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    response.status(500).send(error);
                }else{
                    try {
                        response.send(JSON.parse(res.body.replace(/\\/g, "")));
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});

router.post(urls.getStatusList, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.getStatusListUrl,
                method: "POST",
                body: JSON.stringify(req.body),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    console.log(error);
                    response.status(500).send(error);
                }else{
                    try {
                        response.send(JSON.parse(res.body));
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});

router.post(urls.submitRedo, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.submitRedoUrl,
                method: "POST",
                body: JSON.stringify(req.body),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    console.log(error);
                    response.status(500).send(error);
                }else{
                    try {
                        response.send(JSON.parse(res.body));
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});

router.post(urls.deliverRequest, (req, response, next) => {
    request(
        {
            url: urls.deliverRequestUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers:{
                'Content-type':'application/json'
            }
        }, function(error, res, body){
            if(error)
                response.status(500).send(err);
            else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    );
});

router.post(urls.requestDetails, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
        request(
            {
                url: urls.requestDetailsUrl,
                method: "POST",
                body: JSON.stringify(req.body),
                headers: {
                    'Content-Type':'application/json'
                },
                auth: {
                    'bearer': oauth.token.id
                }
            }, function (error, res, body) {
                if(error){
                    console.log(error);
                    response.status(500).send(error);
                }else{
                    try {
                        response.send(JSON.parse(res.body));
                    }catch(err){
                        response.status(500).send(err)
                    }
                }
            }
        )
    // })
});

router.post(urls.getSampleInfoFilters, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
    request(
        {
            url: urls.getSampleInfoFiltersUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
    // })
});

router.post(urls.getSampleData, (req, response, next) => {
    // oauth.getToken('dpcr-scv').then(function(){
    request(
        {
            url: urls.getSampleDataUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
    // })
});

router.post(urls.cherrypickSamples, (req, response, next) => {
    request(
        {
            url: urls.cherrypickSamplesUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.customerReport, (req, response, next) => {
    request(
        {
            url: urls.customerReportUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.customerReportDownload, (req, response, next) => {
    request(
        {
            url: urls.customerReportDownloadUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send({headers: res.headers, data: body})
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.customerReportEmail, (req, response, next) => {
    request(
        {
            url: urls.customerReportEmailUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.getDropdownsConfig, (req, response, next) => {
    request(
        {
            url: urls.getDropdownsConfigUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.getAppConfig, (req, response, next) => {
    request(
        {
            url: urls.getAppConfigUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.saveAppConfig, (req, response, next) => {
    request(
        {
            url: urls.saveAppConfigUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.resetAppConfig, (req, response, next) => {
    request(
        {
            url: urls.resetAppConfigUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.saveNotes, (req, response, next) => {
    request(
        {
            url: urls.saveNotesUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.deleteNotes, (req, response, next) => {
    request(
        {
            url: urls.deleteNotesUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.syncGridConfig, (req, response, next) => {
    request(
        {
            url: urls.syncGridConfigUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.readyToReview, (req, response, next) => {
    request(
        {
            url: urls.readyToReviewUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.updateProject, (req, response, next) => {
    request(
        {
            url: urls.updateProjectUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.deleteMarkerPlates, (req, response, next) => {
    request(
        {
            url: urls.deleteMarkerPlatesUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.samplesForPlate, (req, response, next) => {
    request(
        {
            url: urls.samplesForPlateUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.advanceFilter, (req, response, next) => {
    request(
        {
            url: urls.getAdvanceFilterUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.saveAdvanceFilter, (req, response, next) => {
    request(
        {
            url: urls.saveAdvanceFilterUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.deleteAdvanceFilter, (req, response, next) => {
    request(
        {
            url: urls.deleteAdvanceFilterUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.applyAdvanceFilter, (req, response, next) => {
    request(
        {
            url: urls.applyAdvanceFilterUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});

router.post(urls.reload, (req, response, next) => {
    request(
        {
            url: urls.reloadUrl,
            method: "POST",
            body: JSON.stringify(req.body),
            headers: {
                'Content-Type':'application/json'
            }
        }, function (error, res, body) {
            if(error){
                console.log(error);
                response.status(500).send(error);
            }else{
                try {
                    response.send(JSON.parse(res.body));
                }catch(err){
                    response.status(500).send(err)
                }
            }
        }
    )
});


module.exports = router;
