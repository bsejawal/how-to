// const tokenConfigs = JSON.parse(process.env.VCAP_SERVICES);
//
// const tokenConfigMapping = tokenConfigs["user-provided"].find((item) => item.name === 'oauth-configs')["credentials"];
//
// let tokenUrl = tokenConfigMapping["dpcr-scv"].accessTokenUrl;
//
// let tokenConfig = {
//     url: tokenUrl+"?grant_type=client_credentials",
//     method:"POST",
//     headers: {
//         'Content-Type': 'application/x-www-form-urlencoded',
//         "Accept-Language": "en-US,en;q=0.5"
//     }
// };
//
// function getTokenConfig(arg){
//     tokenConfig["auth"] = {
//         user: tokenConfigMapping[arg].clientId,
//         pass: tokenConfigMapping[arg].clientSecret
//     };
//     return tokenConfig;
// }
//
// module.exports = {getTokenConfig};
//
