const request = require("request");
const tokenConfigs = require('./token-configs');

let token = {id:null, obtainedTime:''};
let tokenObj = null;

function getToken(type){
    if(tokenObj===null || tokenExpires(tokenObj))
        return new Promise((resolve,reject)=>
            request(
                tokenConfigs.getTokenConfig(type),
                function(err, res){
                    if(!err) {
                        tokenObj = JSON.parse(res.body);
                        token.id = tokenObj["access_token"];
                        token.obtainedTime = new Date();
                    }else{
                        console.error("Error while getting auth token.");
                        console.error(JSON.stringify(err));
                    }
                    resolve();
                }));
    else return new Promise(function(resolve,reject){ resolve() });
}

function tokenExpires(tokenObj){
    if(tokenObj === null) return true;
    return (((new Date().getTime() - token.obtainedTime.getTime())/1000) > parseFloat(tokenObj['expires_in']))
}

module.exports = {getToken, token};