import ProjectConstants from '../util/ProjectConstants'
import AssignAnalystConfig from './AssignAnalystConfig.json'
import AssayDataByPlateConfigWft1 from './workflows/wft1/AssayDataByPlateConfig'
import AssayDataByPlateConfigWft2 from './workflows/wft2/AssayDataByPlateConfig'
import AssayDataByPlateConfigWft3 from './workflows/wft3/AssayDataByPlateConfig'
import AssayDataByFamilyConfigWft1 from './workflows/wft1/AssayDataByFamilyConfig';
import AssayDataByFamilyConfigWft3 from './workflows/wft3/AssayDataByFamilyConfig';
import CherrypickConfigWft2 from './workflows/wft2/CherrypickConfig';
import CustomerReportPercentMissingByPedigreeConfigWft2 from './workflows/wft2/CustomerReportPercentMissingByPedigreeConfig';
import CustomerReportResultConfigWft2 from './workflows/wft2/CustomerReportResultConfig';
import CustomerReportSummaryAggregateConfigWft2 from './workflows/wft2/CustomerReportSummaryAggregateConfig';
import CustomerReportSummaryDetailsConfigWft2 from './workflows/wft2/CustomerReportSummaryDetailsConfig';

const config = {
    [ProjectConstants["app-codes"].ASSAY_DATA_BY_PLATE_WFT1]: AssayDataByPlateConfigWft1,
    [ProjectConstants["app-codes"].ASSAY_DATA_BY_PLATE_WFT2]: AssayDataByPlateConfigWft2,
    [ProjectConstants["app-codes"].ASSAY_DATA_BY_PLATE_WFT3]: AssayDataByPlateConfigWft3,
    [ProjectConstants["app-codes"].ASSAY_DATA_BY_FAMILY_WFT1]: AssayDataByFamilyConfigWft1,
    [ProjectConstants["app-codes"].ASSAY_DATA_BY_FAMILY_WFT3]: AssayDataByFamilyConfigWft3,
    [ProjectConstants["app-codes"].CHERRYPICK_WFT2]: CherrypickConfigWft2,
    [ProjectConstants["app-codes"].CUSTOMER_REPORT_PERCENT_MISSING_BY_PEDIGREE_WFT2]: CustomerReportPercentMissingByPedigreeConfigWft2,
    [ProjectConstants["app-codes"].CUSTOMER_REPORT_RESULT_WFT2]: CustomerReportResultConfigWft2,
    [ProjectConstants["app-codes"].CUSTOMER_REPORT_SUMMARY_AGGREGATE_WFT2]: CustomerReportSummaryAggregateConfigWft2,
    [ProjectConstants["app-codes"].CUSTOMER_REPORT_SUMMARY_DETAILS_WFT2]: CustomerReportSummaryDetailsConfigWft2,
    [ProjectConstants["app-codes"].ASSIGN_ANALYST]: AssignAnalystConfig
};

module.exports = config;