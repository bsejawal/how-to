import React from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import Configuration from './Configuration'
import AssayDataMain from './AssayDataMain';
import JsonEditor from './json-editor/index'
import AssignAnalyst from './AssignAnalyst'
import SamplesInfo from './workflows/wft2/Cherrypick/SamplesInfo'
import CustomerReport from './workflows/wft2/CustomerReport/CustomerReport'
import PlateMapViewMain from './PlateMapViewMain'

const routes = (
    <BrowserRouter>
        <div>
            <Route exact path="/smad-web/configuration" component={Configuration}/>
            <Route exact path="/smad-web/score-marker-assay-data/:requestId/:wf" component={AssayDataMain}/>
            <Route exact path="/smad-web/settings/:appCode" component={JsonEditor} />
            <Route exact path="/smad-web/assign-analyst" component={AssignAnalyst} />
            <Route exact path="/smad-web/samples-info" component={SamplesInfo} />
            <Route exact path="/smad-web/customer-report" component={CustomerReport} />
            <Route exact path="/smad-web/plate-map-view/:requestId/:plateId/:wf" component={PlateMapViewMain} />

            <Route exact path="/smad-web-stage/configuration" component={Configuration}/>
            <Route exact path="/smad-web-stage/score-marker-assay-data/:requestId/:wf" component={AssayDataMain}/>
            <Route exact path="/smad-web-stage/settings/:appCode" component={JsonEditor} />
            <Route exact path="/smad-web-stage/assign-analyst" component={AssignAnalyst} />
            <Route exact path="/smad-web-stage/samples-info" component={SamplesInfo} />
            <Route exact path="/smad-web-stage/customer-report" component={CustomerReport} />
            <Route exact path="/smad-web-stage/plate-map-view/:requestId/:plateId/:wf" component={PlateMapViewMain} />
        </div>
    </BrowserRouter>
);

module.exports = routes;