import React from 'react';

function loadImage(imageName, alt, style) {
    return <img src={require(`./images/${imageName}`)} style={style} alt={alt} />;
}

module.exports = {loadImage};