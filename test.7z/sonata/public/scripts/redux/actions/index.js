export const updateAssignAnalystWarnings = () => {
    return {
        type: 'ASSIGN_ANALYST_WARNING',
        warnings: []
    }
};

export const setCurrentUser = () => {
    return {
        type: 'SET_CURRENT_USER',
        currentUser: {}
    }
};

export const setApplicationCode = () => {
    return {
        type: 'SET_APPLICATION_CODE',
        applicationCode: {'':''}
    }
};

