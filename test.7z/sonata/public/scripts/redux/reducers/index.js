const initialState = {
    assignAnalystWarnings: [],
    currentUser: {}
};

const reducers = (state = initialState, action) => {
    switch(action.type){
        case 'ASSIGN_ANALYST_WARNING':
            return Object.assign({} , state, {
                assignAnalystWarnings: action.warnings
            });
        case 'SET_CURRENT_USER':
            return Object.assign({} , state, {
                currentUser: action.currentUser
            });
        default:
            return state;
    }
};

export default reducers;