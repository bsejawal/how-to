const webpack = require('webpack')

module.exports = {
  devtool: 'source-map',
  entry: [
    'babel-polyfill',
    './public/scripts/main',
  ],
  module: {
    loaders: [
      {test: /.json$/, loader: 'json-loader'},
      {test: /.jsx?$/, loader: 'babel-loader', exclude: /node_modules/,
          query: {
          presets: ['react', 'env', 'es2015']
      }
      },
      {test:/\.css$/, loaders: ['style-loader','css-loader']},
        { test: /\.(png|jpg|gif)$/, loader: 'url-loader?limit=85000' }
    ],
  },
  output: {
    filename: 'bundle.js',
    path: `${__dirname}/public/scripts/`,
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"production"',
      },
    }),
    new webpack.IgnorePlugin(/regenerator|nodent|js-beautify/, /ajv/),
    new webpack.optimize.OccurrenceOrderPlugin(),
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        warnings: false,
      },
      dead_code: true,
      minimize: true,
    }),
  ],
  resolve: {
    extensions: [
      '.js',
      '.json',
      '.jsx',
    ],
  },
   node: {fs: 'empty'}
};