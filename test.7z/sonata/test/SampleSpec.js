describe('sample spec', () => {
  it('validates that 1 is 1', () => {
    (1).should.equal(1);
  });
});